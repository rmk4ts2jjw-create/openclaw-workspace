// src/routes/api/crons.tsx
// Cron jobs API — handled by handleApiRequest in src/server.ts
// This stub export prevents TanStack Router warnings about non-route files.
export function Route() {
  return null;
}
