// src/routes/api/incidents-resolve.ts
// Resolve an incident — sets status to RESOLVED and records resolution timestamp
import { writeFileSync, readFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";

export async function POST({ request }: { request: Request }) {
  try {
    const { id, resolved, timeline } = (await request.json()) as {
      id: string;
      resolved: string;
      timeline?: unknown[];
    };
    const incidentsPath = join(WORKSPACE, "data", "incidents.json");
    if (!existsSync(incidentsPath)) {
      return new Response(JSON.stringify({ ok: false, error: "incidents.json not found" }), {
        status: 404,
        headers: { "Content-Type": "application/json" },
      });
    }
    const incidents = JSON.parse(readFileSync(incidentsPath, "utf-8")) as Record<string, unknown>[];
    const idx = incidents.findIndex((i) => i.id === id);
    if (idx !== -1) {
      incidents[idx] = {
        ...incidents[idx],
        status: "RESOLVED",
        resolved,
        lastActivity: resolved,
        ...(timeline ? { timeline } : {}),
      };
      writeFileSync(incidentsPath, JSON.stringify(incidents, null, 2), "utf-8");
    }
    return new Response(JSON.stringify({ ok: true }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("[api/incidents/resolve] Error:", err);
    return new Response(JSON.stringify({ ok: false, error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
