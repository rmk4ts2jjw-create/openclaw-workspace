// src/routes/api/dispatch.tsx
// Direct API route for dispatching tasks to the queue
import { writeFileSync, readFileSync, existsSync, mkdirSync } from "node:fs";
import { join } from "node:path";

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";

export async function POST({ request }: { request: Request }) {
  try {
    const { taskId, title, assignee } = await request.json();
    const dir = join(WORKSPACE, "data");
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });

    const queuePath = join(dir, "queue.json");
    let queue: Array<{
      id: string;
      taskId: string;
      title: string;
      assignee: string;
      dispatchedAt: string;
      status: string;
    }> = [];

    try {
      const raw = readFileSync(queuePath, "utf-8");
      queue = JSON.parse(raw);
    } catch {
      queue = [];
    }

    const item = {
      id: `queue-${Date.now().toString(36)}`,
      taskId,
      title,
      assignee,
      dispatchedAt: new Date().toISOString(),
      status: "pending",
    };

    queue.push(item);
    writeFileSync(queuePath, JSON.stringify(queue, null, 2), "utf-8");

    // Also write a dispatch event to the ship log
    const logPath = join(WORKSPACE, "memory", "ship-log.md");
    const timestamp = new Date().toISOString().replace("T", " ").slice(0, 19);
    const logEntry = `\n## ${timestamp} — TASK DISPATCHED\n- **${title}** assigned to **${assignee}**\n- Task ID: ${taskId}\n- Queue ID: ${item.id}\n- Status: pending execution\n`;
    try {
      const existing = readFileSync(logPath, "utf-8");
      writeFileSync(logPath, existing + logEntry, "utf-8");
    } catch {
      writeFileSync(logPath, `# Ship's Log\n${logEntry}`, "utf-8");
    }

    return new Response(JSON.stringify({ ok: true, queueId: item.id }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("[dispatch] Error:", err);
    return new Response(JSON.stringify({ ok: false, error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
