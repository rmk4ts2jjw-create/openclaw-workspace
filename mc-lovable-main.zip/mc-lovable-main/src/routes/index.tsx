import { createFileRoute } from "@tanstack/react-router";
import { Dashboard } from "@/components/Dashboard";
import { getSystemStats } from "@/lib/server-data/system";
import { getAgentStatus } from "@/lib/server-data/agent-status";
import { getActivityFeed } from "@/lib/server-data/activity";
import { getIncidents } from "@/lib/server-data/incidents";
import { getTasks } from "@/lib/server-data/tasks";
import { getRiskMeterItems, getAutoHealState, getAutoHealAudit, type RiskMeterItem } from "@/lib/server-data/predictions";
import { getPerformanceState } from "@/lib/server-data/performance";
import type { ActivityEvent } from "@/lib/server-data-types";
import type { Incident } from "@/lib/server-data-types";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Mission Control — Dashboard" }] }),
  loader: async () => {
    const [stats, agents, incidents, allTasks] = await Promise.all([
      getSystemStats(),
      getAgentStatus(),
      getIncidents().catch(() => [] as Incident[]),
      getTasks().catch(() => []),
    ]);
    let activity: ActivityEvent[] = [];
    try { activity = await getActivityFeed(); } catch { /* ignore */ }

    // Prediction + auto-heal data for dashboard panels
    let riskItems: RiskMeterItem[] = [];
    let autoHealState: Awaited<ReturnType<typeof getAutoHealState>> | undefined;
    let autoHealAudit: Awaited<ReturnType<typeof getAutoHealAudit>> = [];
    let performanceState: Awaited<ReturnType<typeof getPerformanceState>> | undefined;
    try {
      const [_riskItems, _autoHealState, _autoHealAudit, _performanceState] = await Promise.all([
        getRiskMeterItems(),
        getAutoHealState(),
        getAutoHealAudit(),
        getPerformanceState(),
      ]);
      riskItems = _riskItems;
      autoHealState = _autoHealState;
      autoHealAudit = _autoHealAudit;
      performanceState = _performanceState;
      console.log('[dashboard/loader] predictions loaded:', { riskItems: riskItems.length, hasAutoHeal: !!autoHealState });
    } catch (err) {
      console.error('[dashboard/loader] predictions fetch failed:', err);
      riskItems = [];
    }

    return { agents, stats, activity, incidents, allTasks, riskItems, autoHealState, autoHealAudit, performanceState };
  },
  component: HomePage,
});

function HomePage() {
  const { agents, stats, activity, incidents, allTasks, riskItems, autoHealState, autoHealAudit, performanceState } = Route.useLoaderData();
  return (
    <Dashboard
      agents={agents}
      systemStats={stats}
      activity={activity}
      incidents={incidents}
      allTasks={allTasks}
      riskItems={riskItems}
      autoHealState={autoHealState}
      autoHealAudit={autoHealAudit}
      performanceState={performanceState}
    />
  );
}
