import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Search, FileText } from "lucide-react";
import { PageHeader, Pill } from "@/components/PageHeader";
import { Markdown } from "@/components/Markdown";
import { getDocs } from "@/lib/server-data/docs";
import type { Doc } from "@/lib/server-data-types";

export const Route = createFileRoute("/docs")({
  head: () => ({ meta: [{ title: "Docs — Mission Control" }] }),
  loader: async () => {
    return await getDocs();
  },
  component: DocsPage,
});

const TYPE_PILL: Record<string, "violet" | "online" | "warning" | "cyan"> = {
  newsletter: "violet",
  brief: "online",
  note: "cyan",
  content: "warning",
};

function DocsPage() {
  const DOCS = Route.useLoaderData() as Doc[];
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<string>("all");
  const [selected, setSelected] = useState<string | null>(null);

  const filtered = useMemo(
    () =>
      DOCS.filter(
        (d) =>
          (filter === "all" || d.type === filter) &&
          (q === "" ||
            d.title.toLowerCase().includes(q.toLowerCase()) ||
            d.body.toLowerCase().includes(q.toLowerCase()))
      ),
    [q, filter, DOCS]
  );

  const current = DOCS.find((d) => d.id === selected);

  return (
    <>
      <PageHeader icon="📄" title="Docs" meta={`${DOCS.length} documents`}>
        Everything the crew has produced.
      </PageHeader>

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="search docs…"
            className="w-full rounded-md border border-border bg-card/60 pl-9 pr-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:border-violet/60"
          />
        </div>
        {(["all", "newsletter", "brief", "note", "content"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setFilter(t)}
            className={`rounded-md border px-3 py-2 text-xs font-medium transition-colors ${
              filter === t
                ? "border-violet/60 bg-violet/15 text-foreground"
                : "border-border bg-card/40 text-muted-foreground hover:text-foreground"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {DOCS.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border/80 bg-card/30 px-6 py-14 text-center">
          <div className="font-mono text-xs tracking-[0.25em] text-muted-foreground">— NO DOCS —</div>
          <div className="mt-3 text-sm text-muted-foreground">No documents found in the workspace.</div>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.length === 0 && (
            <div className="rounded-md border border-dashed border-border px-3 py-10 text-center text-sm text-muted-foreground">
              No docs match.
            </div>
          )}
          {filtered.map((d) => (
            <button
              key={d.id}
              onClick={() => setSelected(d.id === selected ? null : d.id)}
              className="w-full text-left rounded-lg border border-border bg-card/60 px-4 py-3 hover:border-violet/50 transition-colors"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <FileText className="h-4 w-4 shrink-0 text-muted-foreground" />
                  <div className="min-w-0">
                    <div className="font-medium truncate">{d.title}</div>
                    <div className="font-mono text-[11px] text-muted-foreground mt-0.5">
                      {d.date} · {d.author}
                    </div>
                  </div>
                </div>
                <Pill variant={TYPE_PILL[d.type] || "default"}>{d.type}</Pill>
              </div>
              {selected === d.id && (
                <div className="mt-4 rounded-md border border-border bg-background/40 p-4">
                  <Markdown source={d.body} />
                </div>
              )}
            </button>
          ))}
        </div>
      )}
    </>
  );
}
