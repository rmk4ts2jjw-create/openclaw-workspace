import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Search, BookOpen, Lightbulb, AlertTriangle, CheckCircle, Settings, FileText, HelpCircle, Tag, Calendar, User, ChevronDown, ChevronRight, Shield, Wrench, Zap } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { Markdown } from "@/components/Markdown";
import { getDailyLogs, getLongTermMemory, getWikiStats } from "@/lib/server-data/memory";
import { getStationMemory, searchMemory, getRelatedRecords, getMemoryRecord } from "@/lib/server-data/station-memory";
import type { MemoryEntry } from "@/lib/server-data-types";
import type { StationMemoryRecord, MemoryRecordType, StationMemoryStore } from "@/lib/server-data/station-memory";

export const Route = createFileRoute("/memory")({
  head: () => ({ meta: [{ title: "Memory — Mission Control" }] }),
  loader: async () => {
    const [daily, long, station, wikiStats] = await Promise.all([
      getDailyLogs(),
      getLongTermMemory(),
      getStationMemory(),
      getWikiStats(),
    ]);
    return { daily, long, station, wikiStats };
  },
  component: MemoryPage,
});

type Tab = "daily" | "long" | "knowledge";

// ── Station Memory category config ──────────────────────────────────────────

const CATEGORY_CONFIG: Record<
  MemoryRecordType,
  { label: string; icon: typeof BookOpen; color: string }
> = {
  "architecture-decision": { label: "Architecture", icon: Settings, color: "text-violet" },
  "lesson-learned":       { label: "Lessons",     icon: Lightbulb, color: "text-amber" },
  "incident-knowledge":   { label: "Incidents",   icon: AlertTriangle, color: "text-destructive" },
  "completed-task-summary": { label: "Tasks",     icon: CheckCircle, color: "text-[oklch(0.88_0.18 145)]" },
  "operational-decision": { label: "Operations",  icon: Zap, color: "text-cyan-accent" },
  "framework-rule":       { label: "Rules",       icon: Shield, color: "text-warning" },
  runbook:                { label: "Runbooks",    icon: FileText, color: "text-cyan-accent" },
  "known-issue":          { label: "Known Issues", icon: HelpCircle, color: "text-destructive" },
};

const ALL_CATEGORIES: MemoryRecordType[] = [
  "architecture-decision", "lesson-learned", "incident-knowledge",
  "completed-task-summary", "operational-decision", "framework-rule",
  "runbook", "known-issue",
];

// ── Main Page ────────────────────────────────────────────────────────────────

function MemoryPage() {
  const { daily: DAILY_LOG, long: LONG_TERM, station, wikiStats } = Route.useLoaderData() as {
    daily: MemoryEntry[];
    long: string;
    station: StationMemoryStore;
    wikiStats: Record<string, number> | null;
  };
  const [tab, setTab] = useState<Tab>("daily");
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState(DAILY_LOG[0]?.date ?? "");

  const filtered = useMemo(
    () =>
      DAILY_LOG.filter(
        (e) =>
          e.title.toLowerCase().includes(q.toLowerCase()) ||
          e.body.toLowerCase().includes(q.toLowerCase()) ||
          e.date.includes(q)
      ),
    [q, DAILY_LOG]
  );
  const current = DAILY_LOG.find((e) => e.date === selected) ?? DAILY_LOG[0];

  return (
    <>
      <PageHeader icon="🧠" title="Memory">
        Daily logs, long-term memory, and institutional knowledge.
      </PageHeader>

      <div className="mb-5 flex gap-2">
        <TabBtn active={tab === "daily"} onClick={() => setTab("daily")}>Daily Log</TabBtn>
        <TabBtn active={tab === "long"} onClick={() => setTab("long")}>Long-term</TabBtn>
        <TabBtn active={tab === "knowledge"} onClick={() => setTab("knowledge")}>Knowledge Base</TabBtn>
      </div>

      {tab === "daily" && (
        DAILY_LOG.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border/80 bg-card/30 px-6 py-14 text-center">
            <div className="font-mono text-xs tracking-[0.25em] text-muted-foreground">— NO LOGS —</div>
            <div className="mt-3 text-sm text-muted-foreground">No daily logs found.</div>
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-[320px_1fr]">
            <div className="space-y-3">
              <div className="relative">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="search entries…"
                  className="w-full rounded-md border border-border bg-card/60 pl-9 pr-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:border-violet/60"
                />
              </div>
              <div className="space-y-2 max-h-[70vh] overflow-y-auto pr-1">
                {filtered.length === 0 && (
                  <div className="rounded-md border border-dashed border-border px-3 py-6 text-center text-xs text-muted-foreground">
                    No entries match.
                  </div>
                )}
                {filtered.map((e) => {
                  const active = e.date === selected;
                  return (
                    <button
                      key={e.date}
                      onClick={() => setSelected(e.date)}
                      className={`w-full text-left rounded-lg border px-3 py-3 transition-colors ${
                        active
                          ? "border-violet/60 bg-violet/10 shadow-[0_0_0_1px_oklch(0.62_0.22_295/0.3)]"
                          : "border-border bg-card/40 hover:border-violet/40"
                      }`}
                    >
                      <div className="font-mono text-sm font-semibold">{e.date}</div>
                      <div className="font-mono text-[10px] text-muted-foreground mt-0.5">
                        {e.words.toLocaleString()} words
                      </div>
                      <div className="mt-2 text-xs text-muted-foreground line-clamp-2">## {e.title}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            {current && (
              <div className="rounded-xl border border-border bg-card/40 p-6 max-h-[78vh] overflow-y-auto">
                <div className="font-mono text-[11px] tracking-[0.25em] text-muted-foreground mb-4">
                  {current.date} · {current.words.toLocaleString()} WORDS
                </div>
                <Markdown source={current.body} />
              </div>
            )}
          </div>
        )
      )}

      {tab === "long" && (
        <div className="rounded-xl border border-border bg-card/40 p-6 max-h-[78vh] overflow-y-auto">
          <div className="font-mono text-[11px] tracking-[0.25em] text-muted-foreground mb-4">
            MEMORY.md · LONG-TERM
          </div>
          <Markdown source={LONG_TERM} />
        </div>
      )}

      {tab === "knowledge" && (
        <KnowledgeBaseTab station={station} wikiStats={wikiStats} />
      )}
    </>
  );
}

// ── Knowledge Base Tab ───────────────────────────────────────────────────────

function KnowledgeBaseTab({ station, wikiStats }: { station: StationMemoryStore; wikiStats: Record<string, number> | null }) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<MemoryRecordType | "all">("all");
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const filteredRecords = useMemo(() => {
    let records = station.records;
    if (activeCategory !== "all") {
      records = records.filter((r) => r.type === activeCategory);
    }
    if (searchQuery.trim()) {
      records = searchMemory(station, searchQuery).filter(
        (r) => activeCategory === "all" || r.type === activeCategory
      );
    }
    return records.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [station.records, activeCategory, searchQuery]);

  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = { all: station.records.length };
    for (const type of ALL_CATEGORIES) {
      counts[type] = station.records.filter((r) => r.type === type).length;
    }
    return counts;
  }, [station.records]);

  return (
    <>
      {/* Search */}
      <div className="mb-4 relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by keyword, tag, component, file, agent…"
          className="w-full rounded-lg border border-border bg-card/60 pl-10 pr-4 py-2.5 text-sm placeholder:text-muted-foreground focus:outline-none focus:border-violet/60"
        />
      </div>

      {/* Wiki Stats Banner */}
      {wikiStats && (
        <div className="mb-4 flex flex-wrap gap-3 rounded-lg border border-border/60 bg-card/40 px-4 py-2.5 text-xs text-muted-foreground">
          <span className="font-mono text-violet">Wiki:</span>
          <span>{wikiStats.total} pages</span>
          <span className="text-border">|</span>
          <span>{wikiStats.entities} entities</span>
          <span>{wikiStats.concepts} concepts</span>
          <span>{wikiStats.sources} sources</span>
          <span className="text-border">|</span>
          <span>{wikiStats.bridge} bridge-imported</span>
          <span className="text-border">|</span>
          <span>{wikiStats.reports} reports</span>
        </div>
      )}

      {/* Category Tabs */}
      <div className="flex flex-wrap gap-1.5 mb-6">
        <KBCategoryTab
          active={activeCategory === "all"}
          onClick={() => setActiveCategory("all")}
          label="All"
          count={categoryCounts.all}
          color="text-foreground"
        />
        {ALL_CATEGORIES.map((type) => {
          const config = CATEGORY_CONFIG[type];
          if (categoryCounts[type] === 0) return null;
          return (
            <KBCategoryTab
              key={type}
              active={activeCategory === type}
              onClick={() => setActiveCategory(type)}
              label={config.label}
              count={categoryCounts[type]}
              color={config.color}
              icon={config.icon}
            />
          );
        })}
      </div>

      {/* Content */}
      {filteredRecords.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border/80 bg-card/30 px-6 py-14 text-center">
          <BookOpen className="h-8 w-8 text-muted-foreground/30 mx-auto mb-3" />
          <div className="font-mono text-xs tracking-[0.25em] text-muted-foreground">
            {searchQuery ? "NO RESULTS" : "NO RECORDS"}
          </div>
          <div className="mt-3 text-sm text-muted-foreground">
            {searchQuery
              ? `No records match "${searchQuery}".`
              : activeCategory === "all"
              ? "Station Memory is empty. Records are created from tasks, incidents, and manual entries."
              : `No ${CATEGORY_CONFIG[activeCategory as MemoryRecordType]?.label.toLowerCase()} records yet.`}
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="font-mono text-[10px] text-muted-foreground/50 tracking-wider mb-2">
            {filteredRecords.length} RECORD{filteredRecords.length !== 1 ? "S" : ""}
          </div>
          {filteredRecords.map((record) => (
            <KBRecordCard
              key={record.id}
              record={record}
              expanded={expandedId === record.id}
              onToggle={() => setExpandedId(expandedId === record.id ? null : record.id)}
              station={station}
            />
          ))}
        </div>
      )}
    </>
  );
}

// ── KB Category Tab ──────────────────────────────────────────────────────────

function KBCategoryTab({
  active, onClick, label, count, color, icon: Icon,
}: {
  active: boolean; onClick: () => void; label: string; count: number;
  color: string; icon?: typeof BookOpen;
}) {
  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 rounded-md border px-3 py-1.5 font-mono text-[10px] tracking-wider transition-colors ${
        active
          ? "border-violet/50 bg-violet/10 text-violet"
          : "border-border/50 bg-card/30 text-muted-foreground hover:text-foreground hover:border-border"
      }`}
    >
      {Icon && <Icon className={`h-3 w-3 ${active ? color : ""}`} />}
      {label}
      <span className={`text-[9px] ${active ? "" : "text-muted-foreground/50"}`}>{count}</span>
    </button>
  );
}

// ── KB Record Card ───────────────────────────────────────────────────────────

function KBRecordCard({
  record, expanded, onToggle, station,
}: {
  record: StationMemoryRecord; expanded: boolean; onToggle: () => void;
  station: StationMemoryStore;
}) {
  const config = CATEGORY_CONFIG[record.type];
  const Icon = config?.icon || BookOpen;
  const statusColor =
    record.status === "current" || record.status === "active"
      ? "text-[oklch(0.88_0.18 145)]"
      : record.status === "superseded" || record.status === "deprecated"
      ? "text-muted-foreground/50"
      : record.status === "resolved"
      ? "text-[oklch(0.88_0.18 145)]"
      : record.status === "open"
      ? "text-amber"
      : "text-muted-foreground";

  return (
    <div
      className={`rounded-xl border transition-all ${
        expanded
          ? "border-violet/40 bg-violet/5 shadow-[0_0_0_1px_oklch(0.62_0.22_295/0.15)]"
          : "border-border/60 bg-card/30 hover:border-border"
      }`}
    >
      <button onClick={onToggle} className="w-full text-left px-4 py-3 flex items-start gap-3">
        <div className={`mt-0.5 shrink-0 ${config?.color || "text-muted-foreground"}`}>
          <Icon className="h-4 w-4" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm font-medium leading-snug">{record.title}</span>
            {record.status && (
              <span className={`font-mono text-[8px] tracking-wider uppercase ${statusColor}`}>
                {record.status}
              </span>
            )}
          </div>
          <p className="text-xs text-muted-foreground mt-1 line-clamp-2 leading-relaxed">
            {record.summary}
          </p>
          <div className="flex items-center gap-3 mt-2 flex-wrap">
            <span className="flex items-center gap-1 text-[10px] text-muted-foreground/50">
              <Calendar className="h-3 w-3" />{record.date}
            </span>
            <span className="flex items-center gap-1 text-[10px] text-muted-foreground/50">
              <User className="h-3 w-3" />{record.author}
            </span>
            {record.tags.length > 0 && (
              <span className="flex items-center gap-1 text-[10px] text-muted-foreground/50">
                <Tag className="h-3 w-3" />
                {record.tags.slice(0, 3).join(", ")}
                {record.tags.length > 3 && ` +${record.tags.length - 3}`}
              </span>
            )}
            {record.priority && (
              <span className={`font-mono text-[8px] tracking-wider ${
                record.priority === "P1" ? "text-destructive" : record.priority === "P2" ? "text-amber" : "text-muted-foreground"
              }`}>{record.priority}</span>
            )}
          </div>
        </div>
        <div className="shrink-0 text-muted-foreground/40 mt-1">
          {expanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
        </div>
      </button>

      {expanded && (
        <div className="px-4 pb-4 pt-0 border-t border-border/30">
          <div className="pt-4 space-y-4">
            {record.type === "architecture-decision" && (
              <div className="space-y-3">
                {record.decision && <DetailSection label="Decision" value={record.decision} />}
                {record.reason && <DetailSection label="Reason" value={record.reason} />}
                {record.supersedes && <DetailSection label="Supersedes" value={record.supersedes} />}
              </div>
            )}
            {record.type === "lesson-learned" && (
              <div className="space-y-3">
                {record.problem && <DetailSection label="Problem" value={record.problem} color="text-amber" />}
                {record.rootCause && <DetailSection label="Root Cause" value={record.rootCause} color="text-destructive" />}
                {record.fix && <DetailSection label="Fix" value={record.fix} color="text-[oklch(0.88_0.18 145)]" />}
                {record.filesChanged && record.filesChanged.length > 0 && (
                  <div>
                    <div className="font-mono text-[9px] tracking-wider text-muted-foreground/50 mb-1">FILES CHANGED</div>
                    <div className="flex flex-wrap gap-1">
                      {record.filesChanged.map((f) => (
                        <span key={f} className="rounded bg-card/60 border border-border/40 px-2 py-0.5 font-mono text-[10px] text-foreground/70">{f}</span>
                      ))}
                    </div>
                  </div>
                )}
                {record.neverDoThis && (
                  <div className="rounded-lg border border-amber/30 bg-amber/5 px-3 py-2">
                    <div className="font-mono text-[9px] tracking-wider text-amber mb-1">NEVER DO THIS AGAIN</div>
                    <div className="text-xs text-foreground/80">{record.neverDoThis}</div>
                  </div>
                )}
              </div>
            )}
            {record.type === "operational-decision" && (
              <div className="space-y-3">
                {record.decision && <DetailSection label="Decision" value={record.decision} />}
                {record.reason && <DetailSection label="Reason" value={record.reason} />}
                {record.alternativeConsidered && <DetailSection label="Alternative Considered" value={record.alternativeConsidered} />}
                {record.reviewDate && <DetailSection label="Review Date" value={record.reviewDate} />}
              </div>
            )}
            {record.type === "framework-rule" && (
              <div className="space-y-3">
                {record.rule && (
                  <div className="rounded-lg border border-warning/30 bg-warning/5 px-3 py-2">
                    <div className="font-mono text-[9px] tracking-wider text-warning mb-1">RULE</div>
                    <div className="text-xs text-foreground/80 font-medium">{record.rule}</div>
                  </div>
                )}
                {record.reason && <DetailSection label="Reason" value={record.reason} />}
                {record.examples && <DetailSection label="Examples" value={record.examples} />}
              </div>
            )}
            {record.type === "known-issue" && (
              <div className="space-y-3">
                {record.issue && <DetailSection label="Issue" value={record.issue} color="text-amber" />}
                {record.currentState && <DetailSection label="Current State" value={record.currentState} />}
                {record.workaround && (
                  <div className="rounded-lg border border-violet/30 bg-violet/5 px-3 py-2">
                    <div className="font-mono text-[9px] tracking-wider text-violet mb-1">WORKAROUND</div>
                    <div className="text-xs text-foreground/80">{record.workaround}</div>
                  </div>
                )}
              </div>
            )}
            {record.type === "incident-knowledge" && (
              <div className="space-y-3">
                {record.problem && <DetailSection label="Incident" value={record.problem} color="text-destructive" />}
                {record.rootCause && <DetailSection label="Root Cause" value={record.rootCause} />}
                {record.resolution && <DetailSection label="Resolution" value={record.resolution} color="text-[oklch(0.88_0.18 145)]" />}
                {record.prevention && <DetailSection label="Prevention" value={record.prevention} />}
              </div>
            )}
            {record.type === "completed-task-summary" && (
              <div className="space-y-3">
                {record.originalObjective && <DetailSection label="Objective" value={record.originalObjective} />}
                {record.outcome && <DetailSection label="Outcome" value={record.outcome} color="text-[oklch(0.88_0.18 145)]" />}
                {record.lessons && record.lessons.length > 0 && (
                  <div>
                    <div className="font-mono text-[9px] tracking-wider text-muted-foreground/50 mb-1">LESSONS</div>
                    <ul className="space-y-1">
                      {record.lessons.map((l, i) => (
                        <li key={i} className="text-xs text-foreground/70 flex items-start gap-1.5">
                          <span className="text-muted-foreground/30 mt-0.5">•</span>{l}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}

            {/* Related Records */}
            <KBRelatedRecords recordId={record.id} station={station} onNavigate={() => {}} />

            {/* Tags */}
            {record.tags.length > 0 && (
              <div className="pt-2 border-t border-border/20">
                <div className="flex flex-wrap gap-1">
                  {record.tags.map((tag) => (
                    <Link
                      key={tag}
                      to="/memory"
                      search={{ tab: "knowledge", q: tag }}
                      className="rounded-full border border-border/30 bg-card/30 px-2 py-0.5 font-mono text-[9px] text-muted-foreground/60 hover:text-foreground hover:border-border/60 transition-colors"
                    >
                      {tag}
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* Metadata */}
            <div className="pt-2 border-t border-border/20 flex items-center gap-3 text-[9px] text-muted-foreground/40">
              <span>ID: {record.id}</span>
              <span>Source: {record.source}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Detail Section ───────────────────────────────────────────────────────────

function DetailSection({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div>
      <div className="font-mono text-[9px] tracking-wider text-muted-foreground/50 mb-1">{label.toUpperCase()}</div>
      <div className={`text-xs leading-relaxed ${color || "text-foreground/80"}`}>{value}</div>
    </div>
  );
}

// ── Related Records ──────────────────────────────────────────────────────────

function KBRelatedRecords({ recordId, station, onNavigate }: { recordId: string; station: StationMemoryStore; onNavigate: (id: string) => void; }) {
  const record = getMemoryRecord(station, recordId);
  if (!record || !record.relatedIds || record.relatedIds.length === 0) return null;

  const related = getRelatedRecords(station, record);
  if (related.length === 0) return null;

  return (
    <div>
      <div className="font-mono text-[9px] tracking-wider text-muted-foreground/50 mb-1.5">RELATED</div>
      <div className="flex flex-wrap gap-1.5">
        {related.map((r) => {
          const config = CATEGORY_CONFIG[r.type];
          return (
            <button
              key={r.id}
              onClick={() => {
                onNavigate(r.id);
              }}
              className="inline-flex items-center gap-1 rounded-md border border-border/40 bg-card/40 px-2 py-1 text-[10px] text-foreground/60 hover:text-foreground hover:border-border/60 transition-colors"
            >
              {config && <config.icon className={`h-2.5 w-2.5 ${config.color}`} />}
              <span className="truncate max-w-[120px]">{r.title}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ── Shared Tab Button ────────────────────────────────────────────────────────

function TabBtn({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-md border px-4 py-2 text-sm font-medium transition-colors ${
        active
          ? "border-violet/60 bg-violet/15 text-foreground shadow-[0_0_0_1px_oklch(0.62_0.22_295/0.3)]"
          : "border-border bg-card/40 text-muted-foreground hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );
}
