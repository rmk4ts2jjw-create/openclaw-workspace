// src/routes/timeline.tsx
// Timeline — Unified Event Model showing all station events
import { useState, useMemo } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/PageHeader";
import {
  getTimelineEvents,
  getTimelineSummary,
  type TimelineEvent,
  type TimelineEventType,
} from "@/lib/server-data/timeline-data";
import {
  AlertTriangle,
  ArrowRight,
  Bot,
  CheckCircle2,
  Clock,
  FileText,
  OctagonX,
  Play,
  RotateCcw,
  Server,
  Shield,
  XCircle,
  Zap,
} from "lucide-react";

export const Route = createFileRoute("/timeline")({
  head: () => ({ meta: [{ title: "Timeline — Mission Control" }] }),
  loader: async () => {
    const events = await getTimelineEvents();
    const summary = await getTimelineSummary();
    return { events, summary };
  },
  component: TimelinePage,
});

const TYPE_CONFIG: Record<string, { icon: typeof Zap; color: string; bg: string }> = {
  task_created: { icon: FileText, color: "text-cyan", bg: "bg-cyan/10" },
  task_started: { icon: Play, color: "text-violet", bg: "bg-violet/10" },
  task_completed: { icon: CheckCircle2, color: "text-[oklch(0.88_0.18_145)]", bg: "bg-[oklch(0.88_0.18_145)]/10" },
  task_stalled: { icon: RotateCcw, color: "text-amber-400", bg: "bg-amber-400/10" },
  incident_created: { icon: AlertTriangle, color: "text-red-400", bg: "bg-red-400/10" },
  incident_status_change: { icon: Shield, color: "text-amber-400", bg: "bg-amber-400/10" },
  incident_resolved: { icon: CheckCircle2, color: "text-[oklch(0.88_0.18_145)]", bg: "bg-[oklch(0.88_0.18_145)]/10" },
  cron_success: { icon: CheckCircle2, color: "text-[oklch(0.88_0.18_145)]", bg: "bg-[oklch(0.88_0.18_145)]/10" },
  cron_failure: { icon: XCircle, color: "text-red-400", bg: "bg-red-400/10" },
  system_health: { icon: Server, color: "text-cyan", bg: "bg-cyan/10" },
};

const SOURCE_FILTERS = [
  { key: "all", label: "All Events" },
  { key: "task", label: "Tasks" },
  { key: "incident", label: "Incidents" },
  { key: "cron", label: "Crons" },
] as const;

function EventCard({ event }: { event: TimelineEvent }) {
  const cfg = TYPE_CONFIG[event.type] || TYPE_CONFIG["task_created"];
  const Icon = cfg.icon;
  const time = new Date(event.ts);
  const timeStr = time.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
  const dateStr = time.toLocaleDateString("en-GB", { day: "numeric", month: "short" });

  return (
    <div className={`flex items-start gap-3 rounded-lg border border-border/40 bg-card/20 p-3 ${event.severity === "critical" ? "border-red-400/30" : event.severity === "warning" ? "border-amber-400/20" : ""}`}>
      <div className={`rounded-md p-1.5 ${cfg.bg} shrink-0 mt-0.5`}>
        <Icon className={`h-3.5 w-3.5 ${cfg.color}`} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-start justify-between gap-2">
          <span className="text-sm font-medium leading-tight">{event.title}</span>
          <span className="text-[10px] font-mono text-muted-foreground/50 shrink-0">{dateStr} {timeStr}</span>
        </div>
        {event.description && event.description !== event.title && (
          <p className="mt-0.5 text-xs text-muted-foreground/70 leading-snug">{event.description}</p>
        )}
        <div className="mt-1 flex items-center gap-2 text-[10px] text-muted-foreground/50">
          {event.actor && <span>{event.actor}</span>}
          {event.entityId && event.entityUrl && (
            <a href={event.entityUrl} className="flex items-center gap-0.5 hover:text-violet transition-colors">
              <ArrowRight className="h-2.5 w-2.5" />
              {event.entityId}
            </a>
          )}
          {event.metadata?.severity && (
            <span className="font-mono">{event.metadata.severity}</span>
          )}
        </div>
      </div>
    </div>
  );
}

function TimelinePage() {
  const { events, summary } = Route.useLoaderData() as {
    events: TimelineEvent[];
    summary: Awaited<ReturnType<typeof getTimelineSummary>>;
  };
  const [sourceFilter, setSourceFilter] = useState<string>("all");

  const filtered = useMemo(() => {
    if (sourceFilter === "all") return events;
    return events.filter((e) => e.source === sourceFilter);
  }, [events, sourceFilter]);

  // Group by date
  const grouped = useMemo(() => {
    const groups: Record<string, TimelineEvent[]> = {};
    for (const e of filtered) {
      const date = new Date(e.ts).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
      if (!groups[date]) groups[date] = [];
      groups[date].push(e);
    }
    return groups;
  }, [filtered]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Timeline"
        meta={`${summary.total} events · ${summary.critical} critical · ${summary.warnings} warnings`}
        icon="⏱"
      />

      {/* Source filters */}
      <div className="flex flex-wrap gap-2">
        {SOURCE_FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setSourceFilter(f.key)}
            className={`rounded-lg border px-3 py-1.5 text-xs transition-colors ${
              sourceFilter === f.key
                ? "border-violet/50 bg-violet/10 text-violet"
                : "border-border/60 bg-card/20 text-muted-foreground hover:border-border"
            }`}
          >
            {f.label}
            <span className="ml-1.5 font-mono text-[10px] opacity-70">
              {f.key === "all" ? summary.total : summary.bySource[f.key] || 0}
            </span>
          </button>
        ))}
      </div>

      {/* Timeline */}
      <div className="space-y-6">
        {Object.entries(grouped).map(([date, dateEvents]) => (
          <div key={date}>
            <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-sm py-2 mb-3">
              <h3 className="font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground/70">{date}</h3>
            </div>
            <div className="space-y-2 ml-2 border-l border-border/30 pl-4">
              {dateEvents.map((event) => (
                <EventCard key={event.id} event={event} />
              ))}
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12 text-muted-foreground/50 text-sm">
          No events match the current filter
        </div>
      )}
    </div>
  );
}
