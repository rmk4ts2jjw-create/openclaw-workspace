import { useState, useEffect } from "react";
import { workloadToLevel, WorkloadLevel } from "@/lib/workload";
import type { AgentStatus } from "@/lib/server-data-types";

export interface AgentStatusWithLevel extends AgentStatus {
  workloadLevel: WorkloadLevel;
}

export function useAgentStatus(): AgentStatusWithLevel[] {
  const [agents, setAgents] = useState<AgentStatusWithLevel[]>([]);

  useEffect(() => {
    async function fetchAgents() {
      try {
        const res = await fetch("/api/agent-status");
        if (!res.ok) {
          console.warn("[useAgentStatus] Failed to fetch agent status:", res.status);
          return;
        }
        const data: AgentStatus[] = await res.json();
        const withLevel: AgentStatusWithLevel[] = data.map(agent => ({
          ...agent,
          workloadLevel: workloadToLevel(Math.min(100, agent.tasksActive * 10)),
        }));
        setAgents(withLevel);
      } catch (err) {
        console.error("[useAgentStatus] Error fetching agent status:", err);
      }
    }

    fetchAgents();
    const interval = setInterval(fetchAgents, 10000);
    return () => clearInterval(interval);
  }, []);

  return agents;
}
