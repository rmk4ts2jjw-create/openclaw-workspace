import { useTaskStream } from "./useTaskStream";

export function useBacklogTasks() {
  const { tickerTasks, pendingTasks } = useTaskStream();
  return { tickerTasks, pendingTasks };
}
