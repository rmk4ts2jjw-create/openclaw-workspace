import { useState, useEffect } from "react";
import { workloadToLevel, WorkloadLevel } from "@/lib/workload";
import type { AgentStatus } from "@/lib/server-data-types";

export interface AgentStatusWithLevel extends AgentStatus {
  workloadLevel: WorkloadLevel;
}

export function useAgentNetwork(): AgentStatusWithLevel[] {
  const [agents, setAgents] = useState<AgentStatusWithLevel[]>([]);

  useEffect(() => {
    async function fetchNetwork() {
      try {
        const res = await fetch("/api/agents/network");
        if (!res.ok) {
          console.warn("[useAgentNetwork] Failed to fetch agent network:", res.status);
          return;
        }
        const data: AgentStatus[] = await res.json();
        const withLevel: AgentStatusWithLevel[] = data.map(agent => ({
          ...agent,
          workloadLevel: workloadToLevel(Math.min(100, agent.tasksActive * 10)),
        }));
        setAgents(withLevel);
      } catch (err) {
        console.error("[useAgentNetwork] Error fetching agent network:", err);
      }
    }

    fetchNetwork();
    const interval = setInterval(fetchNetwork, 15000);
    return () => clearInterval(interval);
  }, []);

  return agents;
}
