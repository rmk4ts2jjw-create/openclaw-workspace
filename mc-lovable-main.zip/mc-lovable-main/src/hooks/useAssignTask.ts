import { useTaskStream } from "./useTaskStream";

export function useAssignTask() {
  const {
    speechBubbles,
    agentFlash,
    energyBoosts,
    assignTask,
    boostEnergy,
    dismissTask,
    logEvent,
  } = useTaskStream();
  return {
    speechBubbles,
    agentFlash,
    energyBoosts,
    assignTask,
    boostEnergy,
    dismissTask,
    logEvent,
  };
}
