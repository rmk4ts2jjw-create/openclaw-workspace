import { useTaskStream } from "./useTaskStream";

export function useEventLog() {
  const { recentEvents, logEvent } = useTaskStream();
  return { recentEvents, addLocalEvent: logEvent };
}
