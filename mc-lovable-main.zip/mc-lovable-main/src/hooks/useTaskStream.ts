import { useState, useEffect, useRef, useCallback } from "react";
import type { Task, ActivityEvent } from "@/lib/server-data-types";

type LogEventType = ActivityEvent["type"] | "assigned" | "intercepted" | "boosted" | "celebrated";
import { workloadToLevel, WorkloadLevel } from "@/lib/workload";

// Types mirroring the original useTaskStream
export interface TaskStreamState {
  tickerTasks: Task[];
  pendingTasks: Task[];
  recentEvents: LogEvent[];
  speechBubbles: Partial<Record<string, string>>;
  agentFlash: Partial<Record<string, "accept" | "reject">>;
  energyBoosts: Partial<Record<string, boolean>>;
  assignTask: (taskId: string, toAgent: string) => Promise<void>;
  boostEnergy: (agentId: string) => Promise<void>;
  dismissTask: (taskId: string) => Promise<void>;
  logEvent: (event: Omit<LogEvent, "id" | "ts">) => Promise<void>;
}

export interface LogEvent {
  id: string;
  type: LogEventType;
  agentId?: string;
  message: string;
  icon: string;
  ts: number;
}

// Helper to fetch JSON with error handling
async function fetchJSON<T>(url: string): Promise<T | null> {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

// Helper to post JSON
async function postJSON(url: string, data: any): Promise<boolean> {
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    return res.ok;
  } catch {
    return false;
  }
}

function activityToLogEvent(event: ActivityEvent): LogEvent {
  return {
    id: event.id,
    type: event.type,
    agentId: event.actor,
    message: event.message,
    icon: event.type === "cron" ? "⚡" : event.type === "incident" ? "⚠️" : event.type === "memory" ? "🧠" : "📋",
    ts: new Date(event.ts).getTime(),
  };
}

export function useTaskStream(): TaskStreamState {
  const [tickerTasks, setTickerTasks] = useState<Task[]>([]);
  const [pendingTasks, setPendingTasks] = useState<Task[]>([]);
  const [recentEvents, setRecentEvents] = useState<LogEvent[]>([]);
  const [speechBubbles, setSpeechBubbles] = useState<Partial<Record<string, string>>>({});
  const [agentFlash, setAgentFlash] = useState<Partial<Record<string, "accept" | "reject">>>({});
  const [energyBoosts, setEnergyBoosts] = useState<Partial<Record<string, boolean>>>({});

  const taskRegistryRef = useRef<Map<string, Task>>(new Map());
  const flashTimers = useRef<Partial<Record<string, ReturnType<typeof setTimeout>>>>({});
  const bubbleTimers = useRef<Partial<Record<string, ReturnType<typeof setTimeout>>>>({});
  const boostTimers = useRef<Partial<Record<string, ReturnType<typeof setTimeout>>>>({});
  const autoTimers = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());

  // Register existing tasks in registry
  const registerTasks = useCallback((tasks: Task[]) => {
    tasks.forEach(t => taskRegistryRef.current.set(t.id, t));
  }, []);

  // Seed initial fetch
  useEffect(() => {
    async function fetchInitial() {
      const [tasksResp, eventsResp] = await Promise.all([
        fetchJSON<Task[]>("/api/tasks"),
        fetchJSON<ActivityEvent[]>("/api/events"),
      ]);
      if (tasksResp) {
        setTickerTasks(tasksResp.filter(t => t.status === "in_progress"));
        setPendingTasks(tasksResp.filter(t => t.status === "backlog"));
        registerTasks(tasksResp);
      }
      if (eventsResp) {
        setRecentEvents(eventsResp.map(activityToLogEvent).slice(0, 24));
      }
    }
    fetchInitial();
  }, []);

  // Periodic polling for tasks and events
  useEffect(() => {
    async function pollTasks() {
      const tasks = await fetchJSON<Task[]>("/api/tasks");
      if (tasks) {
        setTickerTasks(tasks.filter(t => t.status === "in_progress"));
        setPendingTasks(tasks.filter(t => t.status === "backlog"));
        registerTasks(tasks);
      }
    }
    async function pollEvents() {
      const events = await fetchJSON<ActivityEvent[]>("/api/events");
      if (events) {
        setRecentEvents(prev => {
          const byId = new Map<string, LogEvent>();
          [...events.map(activityToLogEvent), ...prev].forEach((event) => byId.set(event.id, event));
          return Array.from(byId.values())
            .sort((a, b) => b.ts - a.ts)
            .slice(0, 24);
        });
      }
    }
    const taskInterval = setInterval(pollTasks, 5000);
    const eventInterval = setInterval(pollEvents, 5000);
    return () => {
      clearInterval(taskInterval);
      clearInterval(eventInterval);
    };
  }, []);

  const addEvent = useCallback(async (event: Omit<LogEvent, "id" | "ts">) => {
    const newEvent: LogEvent = { ...event, id: `e${Date.now()}-${Math.random()}`, ts: Date.now() };
    setRecentEvents(prev => [newEvent, ...prev].slice(0, 24));
    // Also persist to backend? The original logEvent didn't persist; we'll just keep in state.
    // Optionally we could POST to /api/events, but we'll skip for now.
  }, []);

  const fireFlash = useCallback((agentId: string, kind: "accept" | "reject") => {
    setAgentFlash(prev => ({ ...prev, [agentId]: kind }));
    if (flashTimers.current[agentId]) clearTimeout(flashTimers.current[agentId]);
    flashTimers.current[agentId] = setTimeout(() => {
      setAgentFlash(prev => { const n = { ...prev }; delete n[agentId]; return n; });
    }, 750);
  }, []);

  const fireBubble = useCallback((agentId: string, title: string) => {
    setSpeechBubbles(prev => ({ ...prev, [agentId]: title }));
    if (bubbleTimers.current[agentId]) clearTimeout(bubbleTimers.current[agentId]);
    bubbleTimers.current[agentId] = setTimeout(() => {
      setSpeechBubbles(prev => { const n = { ...prev }; delete n[agentId]; return n; });
    }, 2600);
  }, []);

  const removeTask = useCallback(async (taskId: string) => {
    setTickerTasks(prev => prev.filter(t => t.id !== taskId));
    setPendingTasks(prev => prev.filter(t => t.id !== taskId));
    taskRegistryRef.current.delete(taskId);
    // Also persist removal? We'll treat removal as setting status to "done" or something.
    // For simplicity, we'll just remove from local state; the periodic poll will correct it.
    // If we want to persist, we could PATCH the task to status "done".
    // We'll leave it as local only for now.
  }, []);

  const assignTask = useCallback(async (taskId: string, toAgent: string) => {
    const task = taskRegistryRef.current.get(taskId);
    if (!task) return;
    // Optimistic update: remove from lists
    removeTask(taskId);
    // Prepare updated task
    const updatedTask: Task = {
      ...task,
      assignee: toAgent,
      status: "in_progress" as const,
      lastActivity: new Date().toISOString(),
      currentStep: `Assigned to ${toAgent}`,
      startedAt: new Date().toISOString(),
    };
    // Attempt to PATCH the task
    const success = await postJSON(`/api/tasks/${taskId}`, {
      status: "in_progress",
      assignee: toAgent,
      lastActivity: updatedTask.lastActivity,
      currentStep: updatedTask.currentStep,
      startedAt: updatedTask.startedAt,
    });
    if (!success) {
      // Rollback: revert optimistic removal
      setTickerTasks(prev => [...prev, task]);
      setPendingTasks(prev => [...prev, task]);
      taskRegistryRef.current.set(taskId, task);
      throw new Error(`Failed to assign task ${taskId}`);
    }
    // Update registry with patched task (server may have updated fields)
    taskRegistryRef.current.set(taskId, updatedTask);
    // Trigger speech bubble and flash
    fireBubble(toAgent, task.title);
    fireFlash(toAgent, "accept");
    // Log event
    await addEvent({
      type: "assigned",
      agentId: toAgent,
      message: `📋 Agent ${toAgent} assigned to "${task.title}"`,
      icon: "📋",
    });
  }, [removeTask, fireBubble, fireFlash, addEvent]);

  const boostEnergy = useCallback(async (agentId: string) => {
    // Optimistic update
    setEnergyBoosts(prev => ({ ...prev, [agentId]: true }));
    fireBubble(agentId, "☕ Refueled!");
    if (boostTimers.current[agentId]) clearTimeout(boostTimers.current[agentId]);
    boostTimers.current[agentId] = setTimeout(() => {
      setEnergyBoosts(prev => { const n = { ...prev }; delete n[agentId]; return n; });
    }, 9000);
    // Persist? We'll just fire an event; no backend change needed for energy boost.
    await addEvent({
      type: "boosted",
      agentId,
      message: `☕ ${agentId} refueled — energy restored`,
      icon: "☕",
    });
  }, [fireBubble, addEvent]);

  const dismissTask = useCallback(async (taskId: string) => {
    const task = taskRegistryRef.current.get(taskId);
    if (!task) return;
    // Optimistic update: remove from lists
    removeTask(taskId);
    // Persist as done? We'll just remove locally; periodic poll will fix.
    // For better UX, we could PATCH to status "done".
    const success = await postJSON(`/api/tasks/${taskId}`, {
      status: "done" as const,
      lastActivity: new Date().toISOString(),
      completedAt: new Date().toISOString(),
    });
    if (!success) {
      // Rollback
      setTickerTasks(prev => [...prev, task]);
      setPendingTasks(prev => [...prev, task]);
      taskRegistryRef.current.set(taskId, task);
      throw new Error(`Failed to dismiss task ${taskId}`);
    }
    // Log event
    await addEvent({
      type: "intercepted",
      message: `↩ Task intercepted: "${task.title}"`,
      icon: "↩",
    });
  }, [removeTask, addEvent]);

  // Spawn new tasks every 3-6 seconds (simulate incoming tasks)
  useEffect(() => {
    const spawnNext = () => {
      // In a real system, we would fetch new tasks from the backend; for now we just simulate.
      // We'll skip spawning new tasks to avoid creating fake data.
      // Instead we rely on the periodic poll to get real tasks.
      return setTimeout(spawnNext, 3000 + Math.random() * 3000);
    };
    const timer = setTimeout(spawnNext, 2000);
    return () => clearTimeout(timer);
  }, []);

  return {
    tickerTasks,
    pendingTasks,
    recentEvents,
    speechBubbles,
    agentFlash,
    energyBoosts,
    assignTask,
    boostEnergy,
    dismissTask,
    logEvent: addEvent,
  };
}
