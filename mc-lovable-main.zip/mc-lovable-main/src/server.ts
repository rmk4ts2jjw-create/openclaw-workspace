import "./lib/error-capture";

import { consumeLastCapturedError } from "./lib/error-capture";
import { renderErrorPage } from "./lib/error-page";

type ServerEntry = {
  fetch: (request: Request, env: unknown, ctx: unknown) => Promise<Response> | Response;
};

let serverEntryPromise: Promise<ServerEntry> | undefined;

async function getServerEntry(): Promise<ServerEntry> {
  if (!serverEntryPromise) {
    serverEntryPromise = import("@tanstack/react-start/server-entry").then(
      (m) => ((m as { default?: ServerEntry }).default ?? (m as unknown as ServerEntry)),
    );
  }
  return serverEntryPromise;
}

function addNoCacheHeaders(response: Response): Response {
  response.headers.set("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
  response.headers.set("Pragma", "no-cache");
  response.headers.set("Expires", "0");
  return response;
}

function brandedErrorResponse(): Response {
  return addNoCacheHeaders(new Response(renderErrorPage(), {
    status: 500,
    headers: { "content-type": "text/html; charset=utf-8" },
  }));
}

function isCatastrophicSsrErrorBody(body: string, responseStatus: number): boolean {
  let payload: unknown;
  try {
    payload = JSON.parse(body);
  } catch {
    return false;
  }

  if (!payload || Array.isArray(payload) || typeof payload !== "object") {
    return false;
  }

  const fields = payload as Record<string, unknown>;
  const expectedKeys = new Set(["message", "status", "unhandled"]);
  if (!Object.keys(fields).every((key) => expectedKeys.has(key))) {
    return false;
  }

  return (
    fields.unhandled === true &&
    fields.message === "HTTPError" &&
    (fields.status === undefined || fields.status === responseStatus)
  );
}

// h3 swallows in-handler throws into a normal 500 Response with body
// {"unhandled":true,"message":"HTTPError"} — try/catch alone never fires for those.
async function normalizeCatastrophicSsrResponse(response: Response): Promise<Response> {
  if (response.status < 500) return response;
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return response;

  const body = await response.clone().text();
  if (!isCatastrophicSsrErrorBody(body, response.status)) {
    return response;
  }

  console.error(consumeLastCapturedError() ?? new Error(`h3 swallowed SSR error: ${body}`));
  return brandedErrorResponse();
}

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";

async function handleApiRequest(request: Request, url: URL): Promise<Response | null> {
  if (url.pathname === "/api/save-tasks" && request.method === "POST") {
    try {
      const clientTasks = await request.json();
      const { writeFileSync, readFileSync, existsSync, mkdirSync, renameSync } = await import("node:fs");
      const { join } = await import("node:path");
      const dir = join(WORKSPACE, "data");
      if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
      const tasksPath = join(dir, "tasks.json");

      // Merge: read current disk state, preserve disk-only tasks
      let diskTasks: Record<string, unknown>[] = [];
      try {
        if (existsSync(tasksPath)) {
          const raw = JSON.parse(readFileSync(tasksPath, "utf-8"));
          diskTasks = Array.isArray(raw) ? raw : Object.entries(raw).map(([id, t]: [string, any]) => ({ ...t, id }));
        }
      } catch { /* corrupted, use client as base */ }

      const clientIds = new Set(clientTasks.map((t: Record<string, unknown>) => t.id as string));
      const diskOnlyTasks = diskTasks.filter((t) => !clientIds.has(t.id as string));
      const diskTaskMap = new Map(diskTasks.map((t) => [t.id as string, t] as const));

      // For tasks both client and disk know, protect critical disk-side fields
      // that the client may have lost (e.g., stalledAt set by heartbeat/agent)
      const PROTECTED_FIELDS = ['stalledAt', 'stallNotified', 'dispatchCount'];
      const mergedClientTasks = clientTasks.map((ct: Record<string, unknown>) => {
        const dt = diskTaskMap.get(ct.id as string);
        if (!dt) return ct;
        const merged = { ...ct };
        for (const field of PROTECTED_FIELDS) {
          if (dt[field] && !ct[field]) {
            merged[field] = dt[field];
          }
        }
        return merged;
      });

      const merged = [...mergedClientTasks, ...diskOnlyTasks];

      // Atomic write
      const tmpPath = tasksPath + ".tmp";
      writeFileSync(tmpPath, JSON.stringify(merged, null, 2), "utf-8");
      renameSync(tmpPath, tasksPath);
      console.log(`[api/save-tasks] Merged ${clientTasks.length} client + ${diskOnlyTasks.length} disk-only = ${merged.length} total`);
      return new Response(JSON.stringify({ ok: true }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      console.error("[api/save-tasks] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }
  }
  if (url.pathname === "/api/dispatch" && request.method === "POST") {
    try {
      const { taskId, title, assignee } = await request.json();
      const { writeFileSync, readFileSync, existsSync, mkdirSync } = await import("node:fs");
      const { join } = await import("node:path");
      const dir = join(WORKSPACE, "data");
      if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
      const queuePath = join(dir, "queue.json");
      let queue: unknown[] = [];
      try { queue = JSON.parse(readFileSync(queuePath, "utf-8")); } catch { /* empty */ }
      const item = {
        id: `queue-${Date.now().toString(36)}`,
        taskId,
        title,
        assignee,
        dispatchedAt: new Date().toISOString(),
        status: "pending",
      };
      queue.push(item);
      writeFileSync(queuePath, JSON.stringify(queue, null, 2), "utf-8");
      console.log("[api/dispatch] Dispatched task:", title, "to", assignee);
      return new Response(JSON.stringify({ ok: true, queueId: item.id }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      console.error("[api/dispatch] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }
  }
  if (url.pathname === "/api/crons" && request.method === "GET") {
    try {
      const { execSync } = await import("node:child_process");
      const { join } = await import("node:path");
      const CRON_DB = join(WORKSPACE, "..", "state", "openclaw.sqlite");
      const CRON_STORE = "/Users/spacemonkey/.openclaw/cron/jobs.json";
      const sql = `SELECT job_id, name, enabled, schedule_expr, schedule_tz, payload_message, payload_kind, state_json, job_json FROM cron_jobs WHERE store_key = '${CRON_STORE}' ORDER BY sort_order ASC, updated_at DESC;`;
      const output = execSync(`/usr/bin/sqlite3 -json "${CRON_DB}" "${sql}"`, {
        encoding: "utf-8",
        timeout: 5000,
        env: { ...process.env, PATH: "/usr/bin:/bin" },
      });
      const rows = JSON.parse(output) as Record<string, unknown>[];
      const mapped = rows.map((row) => {
        const state = JSON.parse(String(row.state_json || "{}")) as Record<string, unknown>;
        const job = JSON.parse(String(row.job_json || "{}")) as Record<string, unknown>;
        const schedule = (job.schedule || {}) as Record<string, unknown>;
        const payload = (job.payload || {}) as Record<string, unknown>;
        return {
          id: String(row.job_id || ""),
          name: String(row.name || "Unknown"),
          schedule: String(schedule.expr || row.schedule_expr || ""),
          enabled: row.enabled === 1 || row.enabled === true,
          status: String(state.lastRunStatus || "ok"),
          lastError: String(state.lastError || ""),
          lastErrorReason: String(state.lastDiagnosticSummary || state.lastError || ""),
          consecutiveErrors: Number(state.consecutiveErrors || 0),
          lastRun: state.lastRunAtMs ? new Date(Number(state.lastRunAtMs)).toISOString() : "—",
          nextRun: state.nextRunAtMs ? new Date(Number(state.nextRunAtMs)).toISOString() : "—",
          message: String(payload.message || "").slice(0, 150),
        };
      });
      return new Response(JSON.stringify(mapped), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      console.error("[api/crons] Error:", err);
      return new Response(JSON.stringify([]), {
        headers: { "Content-Type": "application/json" },
      });
    }
  }
  if (url.pathname === "/api/cron-errors" && request.method === "GET") {
    try {
      const { readFileSync, existsSync } = await import("node:fs");
      const { join } = await import("node:path");
      const errorsPath = join(WORKSPACE, "data", "cron-errors.json");
      if (!existsSync(errorsPath)) {
        return new Response(JSON.stringify([]), { headers: { "Content-Type": "application/json" } });
      }
      const errors = JSON.parse(readFileSync(errorsPath, "utf-8"));
      return new Response(JSON.stringify(errors), { headers: { "Content-Type": "application/json" } });
    } catch (err) {
      return new Response(JSON.stringify([]), { headers: { "Content-Type": "application/json" } });
    }
  }
  if (url.pathname === "/api/cron-errors" && request.method === "POST") {
    try {
      const { errorId, status } = await request.json() as { errorId: string; status: string };
      const { writeFileSync, readFileSync, existsSync, mkdirSync } = await import("node:fs");
      const { join } = await import("node:path");
      const errorsPath = join(WORKSPACE, "data", "cron-errors.json");
      const dir = join(WORKSPACE, "data");
      if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
      let errors: Record<string, unknown>[] = [];
      try { errors = JSON.parse(readFileSync(errorsPath, "utf-8")); } catch { /* empty */ }
      const idx = errors.findIndex((e) => e.id === errorId);
      if (idx !== -1) {
        errors[idx].status = status;
        errors[idx].updatedAt = new Date().toISOString();
      } else {
        errors.push({ id: errorId, status, updatedAt: new Date().toISOString() });
      }
      writeFileSync(errorsPath, JSON.stringify(errors, null, 2), "utf-8");
      return new Response(JSON.stringify({ ok: true }), { headers: { "Content-Type": "application/json" } });
    } catch (err) {
      console.error("[api/cron-errors] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), { status: 500, headers: { "Content-Type": "application/json" } });
    }
  }
  if (url.pathname === "/api/cron-errors/update" && request.method === "POST") {
    try {
      const { errorId, status } = await request.json() as { errorId: string; status: string };
      const { writeFileSync, readFileSync, existsSync, mkdirSync } = await import("node:fs");
      const { join } = await import("node:path");
      const errorsPath = join(WORKSPACE, "data", "cron-errors.json");
      const dir = join(WORKSPACE, "data");
      if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
      let errors: Record<string, unknown>[] = [];
      try { errors = JSON.parse(readFileSync(errorsPath, "utf-8")); } catch { /* empty */ }
      const idx = errors.findIndex((e) => e.id === errorId);
      if (idx !== -1) {
        errors[idx].status = status;
        errors[idx].updatedAt = new Date().toISOString();
      } else {
        errors.push({ id: errorId, status, updatedAt: new Date().toISOString() });
      }
      writeFileSync(errorsPath, JSON.stringify(errors, null, 2), "utf-8");
      console.log("[api/cron-errors/update] Updated:", errorId, "->", status);
      return new Response(JSON.stringify({ ok: true }), { headers: { "Content-Type": "application/json" } });
    } catch (err) {
      console.error("[api/cron-errors/update] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), { status: 500, headers: { "Content-Type": "application/json" } });
    }
  }
  if (url.pathname === "/api/incidents/update" && request.method === "POST") {
    try {
      const { id, actions } = await request.json() as { id: string; actions: unknown[] };
      const { writeFileSync, readFileSync, existsSync } = await import("node:fs");
      const { join } = await import("node:path");
      const incidentsPath = join(WORKSPACE, "data", "incidents.json");
      if (!existsSync(incidentsPath)) {
        return new Response(JSON.stringify({ ok: false, error: "incidents.json not found" }), { status: 404, headers: { "Content-Type": "application/json" } });
      }
      const incidents = JSON.parse(readFileSync(incidentsPath, "utf-8")) as Record<string, unknown>[];
      const idx = incidents.findIndex((i) => i.id === id);
      if (idx !== -1) {
        // Merge: only update the actions array, preserve all other fields
        incidents[idx] = { ...incidents[idx], actions };
        writeFileSync(incidentsPath, JSON.stringify(incidents, null, 2), "utf-8");
        console.log("[api/incidents/update] Updated actions for incident:", id);
      }
      return new Response(JSON.stringify({ ok: true }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      console.error("[api/incidents/update] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }
  }
  if (url.pathname === "/api/incidents/timeline" && request.method === "POST") {
    try {
      const { incidentId, message, actor } = await request.json() as {
        incidentId: string; message: string; actor?: string;
      };
      if (!incidentId || !message) {
        return new Response(JSON.stringify({ ok: false, error: "incidentId and message required" }), {
          status: 400, headers: { "Content-Type": "application/json" },
        });
      }
      const { writeFileSync, readFileSync, existsSync } = await import("node:fs");
      const { join } = await import("node:path");
      const incidentsPath = join(WORKSPACE, "data", "incidents.json");
      if (!existsSync(incidentsPath)) {
        return new Response(JSON.stringify({ ok: false, error: "incidents.json not found" }), {
          status: 404, headers: { "Content-Type": "application/json" },
        });
      }
      const incidents = JSON.parse(readFileSync(incidentsPath, "utf-8")) as Record<string, unknown>[];
      const idx = incidents.findIndex((i) => i.id === incidentId);
      if (idx === -1) {
        return new Response(JSON.stringify({ ok: false, error: `Incident ${incidentId} not found` }), {
          status: 404, headers: { "Content-Type": "application/json" },
        });
      }
      const inc = incidents[idx];
      const timeline = (inc.timeline as Record<string, unknown>[]) || [];
      const now = new Date().toISOString();
      timeline.push({ ts: now, message, actor: actor || "system" });
      inc.timeline = timeline;
      inc.lastActivity = now;
      writeFileSync(incidentsPath, JSON.stringify(incidents, null, 2), "utf-8");
      console.log("[api/incidents/timeline] Appended to", incidentId, ":", message.slice(0, 60));
      return new Response(JSON.stringify({ ok: true }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      console.error("[api/incidents/timeline] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500, headers: { "Content-Type": "application/json" },
      });
    }
  }
  if (url.pathname === "/api/tasks/add" && request.method === "POST") {
    try {
      const newTask = await request.json();
      const { writeFileSync, readFileSync, existsSync, mkdirSync } = await import("node:fs");
      const { join } = await import("node:path");
      const dir = join(WORKSPACE, "data");
      if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
      const tasksPath = join(dir, "tasks.json");
      let tasks: unknown[] = [];
      try {
        const raw = JSON.parse(readFileSync(tasksPath, "utf-8"));
        tasks = Array.isArray(raw) ? raw : Object.entries(raw).map(([id, t]: [string, any]) => ({ ...t, id }));
      } catch { /* empty */ }
      // Check for duplicate — same title + assignee already exists
      const isDuplicate = (tasks as Record<string, unknown>[]).some(
        (t) => t.title === newTask.title && t.assignee === newTask.assignee
      );
      if (isDuplicate) {
        console.log("[api/tasks/add] Skipped duplicate:", newTask.title);
        return new Response(JSON.stringify({ ok: false, message: "Duplicate task — already exists" }), {
          headers: { "Content-Type": "application/json" },
        });
      }
      tasks.unshift(newTask);
      writeFileSync(tasksPath, JSON.stringify(tasks, null, 2), "utf-8");
      console.log("[api/tasks/add] Added task:", newTask.title);
      return new Response(JSON.stringify({ ok: true }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      console.error("[api/tasks/add] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }
  }
  if (url.pathname === "/api/station-memory/suggest" && request.method === "GET") {
    try {
      const sourceType = url.searchParams.get("sourceType") as "task" | "incident" | null;
      const sourceId = url.searchParams.get("sourceId");
      if (!sourceType || !sourceId) {
        return new Response(JSON.stringify({ ok: false, error: "sourceType and sourceId required" }), {
          status: 400, headers: { "Content-Type": "application/json" },
        });
      }
      const { readFileSync, existsSync } = await import("node:fs");
      const { join } = await import("node:path");
      const memPath = join(WORKSPACE, "data", "station-memory.json");
      const memStore = existsSync(memPath) ? JSON.parse(readFileSync(memPath, "utf-8")) : { records: [] };
      const existingRecords = memStore.records as Record<string, unknown>[];

      if (sourceType === "task") {
        const tasksPath = join(WORKSPACE, "data", "tasks.json");
        if (!existsSync(tasksPath)) {
          return new Response(JSON.stringify({ ok: false, error: "tasks.json not found" }), { status: 404, headers: { "Content-Type": "application/json" } });
        }
        const tasks = JSON.parse(readFileSync(tasksPath, "utf-8")) as Record<string, unknown>[];
        const task = tasks.find((t) => t.id === sourceId);
        if (!task) {
          return new Response(JSON.stringify({ ok: false, error: "task not found" }), { status: 404, headers: { "Content-Type": "application/json" } });
        }
        const existing = existingRecords.find((r) => r.sourceId === task.id);
        if (existing) {
          return new Response(JSON.stringify({ ok: true, alreadyExists: true, record: existing }), { headers: { "Content-Type": "application/json" } });
        }
        const taskTags = (task.tags || []) as string[];
        const relatedRecords = existingRecords.filter((r) =>
          ((r.tags || []) as string[]).some((tag: string) => taskTags.includes(tag))
        ).slice(0, 5);
        const suggestion = {
          id: `sm-${Date.now().toString(36)}`,
          type: "completed-task-summary",
          title: `Task: ${task.title}`,
          summary: (task.summary || task.note || "No completion summary available.") as string,
          originalObjective: (task.note || "") as string,
          outcome: (task.summary || "") as string,
          recommendations: [],
          lessons: [],
          date: new Date().toISOString().split("T")[0],
          author: (task.assignee || "monkey") as string,
          tags: taskTags,
          relatedIds: relatedRecords.map((r) => r.id as string),
          source: "task",
          sourceId: task.id as string,
          linkedIncidentId: (task.linkedIncidentId || null) as string | null,
        };
        return new Response(JSON.stringify({ ok: true, suggestion, relatedRecords }), { headers: { "Content-Type": "application/json" } });
      }

      if (sourceType === "incident") {
        const incPath = join(WORKSPACE, "data", "incidents.json");
        if (!existsSync(incPath)) {
          return new Response(JSON.stringify({ ok: false, error: "incidents.json not found" }), { status: 404, headers: { "Content-Type": "application/json" } });
        }
        const incidents = JSON.parse(readFileSync(incPath, "utf-8")) as Record<string, unknown>[];
        const incident = incidents.find((i) => i.id === sourceId);
        if (!incident) {
          return new Response(JSON.stringify({ ok: false, error: "incident not found" }), { status: 404, headers: { "Content-Type": "application/json" } });
        }
        const existing = existingRecords.find((r) => r.sourceId === incident.id);
        if (existing) {
          return new Response(JSON.stringify({ ok: true, alreadyExists: true, record: existing }), { headers: { "Content-Type": "application/json" } });
        }
        const incTags = ((incident.tags || (incident.severity ? [incident.severity] : [])) as string[]);
        const relatedRecords = existingRecords.filter((r) =>
          ((r.tags || []) as string[]).some((tag: string) => incTags.includes(tag))
        ).slice(0, 5);
        const resolution = (incident.resolved || incident.resolution || "") as string;
        const timeline = (incident.timeline || []) as Record<string, unknown>[];
        const timelineSummary = timeline.map((e) => (e.message || e) as string).join("; ");
        const suggestion = {
          id: `sm-${Date.now().toString(36)}`,
          type: "lesson-learned",
          title: `Lesson: ${incident.title}`,
          summary: (resolution || `Incident ${incident.id} resolved.`) as string,
          problem: incident.title as string,
          rootCause: (resolution || "See incident timeline.") as string,
          fix: (timelineSummary || "Resolved.") as string,
          filesChanged: [],
          neverDoThis: "",
          date: new Date().toISOString().split("T")[0],
          author: "monkey",
          tags: incTags.concat(["incident"]),
          relatedIds: relatedRecords.map((r) => r.id as string),
          source: "incident",
          sourceId: incident.id as string,
        };
        return new Response(JSON.stringify({ ok: true, suggestion, relatedRecords }), { headers: { "Content-Type": "application/json" } });
      }

      return new Response(JSON.stringify({ ok: false, error: "unknown sourceType" }), {
        status: 400, headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      console.error("[api/station-memory/suggest] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500, headers: { "Content-Type": "application/json" },
      });
    }
  }
  if (url.pathname === "/api/station-memory/add" && request.method === "POST") {
    try {
      const body = await request.json() as Record<string, unknown>;
      const { writeFileSync, readFileSync, existsSync, renameSync } = await import("node:fs");
      const { join } = await import("node:path");
      const memPath = join(WORKSPACE, "data", "station-memory.json");
      let store: { version: number; lastUpdated: string; records: Record<string, unknown>[] } = { version: 1, lastUpdated: new Date().toISOString(), records: [] };
      if (existsSync(memPath)) {
        try { store = JSON.parse(readFileSync(memPath, "utf-8")); } catch { /* corrupt, start fresh */ }
      }
      const record = {
        ...body,
        id: (body.id as string) || `sm-${Date.now().toString(36)}`,
        date: (body.date as string) || new Date().toISOString().split("T")[0],
        author: (body.author as string) || "monkey",
        tags: (body.tags as string[]) || [],
        relatedIds: (body.relatedIds as string[]) || [],
        source: (body.source as string) || "manual",
      };
      const duplicateIdx = store.records.findIndex(
        (r) => (r as any).sourceId && (r as any).sourceId === (record as any).sourceId && (record as any).sourceId
      );
      if (duplicateIdx !== -1) {
        store.records[duplicateIdx] = { ...store.records[duplicateIdx], ...record };
      } else {
        store.records.push(record);
      }
      store.lastUpdated = new Date().toISOString();
      const tmpPath = memPath + ".tmp";
      writeFileSync(tmpPath, JSON.stringify(store, null, 2), "utf-8");
      renameSync(tmpPath, memPath);
      console.log(`[station-memory/add] ${duplicateIdx !== -1 ? "Updated" : "Created"} record ${record.id}`);
      return new Response(JSON.stringify({ ok: true, record, updated: duplicateIdx !== -1 }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      console.error("[api/station-memory/add] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500, headers: { "Content-Type": "application/json" },
      });
    }
  }
  if (url.pathname === "/api/cron-toggle" && request.method === "POST") {
    try {
      const { id, action } = await request.json() as { id: string; action: string };
      const { execSync } = await import("node:child_process");
      const cmd = action === "enable" ? "enable" : "disable";
      execSync(`/opt/homebrew/bin/openclaw cron ${cmd} "${id}"`, {
        encoding: "utf-8",
        timeout: 10000,
        env: { ...process.env, PATH: "/opt/homebrew/bin:/usr/bin:/bin" },
      });
      return new Response(JSON.stringify({ ok: true, message: `Cron job ${cmd}d` }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }
  }
  if (url.pathname === "/api/cron/enable" && request.method === "POST") {
    try {
      const { id } = await request.json();
      const { execSync } = await import("node:child_process");
      execSync(`/opt/homebrew/bin/openclaw cron enable "${id}"`, {
        encoding: "utf-8",
        timeout: 10000,
        env: { ...process.env, PATH: "/opt/homebrew/bin:/usr/bin:/bin" },
      });
      return new Response(JSON.stringify({ ok: true, message: "Cron job enabled" }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }
  }
  if (url.pathname === "/api/cron/disable" && request.method === "POST") {
    try {
      const { id } = await request.json();
      const { execSync } = await import("node:child_process");
      execSync(`/opt/homebrew/bin/openclaw cron disable "${id}"`, {
        encoding: "utf-8",
        timeout: 10000,
        env: { ...process.env, PATH: "/opt/homebrew/bin:/usr/bin:/bin" },
      });
      return new Response(JSON.stringify({ ok: true, message: "Cron job disabled" }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }
  }
  // ── Agent Status ──────────────────────────────────────────────────────────
  if (url.pathname === "/api/agent-status" && request.method === "GET") {
    try {
      const { readFileSync, existsSync } = await import("node:fs");
      const { join } = await import("node:path");
      const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";
      const OPENCLAW_DIR = join(WORKSPACE, "..");

      // Read openclaw.json for model config
      let currentModel = "unknown";
      try {
        const cfgPath = join(OPENCLAW_DIR, "openclaw.json");
        if (existsSync(cfgPath)) {
          const cfg = JSON.parse(readFileSync(cfgPath, "utf-8")) as Record<string, unknown>;
          const agents = cfg?.agents as Record<string, unknown> | undefined;
          const defaults = agents?.defaults as Record<string, unknown> | undefined;
          const modelConfig = defaults?.model as Record<string, unknown> | undefined;
          currentModel = String(modelConfig?.primary || "unknown");
        }
      } catch { /* use default */ }

      // Read tasks.json for agent workload
      let tasks: unknown[] = [];
      try {
        const tasksPath = join(WORKSPACE, "data", "tasks.json");
        if (existsSync(tasksPath)) {
          const raw = JSON.parse(readFileSync(tasksPath, "utf-8"));
          tasks = Array.isArray(raw) ? raw : Object.entries(raw).map(([id, t]: [string, any]) => ({ ...t, id }));
        }
      } catch { /* empty */ }

      const activeTasks = tasks.filter((t: any) => t.status === "in_progress");
      const countFor = (id: string) => activeTasks.filter((t: any) => t.assignee === id).length;
      const currentTaskFor = (id: string) => {
        const t = activeTasks.find((t: any) => t.assignee === id);
        return t ? (t as any).title : undefined;
      };

      const agents = [
        { id: "monkey", name: "Space Monkey", role: "Mission Director", emoji: "🐒", status: "active", model: currentModel, lastActive: "now", tasksActive: countFor("monkey"), currentAction: currentTaskFor("monkey") || "Monitoring station" },
        { id: "lifesupport", name: "Life Support Officer", role: "Infrastructure Controller", emoji: "🥷🏽", status: "active", model: currentModel, lastActive: "5m ago", tasksActive: countFor("lifesupport"), currentAction: currentTaskFor("lifesupport") || "Monitoring systems" },
        { id: "engineer", name: "Systems Engineer", role: "Coder / Builder", emoji: "🔧", status: countFor("engineer") > 0 ? "active" : "standby", model: currentModel, lastActive: countFor("engineer") > 0 ? "now" : "1h ago", tasksActive: countFor("engineer"), currentAction: currentTaskFor("engineer") || "Standing by" },
        { id: "archivist", name: "Station Archivist", role: "Memory & Knowledge", emoji: "📚", status: countFor("archivist") > 0 ? "active" : "standby", model: currentModel, lastActive: countFor("archivist") > 0 ? "now" : "30m ago", tasksActive: countFor("archivist"), currentAction: currentTaskFor("archivist") || "Indexing memory sectors" },
      ];
      return new Response(JSON.stringify(agents), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      console.error("[api/agent-status] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }
  }

  // ── Tasks ─────────────────────────────────────────────────────────────────
  if (url.pathname === "/api/tasks" && request.method === "GET") {
    try {
      const { readFileSync, existsSync } = await import("node:fs");
      const { join } = await import("node:path");
      const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";
      const tasksPath = join(WORKSPACE, "data", "tasks.json");
      let tasks: unknown[] = [];
      if (existsSync(tasksPath)) {
        const raw = JSON.parse(readFileSync(tasksPath, "utf-8"));
        tasks = Array.isArray(raw) ? raw : Object.entries(raw).map(([id, t]: [string, any]) => ({ ...t, id }));
      }
      return new Response(JSON.stringify(tasks), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      console.error("[api/tasks] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }
  }

  // ── Events / Activity ─────────────────────────────────────────────────────
  if (url.pathname === "/api/events" && request.method === "GET") {
    try {
      const { readFileSync, existsSync, readdirSync, statSync } = await import("node:fs");
      const { join } = await import("node:path");
      const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";
      const events: unknown[] = [];

      // 1. In-progress and recently completed tasks
      try {
        const tasksPath = join(WORKSPACE, "data", "tasks.json");
        if (existsSync(tasksPath)) {
          const raw = JSON.parse(readFileSync(tasksPath, "utf-8"));
          const tasks = Array.isArray(raw) ? raw : Object.entries(raw).map(([id, t]: [string, any]) => ({ ...t, id }));
          for (const t of tasks.filter((t: any) => t.status === "in_progress").slice(0, 5)) {
            events.push({ id: `task-active-${t.id}`, ts: t.startedAt || t.ts, message: `Working: ${t.title}`, type: "task", actor: t.assignee });
          }
          for (const t of tasks.filter((t: any) => t.status === "done" && t.completedAt).slice(-5).reverse()) {
            events.push({ id: `task-done-${t.id}`, ts: t.completedAt, message: `Completed: ${t.title}`, type: "task", actor: t.assignee });
          }
        }
      } catch { /* ignore */ }

      // 2. Open incidents
      try {
        const incPath = join(WORKSPACE, "data", "incidents.json");
        if (existsSync(incPath)) {
          const incidents = JSON.parse(readFileSync(incPath, "utf-8")) as Record<string, unknown>[];
          for (const inc of incidents.filter((i) => i.status !== "RESOLVED").slice(0, 3)) {
            events.push({ id: `inc-${inc.id}`, ts: String(inc.updatedAt || inc.createdAt || new Date().toISOString()), message: `Incident: ${inc.title || inc.id}`, type: "incident", actor: String(inc.assignee || "system") });
          }
        }
      } catch { /* ignore */ }

      // 3. Cron errors
      try {
        const errPath = join(WORKSPACE, "data", "cron-errors.json");
        if (existsSync(errPath)) {
          const cronErrors = JSON.parse(readFileSync(errPath, "utf-8")) as Record<string, unknown>[];
          for (const ce of cronErrors.filter((e) => e.status !== "completed" && e.status !== "resolved").slice(0, 3)) {
            events.push({ id: `cron-err-${ce.id}`, ts: String(ce.createdAt || new Date().toISOString()), message: `Cron error: ${ce.jobName || ce.jobId || "Unknown"} (${ce.consecutiveErrors ?? "?"}x)`, type: "cron", actor: "system" });
          }
        }
      } catch { /* ignore */ }

      // 4. Recent daily logs
      try {
        const memDir = join(WORKSPACE, "memory");
        if (existsSync(memDir)) {
          const memFiles = readdirSync(memDir).filter((f) => /^\d{4}-\d{2}-\d{2}\.md$/.test(f)).sort().reverse().slice(0, 3);
          for (const file of memFiles) {
            const stat = statSync(join(memDir, file));
            const content = readFileSync(join(memDir, file), "utf-8");
            const titleMatch = content.match(/^#\s+(.+)/m);
            const title = titleMatch ? titleMatch[1].replace(/<!--.*?>/g, "").trim() : file;
            events.push({ id: `mem-${file}`, ts: stat.mtime.toISOString(), message: `Log: ${title}`, type: "memory", actor: "Space Monkey" });
          }
        }
      } catch { /* ignore */ }

      events.sort((a: any, b: any) => new Date(b.ts).getTime() - new Date(a.ts).getTime());
      return new Response(JSON.stringify(events.slice(0, 30)), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (err) {
      console.error("[api/events] Error:", err);
      return new Response(JSON.stringify({ ok: false, error: String(err) }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }
  }

  return null;
}

export default {
  async fetch(request: Request, env: unknown, ctx: unknown) {
    try {
      const url = new URL(request.url);
      const apiResponse = await handleApiRequest(request, url);
      if (apiResponse) return addNoCacheHeaders(apiResponse);
      const handler = await getServerEntry();
      const response = await handler.fetch(request, env, ctx);
      const normalized = await normalizeCatastrophicSsrResponse(response);
      return addNoCacheHeaders(normalized);
    } catch (error) {
      console.error("[SERVER FETCH ERROR]", error);
      return brandedErrorResponse();
    }
  },
};
