// src/components/CollaborationBeam.tsx
// Animated beam between collaborating agents in different rooms

import { motion } from "framer-motion";

interface CollaborationBeamProps {
  fromRoom: string;
  toRoom: string;
  color?: string;
  active?: boolean;
}

const ROOM_CENTERS: Record<string, { x: number; y: number }> = {
  command: { x: 25, y: 28 },
  security: { x: 75, y: 28 },
  workshop: { x: 25, y: 78 },
  archive: { x: 75, y: 78 },
};

export function CollaborationBeam({ fromRoom, toRoom, color = "oklch(0.62 0.22 295)", active = true }: CollaborationBeamProps) {
  const from = ROOM_CENTERS[fromRoom];
  const to = ROOM_CENTERS[toRoom];
  if (!from || !to) return null;

  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const length = Math.sqrt(dx * dx + dy * dy);
  const angle = Math.atan2(dy, dx) * (180 / Math.PI);
  const midX = (from.x + to.x) / 2;
  const midY = (from.y + to.y) / 2;

  if (!active) return null;

  return (
    <div className="pointer-events-none absolute inset-0 z-[12] overflow-hidden">
      {/* Main beam line */}
      <motion.div
        className="absolute origin-left"
        style={{
          left: `${from.x}%`,
          top: `${from.y}%`,
          width: `${length}%`,
          height: 2,
          transform: `rotate(${angle}deg)`,
          background: `linear-gradient(90deg, ${color}00, ${color}80, ${color})`,
        }}
        animate={{ opacity: [0.4, 0.8, 0.4] }}
        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
      />
      {/* Energy pulse traveling along beam */}
      <motion.div
        className="absolute rounded-full"
        style={{
          width: 6,
          height: 6,
          backgroundColor: color,
          boxShadow: `0 0 8px ${color}, 0 0 16px ${color}80`,
          left: `${midX}%`,
          top: `${midY}%`,
          x: "-50%",
          y: "-50%",
        }}
        animate={{
          left: [`${from.x}%`, `${to.x}%`, `${from.x}%`],
          top: [`${from.y}%`, `${to.y}%`, `${from.y}%`],
          opacity: [0.6, 1, 0.6],
        }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
      />
      {/* Endpoint glows */}
      {[from, to].map((pt, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full"
          style={{
            width: 8,
            height: 8,
            backgroundColor: color,
            left: `${pt.x}%`,
            top: `${pt.y}%`,
            x: "-50%",
            y: "-50%",
          }}
          animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut", delay: i * 0.3 }}
        />
      ))}
    </div>
  );
}
