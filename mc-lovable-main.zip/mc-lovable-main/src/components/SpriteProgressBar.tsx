// src/components/SpriteProgressBar.tsx
// Small progress bar that appears above an agent sprite

import { motion } from "framer-motion";

interface SpriteProgressBarProps {
  progress: number; // 0-100
  color?: string;
  label?: string;
}

export function SpriteProgressBar({ progress, color = "oklch(0.88 0.18 145)", label }: SpriteProgressBarProps) {
  const clampedProgress = Math.min(100, Math.max(0, progress));

  return (
    <div className="absolute left-1/2 -translate-x-1/2 -top-5 w-14 pointer-events-none z-20">
      {label && (
        <div className="font-mono text-[6px] text-center text-foreground/60 truncate mb-0.5">
          {label}
        </div>
      )}
      <div className="h-1 w-full rounded-full bg-background/60 border border-border/30 overflow-hidden">
        <motion.div
          className="h-full rounded-full"
          style={{ backgroundColor: color }}
          initial={{ width: 0 }}
          animate={{ width: `${clampedProgress}%` }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        />
      </div>
      <div className="font-mono text-[6px] text-center text-foreground/40 mt-0.5">
        {Math.round(clampedProgress)}%
      </div>
    </div>
  );
}
