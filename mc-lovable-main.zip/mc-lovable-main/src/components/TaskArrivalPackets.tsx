// src/components/TaskArrivalPackets.tsx
// Animated task arrival packets — fly from dispatch point to agent rooms

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Package } from "lucide-react";

interface Packet {
  id: string;
  toRoom: string;
  taskName: string;
  color: string;
}

const ROOM_POSITIONS: Record<string, { x: number; y: number }> = {
  command: { x: 25, y: 28 },
  security: { x: 75, y: 28 },
  workshop: { x: 25, y: 78 },
  archive: { x: 75, y: 78 },
};

const DISPATCH_POINT = { x: 50, y: 50 };

interface TaskArrivalPacketsProps {
  packets: Packet[];
  onArrived?: (id: string) => void;
}

export function TaskArrivalPackets({ packets, onArrived }: TaskArrivalPacketsProps) {
  return (
    <div className="pointer-events-none absolute inset-0 z-[20] overflow-hidden">
      <AnimatePresence>
        {packets.map((packet) => {
          const dest = ROOM_POSITIONS[packet.toRoom];
          if (!dest) return null;
          return (
            <motion.div
              key={packet.id}
              className="absolute"
              initial={{
                left: `${DISPATCH_POINT.x}%`,
                top: `${DISPATCH_POINT.y}%`,
                x: "-50%",
                y: "-50%",
                scale: 0.5,
                opacity: 0,
              }}
              animate={{
                left: `${dest.x}%`,
                top: `${dest.y}%`,
                scale: [0.5, 1.2, 0.8],
                opacity: [0, 1, 1, 0],
              }}
              exit={{ opacity: 0, scale: 0.3 }}
              transition={{ duration: 1.8, ease: "easeOut" }}
              onAnimationComplete={() => onArrived?.(packet.id)}
            >
              <div className="relative">
                <Package
                  className="h-4 w-4 drop-shadow-lg"
                  style={{ color: packet.color }}
                />
                {/* Trail effect */}
                <motion.div
                  className="absolute inset-0 rounded-full"
                  style={{ backgroundColor: packet.color }}
                  initial={{ opacity: 0.4, scale: 1 }}
                  animate={{ opacity: 0, scale: 2.5 }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                />
              </div>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
