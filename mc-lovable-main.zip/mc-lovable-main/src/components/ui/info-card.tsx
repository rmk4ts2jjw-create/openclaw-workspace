import * as React from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface InfoCardProps {
  title: string;
  description: string;
  buttonText: string;
  onButtonClick?: () => void;
  className?: string;
}

const InfoCard = React.forwardRef<HTMLDivElement, InfoCardProps>(
  ({ title, description, buttonText, onButtonClick, className }, ref) => {
    return (
      <Card ref={ref} className={className}>
        <CardHeader>
          <CardTitle>{title}</CardTitle>
          <CardDescription>{description}</CardDescription>
        </CardHeader>
        <CardContent>{/* Additional content can be added here if needed */}</CardContent>
        <CardFooter>
          <Button onClick={onButtonClick}>{buttonText}</Button>
        </CardFooter>
      </Card>
    );
  },
);

InfoCard.displayName = "InfoCard";

export { InfoCard };
export type { InfoCardProps };
