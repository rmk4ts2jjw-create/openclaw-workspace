import { Link, useRouterState } from "@tanstack/react-router";
import {
  Home,
  Target,
  Calendar as CalendarIcon,
  Brain,
  FileText,
  Users,
  Satellite,
  AlertTriangle,
  Menu,
  X,
  Zap,
  Settings,
  Clock,
} from "lucide-react";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { getAwaitingReviewCount } from "@/lib/server-data/openclaw-status";
import { getBacklogCount } from "@/lib/server-data/tasks";

// Build label chip — shows current app version in sidebar header
const BUILD_LABEL = "v3.2.1"; // bump on release

const sections = [
  {
    label: "OPERATIONS",
    items: [
      { title: "Tasks", to: "/tasks", icon: Target },
      { title: "Incidents", to: "/incidents", icon: AlertTriangle },
      { title: "Scheduler", to: "/scheduler", icon: CalendarIcon },
    ],
  },
  {
    label: "KNOWLEDGE",
    items: [
      { title: "Memory", to: "/memory", icon: Brain },
      { title: "Docs", to: "/docs", icon: FileText },
    ],
  },
  {
    label: "STATION",
    items: [
      { title: "Team", to: "/team", icon: Users },
      { title: "Activity", to: "/activity", icon: Zap },
      { title: "Timeline", to: "/timeline", icon: Clock },
      { title: "Settings", to: "/settings", icon: Settings },
    ],
  },
] as const;

export function AppSidebar() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [mobileOpen, setMobileOpen] = useState(false);
  const [awaitingReviewCount, setAwaitingReviewCount] = useState(0);
  const [backlogCount, setBacklogCount] = useState(0);

  // Poll for awaiting review + backlog counts
  useEffect(() => {
    const fetchCounts = async () => {
      try {
        const [reviewRes, backlogRes] = await Promise.all([
          getAwaitingReviewCount(),
          getBacklogCount(),
        ]);
        setAwaitingReviewCount(reviewRes.count);
        setBacklogCount(backlogRes.count);
      } catch { /* ignore */ }
    };
    fetchCounts();
    const interval = setInterval(fetchCounts, 30000); // every 30s
    return () => clearInterval(interval);
  }, []);

  const isActive = (to: string) => {
    if (to === "/") return path === "/";
    return path === to || path.startsWith(to + "/");
  };



  return (
    <>
      {/* Mobile header */}
      <div className="md:hidden flex items-center justify-between px-4 py-3 border-b border-sidebar-border bg-sidebar">
        <button onClick={() => setMobileOpen(!mobileOpen)} className="text-sidebar-foreground">
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
        <Link to="/" className="font-mono text-sm font-bold tracking-[0.18em]" aria-label="Mission Control dashboard">MISSION CONTROL</Link>
        <div className="w-5" />
      </div>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm md:hidden" onClick={() => setMobileOpen(false)} />
      )}

      {/* Sidebar */}
      <aside
        className={[
          "w-60 shrink-0 flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border",
          "sticky top-0 bottom-0 h-screen overflow-y-auto z-50 md:z-0",
          "transition-transform duration-200",
          mobileOpen ? "flex translate-x-0" : "hidden md:flex md:translate-x-0",
        ].join(" ")}
      >
        {/* Header — clickable Home */}
        <div className="px-4 pt-5 pb-4 border-b border-sidebar-border/60">
          <Link to="/" className="block" onClick={() => setMobileOpen(false)} aria-label="Mission Control home">
            <div className="rounded-lg border border-sidebar-border bg-card/30 px-3 py-2.5 cursor-pointer hover:bg-card/50 transition-colors">
              <div className="flex items-center gap-2.5">
                <div className="relative w-7 h-7 rounded-full bg-[oklch(0.82_0.15_220/0.15)] flex items-center justify-center shrink-0">
                  <span className="text-sm">🛰</span>
                  <div className="absolute top-0 right-0 w-1.5 h-1.5 rounded-full bg-[oklch(0.85_0.23_155)] ring-1 ring-sidebar sound-ping" />
                </div>
                <div className="min-w-0">
                  <div className="font-bold text-xs leading-tight tracking-[0.16em] text-sidebar-foreground">MISSION CTRL</div>
                  <div className="font-mono text-[9px] text-sidebar-foreground/35 leading-tight">{BUILD_LABEL}</div>
                </div>
              </div>
            </div>
          </Link>
        </div>

        {/* Dashboard top-level nav item */}
        <div className="px-3 pt-3 pb-1">
          <Link to="/" onClick={() => setMobileOpen(false)} aria-label="Dashboard home">
            <div className={[
              "group relative flex h-10 items-center justify-between rounded-lg pl-3.5 pr-3 text-sm transition-all duration-150 cursor-pointer",
              isActive("/")
                ? "bg-[oklch(0.82_0.15_220/0.10)] text-foreground shadow-[inset_3px_0_0_0_var(--cyan-accent),0_0_18px_-6px_oklch(0.82_0.15_220/0.55)]"
                : "text-sidebar-foreground/70 hover:bg-white/[0.04] hover:text-sidebar-foreground",
            ].join(" ")}>
              <span className="flex items-center gap-2.5">
                <Home className={cn("h-4 w-4 transition-opacity", isActive("/") ? "opacity-100" : "opacity-60 group-hover:opacity-90")} />
                <span className="font-medium tracking-tight">Dashboard</span>
              </span>
              {isActive("/") && <span className="w-1.5 h-1.5 rounded-full bg-[oklch(0.85_0.23_155)]" />}
            </div>
          </Link>
        </div>

        <nav className="flex-1 px-3 py-2 space-y-5 overflow-y-auto">
          {sections.map((section) => (
            <div key={section.label}>
              <div className="px-3.5 pt-1 pb-1.5 text-[9px] font-semibold tracking-[0.22em] text-sidebar-foreground/35 uppercase">
                {section.label}
              </div>
              <div className="space-y-0.5">
                {section.items.map((item) => {
                  const active = isActive(item.to);
                  const Icon = item.icon;
                  const isTasks = item.to === "/tasks";
                  const reviewBadge = isTasks && awaitingReviewCount > 0;
                  const backlogBadge = isTasks && backlogCount > 0;
                  return (
                    <Link
                      key={item.to}
                      to={item.to}
                      onClick={() => setMobileOpen(false)}
                      aria-label={`${item.title}${reviewBadge ? ` (${awaitingReviewCount} awaiting review)` : ""}${active ? " (current page)" : ""}`}
                      aria-current={active ? "page" : undefined}
                    >
                      <div className={cn(
                        "group relative flex h-10 items-center justify-between rounded-lg pl-3.5 pr-3 text-sm transition-all duration-150",
                        active
                          ? "bg-[oklch(0.82_0.15_220/0.10)] text-foreground shadow-[inset_3px_0_0_0_var(--cyan-accent),0_0_18px_-6px_oklch(0.82_0.15_220/0.55)]"
                          : "text-sidebar-foreground/70 hover:bg-white/[0.04] hover:text-sidebar-foreground",
                      )}>
                        <span className="flex items-center gap-2.5">
                          <Icon className={cn("h-4 w-4 transition-opacity", active ? "opacity-100" : "opacity-55 group-hover:opacity-85")} />
                          <span className="font-medium tracking-tight">{item.title}</span>
                        </span>
                        {reviewBadge ? (
                          <span className="ml-auto rounded-full bg-[oklch(0.82_0.15_220/0.15)] border border-[var(--cyan-accent)]/40 px-1.5 py-0.5 font-mono text-[9px] font-bold text-[var(--cyan-accent)] min-w-[20px] text-center leading-none">
                            {awaitingReviewCount}
                          </span>
                        ) : backlogBadge ? (
                          <span className="ml-auto rounded-full bg-[oklch(0.82_0.15_220/0.15)] border border-[var(--cyan-accent)]/40 px-1.5 py-0.5 font-mono text-[9px] font-bold text-[var(--cyan-accent)] min-w-[20px] text-center leading-none">
                            {backlogCount}
                          </span>
                        ) : active && <span className="w-1.5 h-1.5 rounded-full bg-[oklch(0.85_0.23_155)]" />}
                      </div>
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* Crew status removed — available in Dashboard CREW STATUS panel */}
      </aside>
    </>
  );
}
