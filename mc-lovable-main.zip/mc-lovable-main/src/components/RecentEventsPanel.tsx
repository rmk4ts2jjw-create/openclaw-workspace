// src/components/RecentEventsPanel.tsx
// Real-time station events panel — shows recent activity across all systems

import { useState, useEffect } from "react";
import { Activity, CheckCircle, AlertTriangle, Zap, Clock, GitCommit, Wrench, Package } from "lucide-react";
import type { ActivityEvent } from "@/lib/server-data-types";

interface RecentEventsPanelProps {
  events: ActivityEvent[];
}

const TYPE_CONFIG: Record<string, { icon: typeof Activity; color: string; bg: string }> = {
  task: { icon: CheckCircle, color: "text-violet", bg: "bg-violet/10" },
  cron: { icon: Zap, color: "text-[oklch(0.88_0.18 145)]", bg: "bg-[oklch(0.88_0.18 145)]/10" },
  system: { icon: Activity, color: "text-cyan-accent", bg: "bg-cyan-accent/10" },
  incident: { icon: AlertTriangle, color: "text-destructive", bg: "bg-destructive/10" },
  deploy: { icon: GitCommit, color: "text-amber", bg: "bg-amber/10" },
  backup: { icon: Package, color: "text-[oklch(0.88_0.18 145)]", bg: "bg-[oklch(0.88_0.18 145)]/10" },
  heal: { icon: Wrench, color: "text-cyan-accent", bg: "bg-cyan-accent/10" },
};

function timeAgo(ts: string): string {
  try {
    const d = new Date(ts);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    if (diff < 60000) return "just now";
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return `${Math.floor(diff / 86400000)}d ago`;
  } catch {
    return "—";
  }
}

export function RecentEventsPanel({ events }: RecentEventsPanelProps) {
  const [currentTime, setCurrentTime] = useState<Date | null>(null);

  useEffect(() => {
    setCurrentTime(new Date());
    const interval = setInterval(() => setCurrentTime(new Date()), 30000);
    return () => clearInterval(interval);
  }, []);

  const sortedEvents = [...events]
    .sort((a, b) => new Date(b.ts).getTime() - new Date(a.ts).getTime())
    .slice(0, 12);

  return (
    <div className="rounded-lg border border-border/30 bg-card/20 overflow-hidden">
      <div className="flex items-center gap-2 px-3 py-2 border-b border-border/20">
        <Activity className="h-3.5 w-3.5 text-cyan-accent" />
        <div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60">RECENT EVENTS</div>
        <div className="ml-auto flex items-center gap-1">
          <span className="h-1.5 w-1.5 rounded-full bg-[oklch(0.88_0.18 145)] animate-pulse" />
          <span className="font-mono text-[7px] text-muted-foreground/40">LIVE</span>
        </div>
      </div>

      <div className="max-h-[240px] overflow-y-auto">
        {sortedEvents.length === 0 ? (
          <div className="px-3 py-6 text-center text-xs text-muted-foreground/50">
            No recent activity
          </div>
        ) : (
          sortedEvents.map((event) => {
            const config = TYPE_CONFIG[event.type] || TYPE_CONFIG.system;
            const Icon = config.icon;
            return (
              <div
                key={event.id}
                className="flex items-start gap-2 px-3 py-1.5 border-b border-border/10 last:border-0 hover:bg-card/30 transition-colors"
              >
                <div className={`mt-0.5 shrink-0 w-5 h-5 rounded flex items-center justify-center ${config.bg}`}>
                  <Icon className={`h-3 w-3 ${config.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-[10px] text-foreground/70 truncate leading-tight">
                    {event.message}
                  </div>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="font-mono text-[8px] text-muted-foreground/40">
                      {event.actor || "system"}
                    </span>
                    <span className="text-muted-foreground/20">·</span>
                    <span className="font-mono text-[8px] text-muted-foreground/40">
                      {currentTime ? timeAgo(event.ts) : "—"}
                    </span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
