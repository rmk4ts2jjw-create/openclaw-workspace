import { useEffect, useState, useRef, useCallback, useMemo } from "react";
import { CREW } from "@/lib/crew";
import type { AgentStatus, SystemStats, OpenClawStatus, ActivityEvent, Incident } from "@/lib/server-data-types";
import type { Task } from "@/lib/server-data-types";
import { getDreamingState, toggleDreaming } from "@/lib/dreaming";
import { Moon, Activity, CheckCircle, Zap, HeartPulse, Wrench, TrendingUp } from "lucide-react";
import { useRouter } from "@tanstack/react-router";
import { DndContext, type DragEndEvent, DragOverlay, type DragStartEvent } from "@dnd-kit/core";
import { AgentOffice } from "./AgentOffice";
import { AmbientStation } from "./AmbientStation";
import { StationFloorplan } from "./StationFloorplan";
import { CelebrationOverlay } from "./CelebrationOverlay";
import { RecentEventsPanel } from "./RecentEventsPanel";
import { DashboardRefresher } from "./DashboardRefresher";
import { AgentNetworkPanel } from "./AgentNetworkPanel";
import { TaskTickerStream } from "./TaskTickerStream";
import { EventLog } from "./EventLog";
import { TaskSidebar } from "./TaskSidebar";
import type { RiskMeterItem, AutoHealState, AutoHealAuditEntry } from "@/lib/server-data/predictions";
import type { PerformanceState } from "@/lib/server-data/performance";
import { tasksToLevel } from "@/lib/room-energy";
import { useAgentStatus } from "@/hooks/useAgentStatus";
import { useTaskStream } from "@/hooks/useTaskStream";

// ── Mood banner mappings ─────────────────────────────────────────────────
const moodLabel: Record<string, string> = {
  calm: "STATION CALM", busy: "ALL HANDS BUSY", alert: "ALERT ACTIVE", critical: "CRITICAL — ACTION NEEDED",
};
const moodClass: Record<string, string> = {
  calm: "text-[oklch(0.88_0.18_145)]", busy: "text-yellow-400", alert: "text-orange-400", critical: "text-red-400 animate-pulse",
};
const moodAccent: Record<string, string> = {
  calm: "oklch(0.85 0.23 155)", busy: "oklch(0.82 0.17 80)", alert: "rgb(251 146 60)", critical: "rgb(248 113 113)",
};

const AGENT_HEX: Record<string, string> = {
  monkey: "#60b8ff", lifesupport: "#ff5c9e", engineer: "#30e8e0", archivist: "#ffb820",
};

// ── Sub-components (kept from production) ─────────────────────────────────

function LiveActivityFeed({ events, stats }: { events: ActivityEvent[]; stats: SystemStats }) {
  const [currentTime, setCurrentTime] = useState<Date | null>(null);
  useEffect(() => { setCurrentTime(new Date()); const t = setInterval(() => setCurrentTime(new Date()), 1000); return () => clearInterval(t); }, []);
  const workingCount = stats.activeCrons || 0;
  const memPercent = stats.memoryPercent;
  const diskPercent = stats.diskPercent;
  return (
    <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
      <div className="rounded-lg border border-border/30 bg-card/20 px-2 py-1 text-center">
        <div className="font-mono text-sm font-bold tracking-wider">{currentTime ? currentTime.toLocaleTimeString("en-GB") : "--:--:--"}</div>
        <div className="font-mono text-[8px] text-muted-foreground/50">{currentTime ? currentTime.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" }) : "---"}</div>
      </div>
      <div className="rounded-lg border border-border/30 bg-card/20 px-3 py-2 space-y-2">
        <div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60">STATION STATUS</div>
        <div className="grid grid-cols-2 gap-2">
          <div className="flex items-center gap-1.5 text-xs"><Zap className="h-3 w-3 text-[oklch(0.88_0.18_145)]" /><span>{workingCount} active</span></div>
          <div className="flex items-center gap-1.5 text-xs"><HeartPulse className="h-3 w-3 text-[oklch(0.88_0.18_145)]" /><span>{memPercent}% mem</span></div>
          <div className="flex items-center gap-1.5 text-xs"><Activity className="h-3 w-3 text-cyan-accent" /><span>{diskPercent}% disk</span></div>
          <div className="flex items-center gap-1.5 text-xs"><CheckCircle className="h-3 w-3 text-[oklch(0.88_0.18_145)]" /><span>{stats.gatewayStatus}</span></div>
        </div>
      </div>
      <div className="rounded-lg border border-border/30 bg-card/20 overflow-hidden">
        <div className="px-3 py-2 border-b border-border/20 font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60">LIVE ACTIVITY</div>
        <div className="max-h-64 overflow-y-auto">
          {events.length === 0 ? (
            <div className="px-3 py-4 text-center text-xs text-muted-foreground/50">No recent activity</div>
          ) : events.slice(0, 15).map((e) => (
            <div key={e.id} className="activity-item flex items-start gap-2 px-3 py-1.5 text-xs border-b border-border/10 last:border-0">
              <span className="font-mono text-[9px] text-muted-foreground/40 shrink-0 mt-0.5">{new Date(e.ts).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}</span>
              <span className={`font-mono text-[8px] tracking-wider shrink-0 mt-0.5 ${e.type === "task" ? "text-violet" : e.type === "cron" ? "text-[oklch(0.88_0.18_145)]" : e.type === "system" ? "text-cyan-accent" : "text-muted-foreground/50"}`}>{e.type.toUpperCase()}</span>
              <span className="text-foreground/70 truncate">{e.message}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="flex flex-wrap gap-1">
        {[{ label: "GATEWAY", ok: stats.gatewayStatus === "running" }, { label: "CRON", ok: stats.activeCrons > 0 }, { label: "MEMORY", ok: true }, { label: "WIKI", ok: true }].map((s) => (
          <span key={s.label} className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 font-mono text-[7px] tracking-wider ${s.ok ? "border-[oklch(0.30_0.04_265)] bg-[oklch(0.82_0.21_145)]/10 text-[oklch(0.88_0.18_145)]" : "border-destructive/30 bg-destructive/10 text-destructive"}`}>
            <span className={`h-1.5 w-1.5 rounded-full ${s.ok ? "bg-[oklch(0.88_0.18_145)]" : "bg-destructive"}`} />{s.label}
          </span>
        ))}
      </div>
    </div>
  );
}

function DashboardChronometer({ stats }: { stats: SystemStats }) {
  return (
    <div className="rounded-lg border border-border/30 bg-card/20 px-2.5 py-1.5">
      <div className="font-mono text-[8px] tracking-[0.15em] text-muted-foreground/50 mb-1">CHRONOMETER</div>
      <div className="grid grid-cols-2 gap-2">
        <div><div className="font-mono text-[8px] text-muted-foreground/40 tracking-wider">MAC</div><div className="font-mono text-sm font-bold tracking-wider text-foreground/90">{stats.uptime}</div></div>
        <div><div className="font-mono text-[8px] text-muted-foreground/40 tracking-wider">GATEWAY</div><div className={`font-mono text-sm font-bold tracking-wider ${stats.gatewayStatus === "running" ? "text-[oklch(0.88_0.18_145)]" : "text-destructive"}`}>{stats.gatewayUptime}</div></div>
      </div>
    </div>
  );
}

function DashboardDiskWidget({ stats }: { stats: SystemStats }) {
  const diskWarn = stats.diskPercent >= 85;
  const wdWarn = stats.wdDiskPercent >= 85;
  const wdAvailable = stats.wdDiskMount !== "—";
  return (
    <div className="rounded-lg border border-border/30 bg-card/20 px-2.5 py-1.5">
      <div className="font-mono text-[8px] tracking-[0.15em] text-muted-foreground/50 mb-1">STORAGE</div>
      <div className="flex items-center gap-4">
        <div className="flex-1 space-y-1">
          <div className="flex items-center gap-2"><span className="font-mono text-[8px] text-muted-foreground/70">INTERNAL</span>{diskWarn && <span className="font-mono text-[7px] text-warning">⚠</span>}</div>
          <div className="h-1.5 w-full rounded-full bg-muted/30 overflow-hidden"><div className={`h-full rounded-full transition-all duration-1000 ${diskWarn ? "bg-warning" : "bg-[oklch(0.88_0.18_145)]"}`} style={{ width: `${Math.min(stats.diskPercent, 100)}%` }} /></div>
          <div className={`font-mono text-[9px] ${diskWarn ? "text-warning font-bold" : "text-foreground/60"}`}>{stats.diskPercent}% · {stats.diskFree} free</div>
        </div>
        {wdAvailable && (
          <div className="flex-1 space-y-1">
            <div className="flex items-center gap-2"><span className="font-mono text-[8px] text-muted-foreground/70">WD MYCLOUD</span>{wdWarn && <span className="font-mono text-[7px] text-warning">⚠</span>}</div>
            <div className="h-1.5 w-full rounded-full bg-muted/30 overflow-hidden"><div className={`h-full rounded-full transition-all duration-1000 ${wdWarn ? "bg-warning" : "bg-cyan-accent"}`} style={{ width: `${Math.min(stats.wdDiskPercent, 100)}%` }} /></div>
            <div className={`font-mono text-[9px] ${wdWarn ? "text-warning font-bold" : "text-foreground/60"}`}>{stats.wdDiskPercent}% · {stats.wdDiskUsed}/{stats.wdDiskTotal}</div>
          </div>
        )}
      </div>
    </div>
  );
}

function QuickActionsPanel({ stats }: { stats: SystemStats }) {
  const [dreamingEnabled, setDreamingEnabled] = useState<boolean | null>(null);
  const [toggling, setToggling] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  useEffect(() => { getDreamingState().then((res) => { if (res.ok) setDreamingEnabled(res.enabled); }).catch(() => setDreamingEnabled(false)); }, []);
  const handleToggleDreaming = async () => {
    setToggling(true);
    try { const res = await toggleDreaming(); if (res.ok) setDreamingEnabled(res.enabled); setResult(res.message); } catch (err) { setResult(`Failed: ${err}`); }
    setToggling(false);
    setTimeout(() => setResult(null), 3000);
  };
  return (
    <div className="space-y-2 pl-1">
      <div className="font-mono text-[8px] tracking-[0.15em] text-muted-foreground/50">QUICK ACTIONS</div>
      <div className={`rounded-lg border px-3 py-2 transition-all ${dreamingEnabled ? "border-[oklch(0.30_0.04_265)] bg-[oklch(0.82_0.21_145)]/10" : "border-border/40 bg-card/20"}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Moon className={`h-4 w-4 ${dreamingEnabled ? "text-[oklch(0.88_0.18_145)]" : "text-muted-foreground/50"}`} />
            <div><div className="text-xs font-medium">Dreaming</div><div className="font-mono text-[9px] text-muted-foreground/50">{dreamingEnabled ? "Memory consolidation active" : "Paused"}</div></div>
          </div>
          <button onClick={handleToggleDreaming} disabled={toggling} className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${dreamingEnabled ? "bg-[oklch(0.88_0.18_145)]" : "bg-muted-foreground/30"} ${toggling ? "opacity-50" : "cursor-pointer"}`}>
            <span className={`inline-block h-3 w-3 transform rounded-full bg-white transition-transform ${dreamingEnabled ? "translate-x-5" : "translate-x-1"}`} />
          </button>
        </div>
        {result && <div className="mt-1 text-[9px] text-[oklch(0.88_0.18_145)]">{result}</div>}
      </div>
      <div className="rounded-lg border border-border/30 bg-card/20 px-3 py-2 space-y-1.5">
        <div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60">SYSTEM</div>
        <div className="flex items-center justify-between text-xs"><span className="text-muted-foreground">Model</span><span className="font-mono text-[10px]">{stats.model?.split("/").pop() || "—"}</span></div>
        <div className="flex items-center justify-between text-xs"><span className="text-muted-foreground">Gateway</span><span className={`font-mono text-[10px] ${stats.gatewayStatus === "running" ? "text-[oklch(0.88_0.18_145)]" : "text-destructive"}`}>{stats.gatewayStatus}</span></div>
        <div className="flex items-center justify-between text-xs"><span className="text-muted-foreground">Crons</span><span className="font-mono text-[10px]">{stats.activeCrons}/{stats.totalCrons}</span></div>
      </div>
      <div className="rounded-lg border border-border/30 bg-card/20 px-3 py-2 space-y-2">
        <div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60">HEALTH</div>
        {[{ label: "CPU", pct: Math.min(Math.round(parseFloat(stats.cpuLoad) || 0), 100), warn: 80 }, { label: "DISK", pct: stats.diskPercent, warn: 85 }, { label: "MEM", pct: stats.memoryPercent, warn: 85 }].map((item) => (
          <div key={item.label} className="space-y-1">
            <div className="flex items-center justify-between text-[10px]"><span className="text-muted-foreground">{item.label}</span><span className={`font-mono ${item.pct >= item.warn ? "text-warning" : "text-foreground/60"}`}>{item.pct}%</span></div>
            <div className="h-1 w-full rounded-full bg-muted/30 overflow-hidden"><div className={`h-full rounded-full transition-all ${item.pct >= item.warn ? "bg-warning" : "bg-[oklch(0.88_0.18_145)]"}`} style={{ width: `${Math.min(item.pct, 100)}%` }} /></div>
          </div>
        ))}
      </div>
    </div>
  );
}

function RiskMeterWidget({ items }: { items: RiskMeterItem[] }) {
  const [currentTime, setCurrentTime] = useState<Date | null>(null);
  useEffect(() => { setCurrentTime(new Date()); const t = setInterval(() => setCurrentTime(new Date()), 1000); return () => clearInterval(t); }, []);
  if (!items || items.length === 0) return null;
  return (
    <div className="rounded-lg border border-border/30 bg-card/20 p-3">
      <div className="flex items-center gap-2 mb-2"><TrendingUp className="h-3.5 w-3.5 text-warning" /><div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60">RISK METER</div></div>
      <div className="space-y-2">
        {items.map((item, idx) => {
          const age = currentTime ? (currentTime.getTime() - new Date(item.detectedAt).getTime()) / 60000 : 0;
          const remaining = Math.max(0, 60 - age);
          const urgencyColor = item.confidence >= 80 ? "text-destructive" : item.confidence >= 70 ? "text-warning" : "text-violet";
          const barColor = item.confidence >= 80 ? "bg-destructive" : item.confidence >= 70 ? "bg-warning" : "bg-violet";
          return (
            <div key={idx} className="space-y-1">
              <div className="flex items-center justify-between"><span className="text-[10px] text-foreground/70 truncate flex-1">{item.label}</span><span className={`font-mono text-[9px] ${urgencyColor} shrink-0 ml-2`}>{item.confidence}%</span></div>
              <div className="h-1 w-full rounded-full bg-muted/30 overflow-hidden"><div className={`h-full rounded-full ${barColor}`} style={{ width: `${item.confidence}%` }} /></div>
              <div className="flex items-center justify-between"><span className="font-mono text-[8px] text-muted-foreground/40 truncate">{item.detail.substring(0, 50)}</span><span className="font-mono text-[8px] text-muted-foreground/40">{Math.round(remaining)}m</span></div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function AutoHealStatusPanel({ state, audit }: { state: AutoHealState | undefined; audit: AutoHealAuditEntry[] }) {
  if (!state) return <div className="rounded-lg border border-border/30 bg-card/20 p-3"><div className="flex items-center gap-2"><Wrench className="h-3.5 w-3.5 text-cyan-accent" /><div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60">AUTO-HEAL</div><span className="ml-auto font-mono text-[7px] text-muted-foreground/30">No data</span></div></div>;
  const total = state.total_heals || 0;
  const success = state.success_count || 0;
  const failed = state.fail_count || 0;
  const level = state.auto_heal_level || "none";
  const recentActions = audit.slice(-5).reverse();
  return (
    <div className="rounded-lg border border-border/30 bg-card/20 p-3">
      <div className="flex items-center gap-2 mb-2">
        <Wrench className="h-3.5 w-3.5 text-cyan-accent" />
        <div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60">AUTO-HEAL</div>
        <span className={`ml-auto font-mono text-[7px] tracking-wider px-1.5 py-0.5 rounded ${level === "none" ? "bg-muted/20 text-muted-foreground/40" : level === "low" ? "bg-[oklch(0.82_0.21_145)]/10 text-[oklch(0.88_0.18_145)]" : level === "medium" ? "bg-violet/10 text-violet" : "bg-cyan-accent/10 text-cyan-accent"}`}>{level.toUpperCase()}</span>
      </div>
      <div className="grid grid-cols-3 gap-2 mb-2">
        <div className="text-center"><div className="font-mono text-sm font-bold text-foreground/80">{total}</div><div className="font-mono text-[7px] text-muted-foreground/40">TOTAL</div></div>
        <div className="text-center"><div className="font-mono text-sm font-bold text-[oklch(0.88_0.18_145)]">{success}</div><div className="font-mono text-[7px] text-muted-foreground/40">SUCCESS</div></div>
        <div className="text-center"><div className="font-mono text-sm font-bold text-destructive">{failed}</div><div className="font-mono text-[7px] text-muted-foreground/40">FAILED</div></div>
      </div>
      {recentActions.length > 0 ? (
        <div className="space-y-1">
          <div className="font-mono text-[7px] tracking-wider text-muted-foreground/30">RECENT</div>
          {recentActions.map((entry, idx) => (
            <div key={idx} className="flex items-center gap-1.5 text-[9px]">
              <span className={`h-1.5 w-1.5 rounded-full shrink-0 ${entry.results.length > 0 && entry.results.every(r => r.status === "success") ? "bg-[oklch(0.88_0.18_145)]" : entry.results.some(r => r.status === "rollback" || r.status === "timeout") ? "bg-destructive" : "bg-muted-foreground/30"}`} />
              <span className="text-foreground/50 truncate">{entry.task_title.substring(0, 35)}</span>
              <span className="ml-auto text-muted-foreground/30 shrink-0">{entry.ts.substring(11, 16)}</span>
            </div>
          ))}
        </div>
      ) : <div className="text-[9px] text-muted-foreground/30 text-center py-1">No auto-heal actions yet</div>}
    </div>
  );
}

function PerformanceInsightsPanel({ state }: { state: PerformanceState | undefined }) {
  if (!state) return <div className="rounded-lg border border-border/30 bg-card/20 p-3"><div className="flex items-center gap-2"><Activity className="h-3.5 w-3.5 text-violet" /><div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60">PERFORMANCE</div><span className="ml-auto font-mono text-[7px] text-muted-foreground/30">No data</span></div></div>;
  const agents = Object.entries(state.agents || {});
  const pendingTunes = (state.tune_tasks || []).filter((t: any) => t.status === "pending");
  return (
    <div className="rounded-lg border border-border/30 bg-card/20 p-3">
      <div className="flex items-center gap-2 mb-2"><Activity className="h-3.5 w-3.5 text-violet" /><div className="font-mono text-[9px] tracking-[0.2em] text-muted-foreground/60">PERFORMANCE</div>{pendingTunes.length > 0 && <span className="ml-auto font-mono text-[7px] bg-violet/10 text-violet px-1.5 py-0.5 rounded">{pendingTunes.length} tune{pendingTunes.length > 1 ? "s" : ""}</span>}</div>
      {agents.length > 0 && (
        <div className="space-y-1.5 mb-2">
          {agents.map(([agent, stats]: [string, any]) => {
            const score = Math.round((stats.success_rate || 0) * 100);
            const scoreColor = score >= 90 ? "text-[oklch(0.88_0.18_145)]" : score >= 70 ? "text-warning" : "text-destructive";
            const barColor = score >= 90 ? "bg-[oklch(0.88_0.18_145)]" : score >= 70 ? "bg-warning" : "bg-destructive";
            return (
              <div key={agent} className="space-y-0.5">
                <div className="flex items-center justify-between"><span className="text-[10px] text-foreground/70">{agent}</span><span className={`font-mono text-[9px] ${scoreColor}`}>{score}%</span></div>
                <div className="h-1 w-full rounded-full bg-muted/30 overflow-hidden"><div className={`h-full rounded-full ${barColor}`} style={{ width: `${score}%` }} /></div>
                <div className="flex items-center justify-between text-[8px] text-muted-foreground/40"><span>{stats.done || 0} tasks · {stats.avg_task_hours || 0}h avg</span><span>{(stats.failure_rate * 100 || 0).toFixed(0)}% fail</span></div>
              </div>
            );
          })}
        </div>
      )}
      {pendingTunes.length > 0 && (
        <div className="space-y-1">
          <div className="font-mono text-[7px] tracking-wider text-muted-foreground/30">PROPOSED TUNES</div>
          {pendingTunes.slice(0, 3).map((tune: any, idx: number) => (
            <div key={idx} className="flex items-center gap-1.5 text-[9px]"><span className={`h-1.5 w-1.5 rounded-full shrink-0 ${tune.confidence >= 80 ? "bg-violet" : "bg-muted-foreground/30"}`} /><span className="text-foreground/50 truncate">{tune.label}</span><span className="ml-auto text-muted-foreground/30 shrink-0">{tune.confidence}%</span></div>
          ))}
        </div>
      )}
      {agents.length === 0 && pendingTunes.length === 0 && <div className="text-[9px] text-muted-foreground/30 text-center py-1">No performance data yet</div>}
    </div>
  );
}

// ── Sparkline (inline) ────────────────────────────────────────────────────
function Sparkline({ data, color }: { data: number[]; color: string }) {
  if (data.length < 2) return <div style={{ width: 44, height: 14, opacity: 0.15, background: color, borderRadius: 2 }} />;
  const w = 44, h = 14;
  const max = Math.max(...data, 1);
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - Math.max(1, (v / max) * h)}`).join(" ");
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} className="overflow-visible shrink-0">
      <defs><linearGradient id={`sg-${color.replace("#", "")}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={color} stopOpacity="0.18" /><stop offset="100%" stopColor={color} stopOpacity="0" /></linearGradient></defs>
      <polygon points={`0,${h} ${pts} ${w},${h}`} fill={`url(#sg-${color.replace("#", "")})`} />
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round" opacity="0.82" />
      {data.length > 1 && (() => { const last = data[data.length - 1]; const x = w; const y = h - Math.max(1, (last / max) * h); return <circle cx={x} cy={y} r="2" fill={color} opacity="0.9" />; })()}
    </svg>
  );
}

// ── Drag ghost card ────────────────────────────────────────────────────────
function DragGhostCard({ task }: { task: Task }) {
  const prioColor = { P1: "#ff4040", P2: "#ff9020", P3: "#c0a020", P4: "#40a870" }[task.priority] ?? "#60b8ff";
  return (
    <div className="rounded px-3 py-2 shadow-2xl pointer-events-none" style={{ background: "rgba(4,4,18,0.94)", border: `1px solid ${prioColor}66`, boxShadow: `0 10px 40px rgba(0,0,0,0.7), 0 0 16px ${prioColor}44`, backdropFilter: "blur(12px)", minWidth: 160 }}>
      <div className="flex items-center gap-2 mb-1">
        <span className="font-mono text-[7px] font-bold px-1 rounded" style={{ background: `${prioColor}22`, color: prioColor }}>{task.priority}</span>
      </div>
      <div className="font-mono text-[9px] text-foreground/80 leading-snug">{task.title.replace("[Dispatch] ", "")}</div>
      <div className="font-mono text-[7px] text-muted-foreground/35 mt-1">↓ Drop on agent room</div>
    </div>
  );
}

// ── Main Dashboard ─────────────────────────────────────────────────────────

interface DashboardProps {
  agents: AgentStatus[];
  systemStats: SystemStats;
  openclawStats?: OpenClawStatus;
  activity?: ActivityEvent[];
  incidents?: Incident[];
  allTasks?: Task[];
  riskItems?: RiskMeterItem[];
  autoHealState?: AutoHealState;
  autoHealAudit?: AutoHealAuditEntry[];
  performanceState?: PerformanceState;
}

export function Dashboard({ agents, systemStats, openclawStats: _openclawStats, activity = [], incidents = [], allTasks = [], riskItems = [], autoHealState, autoHealAudit = [], performanceState }: DashboardProps) {
  const router = useRouter();
  const [visitingAgentId, setVisitingAgentId] = useState<string | null>(null);
  const [celebrate, setCelebrate] = useState(false);
  const [activeDragTask, setActiveDragTask] = useState<Task | null>(null);
  const prevDoneCount = useRef(0);

  // Live data hooks (client-side polling)
  const agentStatus = useAgentStatus();
  const taskStream = useTaskStream();

  void _openclawStats;

  // Use live hook data whenever it has arrived, with SSR props only for first paint.
  const liveAgents: AgentStatus[] = agentStatus.length > 0 ? agentStatus : agents;
  const liveTasks = useMemo(() => {
    const liveTaskOverlay = new Map<string, Task>();
    [...taskStream.pendingTasks, ...taskStream.tickerTasks].forEach((task) => liveTaskOverlay.set(task.id, task));
    return [
      ...allTasks.map((task) => liveTaskOverlay.get(task.id) ?? task),
      ...Array.from(liveTaskOverlay.values()).filter((task) => !allTasks.some((existing) => existing.id === task.id)),
    ];
  }, [allTasks, taskStream.pendingTasks, taskStream.tickerTasks]);
  const liveBacklogTasks = taskStream.pendingTasks.length > 0
    ? taskStream.pendingTasks
    : liveTasks.filter((t) => t.status === "backlog");
  const liveEvents: ActivityEvent[] = useMemo(() => taskStream.recentEvents.length > 0
    ? taskStream.recentEvents.map((e) => {
        const rawType = String(e.type);
        const type = ["task", "cron", "system", "memory", "project", "incident"].includes(rawType)
          ? rawType as ActivityEvent["type"]
          : rawType === "boosted" ? "cron"
          : rawType === "celebrated" ? "system"
          : "task";
        return {
          id: e.id,
          ts: new Date(e.ts).toISOString(),
          message: e.message,
          type,
          actor: e.agentId,
        };
      })
    : activity, [activity, taskStream.recentEvents]);

  // Real task data
  const openIncidents = (incidents || []).filter((i) => i.status !== "RESOLVED");
  const hasP1 = openIncidents.some((i) => i.severity === "P1");
  const hasP2 = openIncidents.some((i) => i.severity === "P2");
  const hasP3P4 = openIncidents.some((i) => i.severity === "P3" || i.severity === "P4");
  const liveWorkingAgentCount = liveAgents.filter(a => a.status === "active" && a.tasksActive > 0).length;
  const mood: "calm" | "busy" | "alert" | "critical" =
    systemStats.gatewayStatus !== "running" ? "critical" : hasP1 ? "critical" : hasP2 ? "alert" : hasP3P4 ? "busy" :
    liveWorkingAgentCount >= 2 ? "busy" : "calm";
  const alertLevel: "none" | "warning" | "critical" = hasP1 ? "critical" : hasP2 || hasP3P4 ? "warning" : "none";

  const stalledTasks = liveTasks.filter((t) => t.status === "in_progress" && t.stalledAt);

  // Agent tasks = real live workload from /api/agent-status
  const agentTasks = Object.fromEntries(liveAgents.map(agent => [agent.id, agent.tasksActive ?? 0]));

  // Celebration detection
  useEffect(() => {
    const currentDone = liveTasks.filter(t => t.status === "done").length;
    if (prevDoneCount.current > 0 && currentDone > prevDoneCount.current) {
      setCelebrate(true);
      setTimeout(() => setCelebrate(false), 3000);
    }
    prevDoneCount.current = currentDone;
  }, [liveTasks]);

  // Log celebration events
  useEffect(() => {
    if (celebrate) taskStream.logEvent({ type: "celebrated", message: "🎊 Station celebration — task load cleared!", icon: "🎊" });
  }, [celebrate, taskStream]);

  // Agent history for sparklines follows live agent IDs, including unknown/future agents.
  const [agentHistory, setAgentHistory] = useState<Record<string, number[]>>(() => Object.fromEntries(agents.map(a => [a.id, [a.tasksActive ?? 0]])));
  useEffect(() => {
    setAgentHistory(prev => {
      const next = { ...prev };
      liveAgents.forEach(agent => {
        next[agent.id] = [...(prev[agent.id] ?? []), agent.tasksActive ?? 0].slice(-14);
      });
      return next;
    });
  }, [liveAgents]);

  // DnD handlers
  const handleDragStart = useCallback((event: DragStartEvent) => {
    const task = event.active.data.current?.task as Task | undefined;
    setActiveDragTask(task ?? null);
  }, []);

  const handleDragEnd = useCallback((event: DragEndEvent) => {
    setActiveDragTask(null);
    if (!event.over) return;
    const task = event.active.data.current?.task as Task | undefined;
    if (!task) return;
    const targetAgentId = event.over.id as string;
    const now = new Date().toISOString();
    // Build updated task list: assign to agent, move to in_progress
    const updatedTasks = liveTasks.map(t =>
      t.id === task.id
        ? { ...t, assignee: targetAgentId, status: "in_progress" as const, lastActivity: now, currentStep: `Assigned to ${targetAgentId} via drag`, startedAt: now }
        : t
    );
    // Persist via save-tasks API (merge-based, safe)
    fetch("/api/save-tasks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedTasks),
    }).then(() => {
      // Trigger immediate sidebar + dashboard refresh
      router.invalidate();
    }).catch(() => {});
    // Visual feedback via task stream
    taskStream.logEvent({ type: "assigned", agentId: targetAgentId, message: `📋 Task "${task.title}" → ${targetAgentId}`, icon: "📋" });
  }, [taskStream, router, liveTasks]);

  const handleVisitingAgentChange = useCallback((agentId: string | null) => { setVisitingAgentId(agentId); }, []);

  // Station status
  const stationStatus: "nominal" | "warning" | "critical" =
    openIncidents.some((i) => i.severity === "P1") ? "critical" : openIncidents.length > 0 || stalledTasks.length > 0 ? "warning" : "nominal";

  return (
    <DndContext id="mission-control-dashboard-dnd" onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
      <div className="flex gap-0 items-stretch min-h-0">
        {/* Main column */}
        <div className="flex-1 flex flex-col gap-2 min-w-0">
          {/* Auto-refresh */}
          <DashboardRefresher intervalMs={5000} />

          {/* Ticker stream — real backlog tasks */}
          <TaskTickerStream tasks={liveBacklogTasks} onIntercept={(taskId) => {
            const now = new Date().toISOString();
            const updatedTasks = liveTasks.map(t =>
              t.id === taskId
                ? { ...t, status: "in_progress" as const, lastActivity: now, currentStep: "Intercepted from ticker" }
                : t
            );
            fetch("/api/save-tasks", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(updatedTasks) })
              .then(() => router.invalidate())
              .catch(() => {});
            taskStream.logEvent({ type: "intercepted", message: `↩ Task intercepted: "${liveBacklogTasks.find(t => t.id === taskId)?.title ?? taskId}"`, icon: "↩" });
          }} />

          {/* Mood banner */}
          <div className="glass-card flex items-center justify-between px-4 py-3" style={{ borderLeft: `3px solid color-mix(in oklab, ${moodAccent[mood]}, transparent 30%)` }}>
            <div className="flex items-center gap-3">
              <div className={`font-mono text-[10px] tracking-[0.22em] font-semibold ${moodClass[mood]}`}>{moodLabel[mood]}</div>
              {alertLevel !== "none" && <span className={`font-mono text-[9px] rounded-full px-2 py-0.5 border ${alertLevel === "critical" ? "bg-red-400/15 text-red-400 border-red-400/30" : alertLevel === "warning" ? "bg-orange-400/15 text-orange-400 border-orange-400/30" : "bg-blue-400/15 text-blue-400 border-blue-400/30"}`}>{alertLevel.toUpperCase()}</span>}
            </div>
            <div className="flex items-center gap-5">
              <div className="flex items-center gap-1.5"><span className="font-mono text-[9px] text-muted-foreground/45 tracking-wider">CRONS</span><span className="font-mono text-[10px] text-foreground/80 tabular-nums">{systemStats.activeCrons}/{systemStats.totalCrons}</span></div>
              <div className="flex items-center gap-1.5"><span className="font-mono text-[9px] text-muted-foreground/45 tracking-wider">UP</span><span className="font-mono text-[10px] text-foreground/80">{systemStats.uptime}</span></div>
            </div>
          </div>

          {/* Station Status Bar */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="glass-card px-4 py-3 flex flex-col items-center justify-center gap-1">
              <div className="label-tracked">AGENTS ACTIVE</div>
              <div className="text-2xl font-bold">{liveAgents.filter(a => a.status === "active").length}</div>
              <div className="text-[8px] text-muted-foreground/50">of {liveAgents.length} crew</div>
            </div>
            <div className="glass-card px-4 py-3 flex flex-col items-center justify-center gap-1">
              <div className="label-tracked">MEMORY</div>
              <div className="text-2xl font-bold">{systemStats.memoryPercent}%</div>
              <div className="text-[8px] text-muted-foreground/50">RAM used</div>
            </div>
            <div className="glass-card px-4 py-3 flex flex-col items-center justify-center gap-1">
              <div className="label-tracked">DISK</div>
              <div className="text-2xl font-bold">{systemStats.diskPercent}%</div>
              <div className="text-[8px] text-muted-foreground/50">storage used</div>
            </div>
            <div className="glass-card px-4 py-3 flex flex-col items-center justify-center gap-1">
              <div className="label-tracked">CPU</div>
              <div className="text-2xl font-bold">{Math.round(parseFloat(systemStats.cpuLoad) || 0)}%</div>
              <div className="text-[8px] text-muted-foreground/50">load avg</div>
            </div>
          </div>

          {/* Full-width Agent Office */}
          <div className="relative z-0">
            <AmbientStation mood={mood}>
              <StationFloorplan enableVisits onVisitingAgentChange={handleVisitingAgentChange} activeIncidentRooms={Array.from(new Set(openIncidents.filter((i) => i.owner && ({ monkey: "command", lifesupport: "security", engineer: "workshop", archivist: "archive" }[i.owner] as string)).filter(Boolean))) as any}>
                {CREW.map(member => {
                  const liveStatus = liveAgents.find(a => a.id === member.id);
                  const isAway = visitingAgentId === member.id;
                  const wl = tasksToLevel(agentTasks[member.id] ?? 0, hasP1 && member.id === "monkey");
                  const agentId = member.id;
                  return (
                    <AgentOffice key={member.id} crew={member}
                      liveStatus={liveStatus ? { id: liveStatus.id, name: liveStatus.name, status: liveStatus.status === "active" && liveStatus.tasksActive > 0 ? "working" as const : liveStatus.status === "error" ? "away" as const : "idle" as const, currentAction: liveStatus.currentAction, tasksActive: liveStatus.tasksActive } : undefined}
                      isAway={isAway} workloadLevel={wl}
                      speechBubble={taskStream.speechBubbles[agentId]} flashState={taskStream.agentFlash[agentId]}
                      energyBoosted={taskStream.energyBoosts[agentId]} onCoffeeSent={taskStream.boostEnergy}
                    />
                  );
                })}
              </StationFloorplan>
            </AmbientStation>
            <CelebrationOverlay active={celebrate} />
          </div>

          {/* Agent Network — directly under Agent Office, enlarged */}
          <div className="relative z-10">
            <AgentNetworkPanel agents={liveAgents} tasks={liveTasks} />
          </div>

          {/* Crew status table with sparklines */}
          <div className="glass-card overflow-hidden">
            <div className="px-4 py-2.5 border-b border-border/40 flex items-center justify-between">
              <div className="label-tracked">CREW STATUS</div>
              <div className="font-mono text-[7px] text-muted-foreground/30">TASKS · TREND</div>
            </div>
            <div className="divide-y divide-border/30">
              {CREW.map(member => {
                const live = liveAgents.find(a => a.id === member.id);
                const status = live?.status || "standby";
                const action = live?.currentAction;
                const isActive = status === "active" && (live?.tasksActive ?? 0) > 0;
                const dotColor = isActive ? "#40d080" : status === "error" ? "#ff4040" : "#444";
                const statusLabel = isActive ? "ON DUTY" : status === "active" ? "ACTIVE" : status === "error" ? "ERROR" : "IDLE";
                const statusColor = isActive ? "text-[oklch(0.88_0.18_145)]" : status === "error" ? "text-destructive" : "text-muted-foreground/50";
                const taskCount = agentTasks[member.id] ?? 0;
                const hex = AGENT_HEX[member.id] ?? "#60b8ff";
                const hist = agentHistory[member.id] ?? [taskCount];
                return (
                  <div key={member.id} className="flex items-center gap-3 px-4 py-2.5 hover:bg-white/[0.02] transition-colors">
                    <span className="shrink-0 text-xl leading-none">{member.emoji}</span>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-foreground/80 leading-tight">{member.name}</div>
                      <div className="text-[9px] text-muted-foreground/60 leading-tight">{member.shortRole}</div>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0"><span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: dotColor }} /><span className={`font-mono text-[9px] ${statusColor}`}>{statusLabel}</span></div>
                    {action && <div className="font-mono text-[9px] text-muted-foreground/40 max-w-[100px] truncate hidden lg:block">{action}</div>}
                    {taskCount > 0 && <div className="shrink-0 font-mono text-[8px] font-bold px-1.5 py-0.5 rounded-full" style={{ background: `${hex}18`, border: `1px solid ${hex}38`, color: hex, minWidth: 22, textAlign: "center" }}>{taskCount}</div>}
                    <Sparkline data={hist} color={hex} />
                  </div>
                );
              })}
            </div>
          </div>

          {/* Station Log */}
          <EventLog events={liveEvents} />

          {/* Panels — single flowing grid, left-to-right, auto-resizing */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))" }}>
            <DashboardChronometer stats={systemStats} />
            <DashboardDiskWidget stats={systemStats} />
            <RiskMeterWidget items={riskItems} />
            <AutoHealStatusPanel state={autoHealState} audit={autoHealAudit} />
            <PerformanceInsightsPanel state={performanceState} />
            <RecentEventsPanel events={liveEvents} />
            <LiveActivityFeed events={liveEvents} stats={systemStats} />
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between rounded-lg border border-border/20 bg-card/10 px-4 py-2 gap-4 flex-wrap">
            <div className="font-mono text-[9px] text-muted-foreground/40 tracking-wider">OPENCLAW STATION · {systemStats.hostname}</div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5"><span className={`inline-block h-1.5 w-1.5 rounded-full ${systemStats.gatewayStatus === "running" ? "bg-[oklch(0.88_0.18_145)] animate-pulse" : "bg-destructive"}`} /><span className="font-mono text-[8px] text-muted-foreground/50">{systemStats.gatewayStatus === "running" ? "ALL SYSTEMS GO" : "GATEWAY DOWN"}</span></div>
              <span className="text-muted-foreground/20">|</span>
              <span className="font-mono text-[8px] text-muted-foreground/50">{systemStats.activeCrons} crons · {Math.round(parseFloat(systemStats.cpuLoad) || 0)}% CPU · {systemStats.memoryPercent}% RAM</span>
            </div>
            <div className="font-mono text-[9px] text-muted-foreground/40 tracking-wider">MODEL: {systemStats.model}</div>
          </div>
        </div>

        {/* Collapsible right sidebar — real backlog tasks */}
        <div className="flex items-stretch shrink-0">
          <TaskSidebar tasks={liveBacklogTasks} onDismiss={(taskId) => {
            const now = new Date().toISOString();
            const updatedTasks = liveTasks.map(t =>
              t.id === taskId
                ? { ...t, status: "done" as const, lastActivity: now, completedAt: now, currentStep: "Dismissed from sidebar" }
                : t
            );
            fetch("/api/save-tasks", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(updatedTasks) })
              .then(() => router.invalidate())
              .catch(() => {});
          }} />
        </div>
      </div>

      {/* Drag overlay */}
      <DragOverlay dropAnimation={null}>
        {activeDragTask ? <DragGhostCard task={activeDragTask} /> : null}
      </DragOverlay>
    </DndContext>
  );
}
