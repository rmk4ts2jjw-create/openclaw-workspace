// src/components/StationReactionOverlay.tsx
// Full-station visual reactions — flash, shake, pulse for events

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export type ReactionType = "task_complete" | "task_dispatch" | "incident" | "celebration" | "error" | "level_up";

interface Reaction {
  id: string;
  type: ReactionType;
  message?: string;
}

interface StationReactionOverlayProps {
  reactions: Reaction[];
  onComplete?: (id: string) => void;
}

const REACTION_CONFIG: Record<ReactionType, { color: string; icon: string; duration: number }> = {
  task_complete: { color: "oklch(0.88 0.18 145)", icon: "✓", duration: 2000 },
  task_dispatch: { color: "oklch(0.62 0.22 295)", icon: "📦", duration: 1500 },
  incident: { color: "oklch(0.78 0.18 25)", icon: "⚠", duration: 3000 },
  celebration: { color: "oklch(0.85 0.16 90)", icon: "🎉", duration: 3000 },
  error: { color: "oklch(0.78 0.18 25)", icon: "✕", duration: 2500 },
  level_up: { color: "oklch(0.78 0.14 200)", icon: "⬆", duration: 2000 },
};

export function StationReactionOverlay({ reactions, onComplete }: StationReactionOverlayProps) {
  return (
    <div className="pointer-events-none absolute inset-0 z-[30] overflow-hidden">
      <AnimatePresence>
        {reactions.map((reaction) => (
          <ReactionEffect
            key={reaction.id}
            reaction={reaction}
            onComplete={() => onComplete?.(reaction.id)}
          />
        ))}
      </AnimatePresence>
    </div>
  );
}

function ReactionEffect({ reaction, onComplete }: { reaction: Reaction; onComplete: () => void }) {
  const config = REACTION_CONFIG[reaction.type];

  useEffect(() => {
    const timer = setTimeout(onComplete, config.duration);
    return () => clearTimeout(timer);
  }, [config.duration, onComplete]);

  if (reaction.type === "task_dispatch") {
    return (
      <motion.div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: [0, 1.5, 1], opacity: [0, 1, 0.8] }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div
          className="rounded-lg border px-3 py-1.5 font-mono text-[10px] tracking-wider"
          style={{ borderColor: config.color, color: config.color, backgroundColor: `${config.color}15` }}
        >
          {config.icon} {reaction.message || "Task Dispatched"}
        </div>
      </motion.div>
    );
  }

  if (reaction.type === "celebration") {
    return (
      <>
        {/* Confetti particles */}
        {Array.from({ length: 12 }).map((_, i) => {
          const angle = (i / 12) * Math.PI * 2;
          const dist = 30 + Math.random() * 20;
          return (
            <motion.div
              key={i}
              className="absolute left-1/2 top-1/2 w-2 h-2 rounded-full"
              style={{
                backgroundColor: ["oklch(0.78 0.14 200)", "oklch(0.85 0.16 90)", "oklch(0.88 0.18 145)", "oklch(0.78 0.18 350)"][i % 4],
              }}
              initial={{ x: 0, y: 0, opacity: 1 }}
              animate={{
                x: Math.cos(angle) * dist,
                y: Math.sin(angle) * dist - 10,
                opacity: [1, 1, 0],
                scale: [1, 1.5, 0.5],
              }}
              transition={{ duration: 1.5, ease: "easeOut" }}
            />
          );
        })}
        {/* Center flash */}
        <motion.div
          className="absolute inset-0"
          style={{ backgroundColor: config.color }}
          initial={{ opacity: 0.3 }}
          animate={{ opacity: [0.3, 0.1, 0] }}
          transition={{ duration: 1 }}
        />
      </>
    );
  }

  if (reaction.type === "incident") {
    return (
      <>
        {/* Red flash overlay */}
        <motion.div
          className="absolute inset-0"
          style={{ backgroundColor: "oklch(0.78 0.18 25 / 0.15)" }}
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 0.6, 0.3, 0.6, 0] }}
          transition={{ duration: 2, times: [0, 0.2, 0.5, 0.8, 1] }}
        />
        {/* Warning banner */}
        <motion.div
          className="absolute top-4 left-1/2 -translate-x-1/2"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -20, opacity: 0 }}
        >
          <div className="rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-1 font-mono text-[10px] text-destructive tracking-wider">
            {config.icon} {reaction.message || "INCIDENT DETECTED"}
          </div>
        </motion.div>
      </>
    );
  }

  // Default: task_complete, error, level_up
  return (
    <motion.div
      className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2"
      initial={{ scale: 0.5, opacity: 0, y: 10 }}
      animate={{ scale: 1, opacity: 1, y: 0 }}
      exit={{ scale: 1.2, opacity: 0, y: -20 }}
      transition={{ duration: 0.4 }}
    >
      <div
        className="rounded-lg border px-3 py-1.5 font-mono text-[10px] tracking-wider whitespace-nowrap"
        style={{ borderColor: config.color, color: config.color, backgroundColor: `${config.color}10` }}
      >
        {config.icon} {reaction.message || reaction.type.replace(/_/g, " ").toUpperCase()}
      </div>
    </motion.div>
  );
}
