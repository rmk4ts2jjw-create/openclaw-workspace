// src/components/DoorAnimation.tsx
// Sliding door animation for station rooms — opens with glow + air hiss, then closes

import { motion } from "framer-motion";

interface DoorAnimationProps {
  position: "left" | "right" | "top" | "bottom";
  isOpen: boolean;
  accentColor: string;
  doorWidth?: number;
  doorHeight?: number;
}

export function DoorAnimation({
  position,
  isOpen,
  accentColor,
  doorWidth = 24,
  doorHeight = 40,
}: DoorAnimationProps) {
  const isHorizontal = position === "left" || position === "right";

  // Translation direction: slide the door outward from its mounted edge
  const translate = (() => {
    if (!isOpen) return { x: 0, y: 0 };
    switch (position) {
      case "left":
        return { x: "-100%", y: 0 };
      case "right":
        return { x: "100%", y: 0 };
      case "top":
        return { x: 0, y: "-100%" };
      case "bottom":
        return { x: 0, y: "100%" };
    }
  })();

  // Glow goes on the leading edge — the edge that moves into view
  const glowEdge = (() => {
    switch (position) {
      case "left":
        return `4px 0 8px ${accentColor}`;
      case "right":
        return `-4px 0 8px ${accentColor}`;
      case "top":
        return `0 4px 8px ${accentColor}`;
      case "bottom":
        return `0 -4px 8px ${accentColor}`;
    }
  })();

  // Hiss line position — thin strip along the same leading edge
  const hissStyle: React.CSSProperties = (() => {
    const base: React.CSSProperties = {
      position: "absolute",
      backgroundColor: `oklch(0.50 0.10 ${extractHue(accentColor)} / 0.2)`,
      transition: "opacity 0.4s ease",
      pointerEvents: "none",
    };
    if (isHorizontal) {
      return {
        ...base,
        top: 0,
        width: 1,
        height: `${doorHeight}px`,
        [position === "left" ? "right" : "left"]: 0,
      };
    }
    return {
      ...base,
      left: 0,
      height: 1,
      width: `${doorWidth}px`,
      [position === "top" ? "bottom" : "top"]: 0,
    };
  })();

  const containerStyle: React.CSSProperties = {
    position: "relative",
    width: isHorizontal ? doorWidth : doorHeight,
    height: isHorizontal ? doorHeight : doorWidth,
    overflow: "hidden",
  };

  return (
    <div style={containerStyle}>
      <motion.div
        animate={{
          x: translate.x,
          y: translate.y,
          boxShadow: isOpen ? glowEdge : "none",
          opacity: isOpen ? 0.6 : 1,
        }}
        transition={{
          transform: { duration: 0.6, ease: "easeInOut" },
          opacity: { duration: 0.3 },
        }}
        style={{
          width: isHorizontal ? doorWidth : doorHeight,
          height: isHorizontal ? doorHeight : doorWidth,
          border: "1px solid oklch(0.30 0.04 265)",
          background: "oklch(0.15 0.02 265)",
          boxSizing: "border-box",
        }}
      >
        {/* Subtle panel detail line down the middle */}
        <div
          style={{
            position: "absolute",
            background: "oklch(0.22 0.03 265)",
            ...(isHorizontal
              ? {
                  left: "50%",
                  top: "10%",
                  width: 1,
                  height: "80%",
                  transform: "translateX(-50%)",
                }
              : {
                  top: "50%",
                  left: "10%",
                  height: 1,
                  width: "80%",
                  transform: "translateY(-50%)",
                }),
          }}
        />
      </motion.div>

      {/* Hiss effect — visible only during motion */}
      {isOpen && <div style={hissStyle} />}
    </div>
  );
}

/** Crude hue extractor from hex / named colors — falls back to 0 (red) */
function extractHue(color: string): number {
  // Handle hex #rrggbb
  const hex = color.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i);
  if (hex) {
    const r = parseInt(hex[1], 16) / 255;
    const g = parseInt(hex[2], 16) / 255;
    const b = parseInt(hex[3], 16) / 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const d = max - min;
    let h = 0;
    if (d !== 0) {
      if (max === r) h = ((g - b) / d + 6) % 6;
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
    }
    return Math.round(h);
  }
  // Handle #rgb shorthand
  const hex3 = color.match(/^#([0-9a-f])([0-9a-f])([0-9a-f])$/i);
  if (hex3) {
    const r = parseInt(hex3[1] + hex3[1], 16) / 255;
    const g = parseInt(hex3[2] + hex3[2], 16) / 255;
    const b = parseInt(hex3[3] + hex3[3], 16) / 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const d = max - min;
    let h = 0;
    if (d !== 0) {
      if (max === r) h = ((g - b) / d + 6) % 6;
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
    }
    return Math.round(h);
  }
  // Handle oklch(h l c)
  const oklchMatch = color.match(/oklch\(\s*([\d.]+)/);
  if (oklchMatch) return parseFloat(oklchMatch[1]);
  return 0;
}
