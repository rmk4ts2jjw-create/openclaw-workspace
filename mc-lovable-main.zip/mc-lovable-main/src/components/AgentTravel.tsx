// src/components/AgentTravel.tsx
// Hallway traversal system — agents physically walk between rooms when collaborating
// Uses L-shaped pathfinding: exit room → horizontal corridor → vertical corridor → enter destination

import { motion, AnimatePresence } from "framer-motion";

interface Collaboration {
  id: string;
  agents: [string, string];
  fromRoom: string;
  toRoom: string;
  sprite: string;
}

interface AgentTravelProps {
  collaborations: Collaboration[];
  roomPositions: Record<string, { x: number; y: number }>;
  isVisible: boolean;
}

// Room grid positions (percentage-based for the 2x2 layout)
const DEFAULT_ROOM_POSITIONS: Record<string, { x: number; y: number }> = {
  command: { x: 25, y: 25 },
  security: { x: 75, y: 25 },
  workshop: { x: 25, y: 75 },
  archive: { x: 75, y: 75 },
};

// Hallway intersection point (center of the grid)
const HUB = { x: 50, y: 50 };

export function AgentTravel({ collaborations, roomPositions, isVisible }: AgentTravelProps) {
  const rooms = { ...DEFAULT_ROOM_POSITIONS, ...roomPositions };

  if (!isVisible || collaborations.length === 0) return null;

  return (
    <div className="relative w-full h-0 overflow-visible">
      {/* SVG layer for collaboration links and data pulses */}
      <svg
        className="absolute inset-0 w-full h-[300px] pointer-events-none"
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
      >
        <defs>
          <linearGradient id="collabGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="oklch(0.62 0.22 295 / 0.3)" />
            <stop offset="50%" stopColor="oklch(0.78 0.14 200 / 0.5)" />
            <stop offset="100%" stopColor="oklch(0.62 0.22 295 / 0.3)" />
          </linearGradient>
        </defs>

        {collaborations.map(collab => {
          const from = rooms[collab.fromRoom];
          const to = rooms[collab.toRoom];
          if (!from || !to) return null;

          // L-shaped path: from → hub → to
          const pathD = `M ${from.x} ${from.y} L ${HUB.x} ${HUB.y} L ${to.x} ${to.y}`;

          return (
            <g key={collab.id}>
              {/* Collaboration link line */}
              <path
                d={pathD}
                fill="none"
                stroke="url(#collabGradient)"
                strokeWidth="0.3"
                strokeDasharray="1 1"
                className="animate-dash"
              />
            </g>
          );
        })}

        {/* Hallway corridor indicators */}
        {/* Horizontal corridor */}
        <line
          x1="15" y1="50" x2="85" y2="50"
          stroke="oklch(0.20 0.03 265 / 0.15)"
          strokeWidth="0.2"
          strokeDasharray="2 2"
        />
        {/* Vertical corridor */}
        <line
          x1="50" y1="15" x2="50" y2="85"
          stroke="oklch(0.20 0.03 265 / 0.15)"
          strokeWidth="0.2"
          strokeDasharray="2 2"
        />

        <style>{`
          @keyframes dash {
            to { stroke-dashoffset: -2; }
          }
          .animate-dash {
            animation: dash 1s linear infinite;
          }
        `}</style>
      </svg>

      {/* Traveling agent sprites (HTML layer for pixelated rendering) */}
      <AnimatePresence>
        {collaborations.map(collab => {
          const from = rooms[collab.fromRoom];
          const to = rooms[collab.toRoom];
          if (!from || !to) return null;

          // Animate via keyframes: from → hub → to
          const midX = HUB.x;
          const midY = HUB.y;

          return (
            <motion.div
              key={`travel-${collab.id}`}
              className="absolute pointer-events-none"
              style={{
                left: `${from.x}%`,
                top: `${from.y}%`,
                transform: "translate(-50%, -50%)",
              }}
              animate={{
                left: [`${from.x}%`, `${midX}%`, `${to.x}%`],
                top: [`${from.y}%`, `${midY}%`, `${to.y}%`],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                repeatDelay: 2,
                ease: "easeInOut",
              }}
            >
              <motion.div
                animate={{ y: [0, -3, 0, -3, 0] }}
                transition={{ duration: 0.5, repeat: Infinity, ease: "easeInOut" }}
              >
                <img
                  src={collab.sprite}
                  alt=""
                  className="w-10 h-10 object-contain"
                  style={{ imageRendering: "pixelated" }}
                />
              </motion.div>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
