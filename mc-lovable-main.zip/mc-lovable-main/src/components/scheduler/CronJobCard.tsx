import type { OpenClawCronJob } from "@/lib/server-data-types";
import type { CronError } from "./useCronData";
import { Pill } from "@/components/PageHeader";
import { Power, Clock, AlertTriangle, CheckCircle, Loader2 } from "lucide-react";

// ── Types ────────────────────────────────────────────────────────────────────

interface CronJobCardProps {
  job: OpenClawCronJob;
  isToggling: boolean;
  hasResult: boolean;
  resultMessage: string | null;
  hasActiveError: boolean;
  onToggle: (job: OpenClawCronJob) => void;
  healthStatus?: "healthy" | "degraded" | "failing" | "unknown";
}

// ── Component ────────────────────────────────────────────────────────────────

export function CronJobCard({
  job,
  isToggling,
  hasResult,
  resultMessage,
  hasActiveError,
  onToggle,
  healthStatus = "unknown",
}: CronJobCardProps) {
  const healthDot =
    healthStatus === "healthy" ? "bg-[oklch(0.88_0.18_145)]" :
    healthStatus === "degraded" ? "bg-amber-400" :
    healthStatus === "failing" ? "bg-red-400" :
    "bg-muted-foreground/30";
  const healthLabel =
    healthStatus === "healthy" ? "text-[oklch(0.88_0.18_145)]" :
    healthStatus === "degraded" ? "text-amber-400" :
    healthStatus === "failing" ? "text-red-400" :
    "text-muted-foreground/50";
  return (
    <div
      className={`rounded-xl border bg-card/60 px-5 py-4 transition-all ${
        job.enabled
          ? "border-border border-l-4 border-l-[oklch(0.88_0.18_145)]"
          : "border-border/40 border-l-4 border-l-border/30 opacity-70"
      }`}
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-center gap-3 flex-wrap">
          <span className={`h-2.5 w-2.5 rounded-full ${healthDot} shrink-0`} title={healthStatus} />
          <h3 className="font-semibold">{job.name}</h3>
          <Pill variant={job.enabled ? "online" : "default"}>
            {job.enabled ? "ACTIVE" : "DISABLED"}
          </Pill>
          {hasActiveError && (
            <Pill variant="warning">⚠ {job.consecutiveErrors ?? 0} error{job.consecutiveErrors ?? 0 > 1 ? "s" : ""}</Pill>
          )}
        </div>

        <button
          onClick={() => onToggle(job)}
          disabled={isToggling}
          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors shrink-0 ${
            job.enabled
              ? "bg-[oklch(0.88_0.18_145)]"
              : "bg-muted-foreground/30"
          } ${isToggling ? "opacity-50 cursor-wait" : "cursor-pointer"}`}
        >
          {isToggling ? (
            <Loader2 className="h-3 w-3 text-white absolute left-1/2 -translate-x-1/2 animate-spin" />
          ) : (
            <span
              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                job.enabled ? "translate-x-6" : "translate-x-1"
              }`}
            />
          )}
        </button>
      </div>

      <div className="mt-2 flex items-center gap-2 font-mono text-xs text-muted-foreground">
        <Clock className="h-3 w-3" />
        <span>{job.schedule}</span>
      </div>

      {job.message && (
        <div className="mt-2 text-xs text-muted-foreground/70 line-clamp-2">
          {job.message}
        </div>
      )}
      {(job.consecutiveErrors ?? 0) > 0 && (
        <div className="mt-2 flex items-center gap-2 text-[10px]">
          <span className={healthLabel}>
            Retry {Math.min((job.consecutiveErrors ?? 0), 3)}/3
          </span>
          {(job.consecutiveErrors ?? 0) >= 3 && (
            <span className="text-red-400">· P2 incident auto-created</span>
          )}
        </div>
      )}

      <div className="mt-3 flex items-center gap-4 font-mono text-[10px] text-muted-foreground/50">
        {job.lastRun !== "—" && (
          <span>Last: {new Date(job.lastRun).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}</span>
        )}
        {job.nextRun !== "—" && job.enabled && (
          <span>Next: {new Date(job.nextRun).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}</span>
        )}
      </div>

      {hasResult && resultMessage && (
        <div className={`mt-2 text-xs ${resultMessage.startsWith("Failed") ? "text-destructive" : "text-[oklch(0.88_0.18_145)]"}`}>
          {resultMessage}
        </div>
      )}
    </div>
  );
}
