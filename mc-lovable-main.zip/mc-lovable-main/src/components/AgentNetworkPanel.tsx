// AgentNetworkPanel — dynamic agent collaboration network.
// Wired to real agent data from useAgentNetwork hook and task counts.

import { useMemo } from "react";
import type { AgentStatus } from "@/lib/server-data-types";
import type { Task } from "@/lib/server-data-types";
import { getCrew } from "@/lib/crew";

const AGENT_COLORS: Record<string, string> = {
  monkey: "#60b8ff",
  lifesupport: "#ff5c9e",
  engineer: "#30e8e0",
  archivist: "#ffb820",
};

interface NodeData {
  id: string;
  emoji: string;
  color: string;
  name: string;
  role: string;
  shortRole: string;
  tasksActive: number;
  workloadLevel: number; // 0-100
  x: number; y: number; // normalized 0-1 within container
}

interface EdgeData {
  source: string;
  target: string;
  collaboration: number; // 0-100 proxy for collaboration strength
}

export function AgentNetworkPanel({ agents, tasks }: { agents: AgentStatus[]; tasks: Task[] }) {
  // Compute task count per agent from tasks array (assignee + not done)
  const taskCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    tasks.forEach(t => {
      if (t.assignee && t.status !== "done") {
        counts[t.assignee] = (counts[t.assignee] ?? 0) + 1;
      }
    });
    return counts;
  }, [tasks]);

  // Prepare node data: combine agent status with task counts
  const nodes: NodeData[] = useMemo(() => {
    return agents.map(agent => {
      const count = taskCounts[agent.id] ?? 0;
      // Prefer the task table count here: /api/agent-status tracks in-progress work,
      // while the network visual is meant to show all live assigned/not-done load.
      const tasksActive = Math.max(agent.tasksActive ?? 0, count);
      const workloadLevel = Math.min(100, tasksActive * 10);
      const emoji = agent.emoji ?? "🤖";
      const color = AGENT_COLORS[agent.id] ?? "#6b7280";
      const crew = getCrew(agent.id);
      const name = crew?.name ?? agent.name ?? agent.id;
      const role = crew?.role ?? agent.role ?? "Agent";
      const shortRole = crew?.shortRole ?? (agent as { shortRole?: string }).shortRole ?? agent.id;
      return {
        id: agent.id,
        emoji,
        color,
        name,
        role,
        shortRole,
        tasksActive,
        workloadLevel,
        x: 0,
        y: 0,
      };
    });
  }, [agents, taskCounts]);

  // Compute collaboration scores between agents: use min of taskCounts as proxy
  const edges: EdgeData[] = useMemo(() => {
    const edges: EdgeData[] = [];
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const a = nodes[i];
        const b = nodes[j];
        const collab = Math.min(a.tasksActive, b.tasksActive) * 10; // scale to 0-100
        if (collab > 0) {
          edges.push({
            source: a.id,
            target: b.id,
            collaboration: Math.min(100, collab),
          });
        }
      }
    }
    return edges;
  }, [nodes]);

  // Determine node layout: 2x2 grid for <=4 agents, otherwise circle
  const positionedNodes: NodeData[] = useMemo(() => {
    const count = nodes.length;
    const nodesWithPos = nodes.map(node => ({ ...node }));
    if (count <= 4) {
      // 2x2 grid positions (normalized 0-1)
      const positions = [
        { x: 0.25, y: 0.25 },
        { x: 0.75, y: 0.25 },
        { x: 0.25, y: 0.75 },
        { x: 0.75, y: 0.75 },
      ];
      nodesWithPos.forEach((n, idx) => {
        if (positions[idx]) {
          n.x = positions[idx].x;
          n.y = positions[idx].y;
        }
      });
    } else {
      // Circular layout
      const radius = 0.4; // inner radius (0-1)
      const center = 0.5;
      const step = (2 * Math.PI) / count;
      nodesWithPos.forEach((n, idx) => {
        const angle = idx * step;
        n.x = center + radius * Math.cos(angle);
        n.y = center + radius * Math.sin(angle);
      });
    }
    return nodesWithPos;
  }, [nodes.length]);

  // Precompute line styles for edges (single color, width/opacity from collaboration)
  const edgeLines = useMemo(() => {
    return edges.map(edge => {
      const sourceNode = positionedNodes.find(n => n.id === edge.source)!;
      const targetNode = positionedNodes.find(n => n.id === edge.target)!;
      const collab = edge.collaboration;
      // Base width and opacity, scale with collaboration
      const width = 1 + collab * 0.02; // 1px base, +0.02 per collab point
      const opacity = 0.1 + collab * 0.008; // 0.1 base, +0.008 per collab point
      return {
        source: sourceNode,
        target: targetNode,
        width,
        opacity,
      };
    });
  }, [positionedNodes, edges]);

  return (
    <div className="flex flex-col" style={{ minHeight: 400 }}>
      <div className="label-tracked mb-2">AGENT NETWORK</div>

      <div className="flex-1 min-w-0">
        <svg viewBox="0 0 200 146" className="w-full" style={{ height: 340 }} aria-hidden>
          {/* Render edges (lines) */}
          {edgeLines.map(({ source, target, width, opacity }) => (
            <line
              key={`edge-${source.id}-${target.id}`}
              x1={source.x * 200}
              y1={source.y * 146}
              x2={target.x * 200}
              y2={target.y * 146}
              stroke="#60b8ff"
              strokeWidth={width}
              strokeOpacity={opacity}
            />
          ))}

          {/* Render nodes */}
          {positionedNodes.map(node => (
            <g key={`node-${node.id}`}>
              {/* Halo based on workloadLevel */}
              <circle
                key={`halo-${node.id}`}
                cx={node.x * 200}
                cy={node.y * 146}
                r={10 + node.workloadLevel * 0.12}
                fill={node.color}
                opacity={node.workloadLevel * 0.0085}
              />
              {/* Node background */}
              <circle
                key={`node-bg-${node.id}`}
                cx={node.x * 200}
                cy={node.y * 146}
                r={9 + node.workloadLevel * 0.09}
                fill="rgba(6,6,16,0.92)"
                stroke={node.color}
                strokeWidth={node.workloadLevel > 0 ? 1.5 : 0.5}
                strokeOpacity={node.workloadLevel > 0 ? 0.85 : 0.22}
              />
              {/* Emoji */}
              <text
                key={`node-emoji-${node.id}`}
                x={node.x * 200}
                y={node.y * 146 + 1}
                textAnchor="middle"
                dominantBaseline="middle"
                fontSize={node.workloadLevel > 0 ? "10" : "8"}
                style={{ userSelect: "none", pointerEvents: "none" }}
              >
                {node.emoji}
              </text>
              {/* Label */}
              <text
                key={`node-label-${node.id}`}
                x={node.x * 200}
                y={node.y * 146 + node.workloadLevel * 9 + 8}
                textAnchor="middle"
                fontSize="5.5"
                fontFamily="'Courier New', monospace"
                letterSpacing="0.08"
                fill={node.workloadLevel > 0 ? node.color : "#444"}
                style={{ userSelect: "none", pointerEvents: "none" }}
              >
                {node.shortRole}
              </text>
            </g>
          ))}
        </svg>
      </div>

      <div className="mt-2 flex items-center gap-3 flex-wrap">
        {/* Agent status summary */}
        {positionedNodes.map(node => {
          const count = taskCounts[node.id] ?? 0;
          const active = node.workloadLevel > 0;
          return (
            <div key={node.id} className="font-mono text-[8px]" style={{ color: active ? node.color : "#444" }}>
              {node.emoji} {count > 0 ? `${count} task${count !== 1 ? "s" : ""}` : "idle"}
            </div>
          );
        })}
        <div className="font-mono text-[7px] text-muted-foreground/30">
          {positionedNodes.filter(n => n.workloadLevel > 0).length} active · {edges.length} collab{edges.length !== 1 ? "s" : ""}
        </div>
      </div>
    </div>
  );
}
