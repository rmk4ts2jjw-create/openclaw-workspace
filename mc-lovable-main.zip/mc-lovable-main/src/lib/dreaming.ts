// src/lib/dreaming.ts
// Dreaming (memory consolidation) toggle for Quick Actions
// NOTE: node:fs is lazy-imported to avoid pulling it into client bundles.

import { createServerFn } from "@tanstack/react-start";
const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";

async function getDreamingFlag(): Promise<string> {
  const { join } = await import("node:path");
  return join(WORKSPACE, "data", "dreaming-enabled.flag");
}

export const getDreamingState = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const { existsSync } = await import("node:fs");
    const enabled = existsSync(await getDreamingFlag());
    return { ok: true, enabled };
  } catch (err) {
    return { ok: false, enabled: false, error: String(err) };
  }
});

export const toggleDreaming = createServerFn({ method: "POST" }).handler(async () => {
  try {
    const { existsSync, writeFileSync, unlinkSync } = await import("node:fs");
    const flag = await getDreamingFlag();
    const currentlyEnabled = existsSync(flag);
    if (currentlyEnabled) {
      // Disable dreaming — remove the flag
      try { unlinkSync(flag); } catch { /* already gone */ }
      return { ok: true, enabled: false, message: "Dreaming disabled" };
    } else {
      // Enable dreaming — create the flag
      writeFileSync(flag, new Date().toISOString(), "utf-8");
      return { ok: true, enabled: true, message: "Dreaming enabled" };
    }
  } catch (err) {
    return { ok: false, enabled: false, message: String(err) };
  }
});
