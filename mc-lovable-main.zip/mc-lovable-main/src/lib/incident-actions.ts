// src/lib/incident-actions.ts
// Response action generation engine
// Given an incident's context (title, severity, tags), produces recommended actions.

import type { IncidentAction } from "./server-data/types";

interface ActionTemplate {
  label: string;
  description: string;
  assignee?: string;
}

// ── Tag-based action templates ───────────────────────────────────────────────

const TAG_ACTIONS: Record<string, ActionTemplate[]> = {
  gateway: [
    { label: "Investigate gateway logs", description: "Check gateway error logs for crash patterns and recent failures", assignee: "engineer" },
    { label: "Inspect session files", description: "Examine gateway session files for corruption or takeover errors", assignee: "engineer" },
    { label: "Restart gateway service", description: "Perform a clean restart of the OpenClaw gateway", assignee: "lifesupport" },
    { label: "Verify service stability", description: "Monitor gateway health after restart to confirm resolution", assignee: "lifesupport" },
    { label: "Review recent deployment changes", description: "Check if recent config or code changes triggered the issue", assignee: "engineer" },
  ],
  "crash-loop": [
    { label: "Identify crash loop trigger", description: "Analyze logs to find the root cause of the crash loop", assignee: "engineer" },
    { label: "Stop affected service", description: "Gracefully stop the crashing service to prevent further damage", assignee: "lifesupport" },
    { label: "Apply temporary mitigation", description: "Implement a short-term fix to break the crash cycle", assignee: "engineer" },
    { label: "Monitor recovery", description: "Watch the service after mitigation to confirm stability", assignee: "lifesupport" },
  ],
  session: [
    { label: "Audit active sessions", description: "List all active gateway sessions and check for anomalies", assignee: "engineer" },
    { label: "Clear stale sessions", description: "Remove expired or corrupted session files", assignee: "lifesupport" },
    { label: "Verify session handling", description: "Test that new sessions can be created cleanly", assignee: "engineer" },
  ],
  cron: [
    { label: "Review cron job configuration", description: "Check the failing cron's schedule, command, and recent runs", assignee: "engineer" },
    { label: "Check cron execution logs", description: "Examine logs for the specific cron job to identify failure point", assignee: "engineer" },
    { label: "Disable problematic cron", description: "Temporarily disable the cron to prevent further failures", assignee: "lifesupport" },
    { label: "Test cron manually", description: "Run the cron command manually to verify it works", assignee: "engineer" },
  ],
  tasks: [
    { label: "Review stuck tasks", description: "Identify tasks that have been in progress with no activity", assignee: "monkey" },
    { label: "Reassign or close stale tasks", description: "Move stalled tasks back to backlog or mark as done", assignee: "monkey" },
    { label: "Check task dispatch queue", description: "Verify the task queue is processing correctly", assignee: "engineer" },
  ],
  storage: [
    { label: "Verify storage mount", description: "Check that all storage mounts are active and accessible", assignee: "lifesupport" },
    { label: "Check disk space", description: "Review disk usage and free space on all volumes", assignee: "lifesupport" },
    { label: "Test read/write operations", description: "Verify storage is functioning with test reads and writes", assignee: "engineer" },
  ],
  memory: [
    { label: "Check memory usage", description: "Review system memory consumption and identify leaks", assignee: "lifesupport" },
    { label: "Restart memory-heavy services", description: "Restart services consuming excessive memory", assignee: "lifesupport" },
    { label: "Review memory allocation", description: "Check if memory limits are configured correctly", assignee: "engineer" },
  ],
  network: [
    { label: "Test connectivity", description: "Verify network connectivity to all dependent services", assignee: "lifesupport" },
    { label: "Check DNS resolution", description: "Ensure DNS is resolving correctly", assignee: "engineer" },
    { label: "Review firewall rules", description: "Check that firewall rules aren't blocking required traffic", assignee: "lifesupport" },
  ],
  model: [
    { label: "Check provider health", description: "Verify the AI model provider is operational", assignee: "lifesupport" },
    { label: "Test model endpoint", description: "Send a test request to the model API", assignee: "engineer" },
    { label: "Review recent model changes", description: "Check if model configuration was recently changed", assignee: "engineer" },
  ],
  token: [
    { label: "Audit token usage", description: "Review recent token consumption patterns", assignee: "monkey" },
    { label: "Identify token burn source", description: "Find which jobs or sessions are consuming excessive tokens", assignee: "engineer" },
    { label: "Disable wasteful jobs", description: "Turn off jobs that burn tokens without productive output", assignee: "lifesupport" },
  ],
  timeout: [
    { label: "Review timeout configuration", description: "Check timeout settings for the affected service", assignee: "engineer" },
    { label: "Analyze slow operations", description: "Identify which operations are exceeding timeout thresholds", assignee: "engineer" },
    { label: "Increase timeout or optimize", description: "Either raise timeout limits or optimize slow operations", assignee: "engineer" },
  ],
  duplicate: [
    { label: "Identify duplicate resources", description: "Find all duplicate cron jobs, tasks, or configurations", assignee: "monkey" },
    { label: "Remove duplicates", description: "Delete or disable duplicate entries", assignee: "lifesupport" },
    { label: "Prevent future duplication", description: "Add checks to prevent the same duplication from recurring", assignee: "engineer" },
  ],
};

// ── Severity-based fallback actions ───────────────────────────────────────────

const SEVERITY_FALLBACKS: Record<string, ActionTemplate[]> = {
  P1: [
    { label: "Investigate root cause", description: "Immediately investigate the root cause of this critical incident", assignee: "engineer" },
    { label: "Assess blast radius", description: "Determine which systems and services are affected", assignee: "lifesupport" },
    { label: "Implement emergency mitigation", description: "Apply the fastest available fix to reduce impact", assignee: "engineer" },
    { label: "Notify command", description: "Escalate to human operator for awareness and guidance", assignee: "monkey" },
  ],
  P2: [
    { label: "Investigate issue", description: "Investigate the cause of this high-severity incident", assignee: "engineer" },
    { label: "Apply fix", description: "Implement a fix for the identified issue", assignee: "engineer" },
    { label: "Verify resolution", description: "Confirm the fix resolves the incident", assignee: "lifesupport" },
  ],
  P3: [
    { label: "Review and triage", description: "Review the incident and determine appropriate response", assignee: "monkey" },
    { label: "Apply standard fix", description: "Apply a standard fix procedure", assignee: "engineer" },
  ],
  P4: [
    { label: "Monitor and log", description: "Monitor the situation and log for pattern analysis", assignee: "lifesupport" },
  ],
};

// ── Title keyword matching ────────────────────────────────────────────────────

const TITLE_ACTIONS: Array<{ keywords: string[]; actions: ActionTemplate[] }> = [
  {
    keywords: ["crash", "loop", "restart", "down", "unreachable"],
    actions: [
      { label: "Check service status", description: "Verify the current state of the affected service", assignee: "lifesupport" },
      { label: "Review error logs", description: "Examine recent error logs for crash details", assignee: "engineer" },
      { label: "Attempt service recovery", description: "Try to restart or recover the service", assignee: "lifesupport" },
    ],
  },
  {
    keywords: ["token", "burn", "cost", "quota", "usage"],
    actions: [
      { label: "Audit token consumption", description: "Review which processes are consuming tokens", assignee: "monkey" },
      { label: "Identify wasteful processes", description: "Find processes that burn tokens without value", assignee: "engineer" },
      { label: "Disable wasteful processes", description: "Turn off identified wasteful processes", assignee: "lifesupport" },
    ],
  },
  {
    keywords: ["stale", "stuck", "hung", "frozen", "no progress"],
    actions: [
      { label: "Identify blocked processes", description: "Find which processes are stuck and why", assignee: "engineer" },
      { label: "Unblock or terminate", description: "Either unblock the process or terminate it cleanly", assignee: "lifesupport" },
      { label: "Review blocking conditions", description: "Check what conditions caused the blockage", assignee: "engineer" },
    ],
  },
  {
    keywords: ["disk", "storage", "space", "full", "mount"],
    actions: [
      { label: "Check disk usage", description: "Review disk space usage across all volumes", assignee: "lifesupport" },
      { label: "Clear temporary files", description: "Remove temporary files and caches to free space", assignee: "lifesupport" },
      { label: "Verify mount integrity", description: "Check that all storage mounts are healthy", assignee: "engineer" },
    ],
  },
  {
    keywords: ["memory", "leak", "oom", "ram"],
    actions: [
      { label: "Check memory usage", description: "Review current memory consumption", assignee: "lifesupport" },
      { label: "Identify memory leak source", description: "Find which process is leaking memory", assignee: "engineer" },
      { label: "Restart affected service", description: "Restart the service to reclaim memory", assignee: "lifesupport" },
    ],
  },
];

// ── Main generation function ──────────────────────────────────────────────────

function generateId(): string {
  return `act-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}

export function generateResponseActions(
  title: string,
  severity: "P1" | "P2" | "P3" | "P4",
  tags: string[],
  owner: string,
): IncidentAction[] {
  const collected: ActionTemplate[] = [];
  const seen = new Set<string>();

  // 1. Tag-based actions
  for (const tag of tags) {
    const tagLower = tag.toLowerCase();
    for (const [key, actions] of Object.entries(TAG_ACTIONS)) {
      if (tagLower.includes(key) || key.includes(tagLower)) {
        for (const a of actions) {
          if (!seen.has(a.label)) {
            seen.add(a.label);
            collected.push(a);
          }
        }
      }
    }
  }

  // 2. Title keyword matching
  const titleLower = title.toLowerCase();
  for (const entry of TITLE_ACTIONS) {
    for (const kw of entry.keywords) {
      if (titleLower.includes(kw)) {
        for (const a of entry.actions) {
          if (!seen.has(a.label)) {
            seen.add(a.label);
            collected.push(a);
          }
        }
        break;
      }
    }
  }

  // 3. Severity fallback — always ensure at least investigation action for P1/P2
  if (collected.length < 2 || severity === "P1" || severity === "P2") {
    const fallbacks = SEVERITY_FALLBACKS[severity] || SEVERITY_FALLBACKS.P3;
    for (const a of fallbacks) {
      if (!seen.has(a.label)) {
        seen.add(a.label);
        collected.push(a);
      }
    }
  }

  // 4. P1/P2 quality rule: must have at least one investigation action
  if (severity === "P1" || severity === "P2") {
    const hasInvestigation = collected.some(a =>
      a.label.toLowerCase().includes("investigate") ||
      a.label.toLowerCase().includes("root cause") ||
      a.label.toLowerCase().includes("review")
    );
    if (!hasInvestigation) {
      collected.unshift({
        label: `Investigate ${title.split("—")[0].trim().slice(0, 40)}`,
        description: `Investigate the root cause of this ${severity} incident`,
        assignee: owner,
      });
    }
  }

  // Convert to IncidentAction with IDs and suggested status
  return collected.map(a => ({
    id: generateId(),
    label: a.label,
    description: a.description,
    status: "suggested" as const,
    assignee: a.assignee || owner,
  }));
}
