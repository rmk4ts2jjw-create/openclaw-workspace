// src/lib/persist.ts
// Lightweight localStorage persistence for UI state.

const STORAGE_KEY = "mission-control-state";

export interface PersistedState {
  lastView: string;
  taskOrder: Record<string, string[]>; // status -> ordered task IDs
  collapsedSections: string[];
  quickActionsOpen: boolean;
}

const DEFAULT_STATE: PersistedState = {
  lastView: "/",
  taskOrder: {},
  collapsedSections: [],
  quickActionsOpen: true,
};

export function loadState(): PersistedState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_STATE;
    return { ...DEFAULT_STATE, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_STATE;
  }
}

export function saveState(state: Partial<PersistedState>): void {
  try {
    const current = loadState();
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...current, ...state }));
  } catch {
    // localStorage full or unavailable — silently ignore
  }
}

export function saveTaskOrder(status: string, taskIds: string[]): void {
  const state = loadState();
  state.taskOrder[status] = taskIds;
  saveState({ taskOrder: state.taskOrder });
}

export function getTaskOrder(status: string): string[] | undefined {
  return loadState().taskOrder[status];
}
