// src/lib/server-data/system.ts

import { createServerFn } from "@tanstack/react-start";
// node:fs lazy-imported below to avoid client bundle leak
import { WORKSPACE, OPENCLAW_DIR, type SystemStats, type SystemHealth, type ActionResult } from "./types";
import { readJsonOrNull, formatBytes, parseSize } from "./helpers";

export const getSystemStats = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const cfg = await readJsonOrNull<Record<string, unknown>>(`${OPENCLAW_DIR}/openclaw.json`);
    const agents = cfg?.agents as Record<string, unknown> | undefined;
    const defaults = agents?.defaults as Record<string, unknown> | undefined;
    const modelConfig = defaults?.model as Record<string, unknown> | undefined;
    // Cron counts now fetched from gateway CLI below (not stale config)

    let workspaceFiles = 0;
    try { const { readdirSync: rd } = await import("node:fs"); workspaceFiles = rd(WORKSPACE).length; } catch { /* ignore */ }

    let cpuLoad = "0";
    let diskUsed = "—"; let diskFree = "—"; let diskTotal = "—"; let diskPercent = 0;
    let memoryUsed = "—"; let memoryTotal = "—"; let memoryPercent = 0;
    let uptime = "—"; let gatewayStatus = "unknown"; let gatewayUptime = "—";
    let wdDiskUsed = "—"; let wdDiskTotal = "—"; let wdDiskPercent = 0; let wdDiskMount = "—";

    try {
      const { execSync } = await import("node:child_process");

      try { const loadOut = execSync("sysctl -n vm.loadavg", { encoding: "utf-8" }).trim(); const parts = loadOut.match(/[\d.]+/g); cpuLoad = parts && parts[1] ? parts[1] : "0"; } catch { /* */ }

      try {
        const df = execSync("df -h / | tail -1 | awk '{print $2, $3, $4, $5}'", { encoding: "utf-8" }).trim().split(" ");
        if (df.length >= 4) { diskTotal = df[0]; diskUsed = df[1]; diskFree = df[2]; diskPercent = parseInt(df[3].replace("%", "")) || 0; }
      } catch { /* */ }

      try {
        const dfOut = execSync("df -h", { encoding: "utf-8" });
        const lines = dfOut.split("\n");
        for (const line of lines) {
          if (/wd|mycloud|public/i.test(line)) {
            const cols = line.trim().split(/\s+/);
            if (cols.length >= 6) {
              wdDiskTotal = cols[1]; wdDiskUsed = cols[2]; wdDiskMount = cols[5];
              const usedNum = parseSize(cols[2]); const totalNum = parseSize(cols[1]);
              if (totalNum > 0) wdDiskPercent = Math.round((usedNum / totalNum) * 100);
              break;
            }
          }
        }
      } catch { /* */ }

      try {
        const vmStat = execSync("vm_stat", { encoding: "utf-8" });
        const pageSizeMatch = vmStat.match(/page size of (\d+) bytes/);
        const pageSize = pageSizeMatch ? parseInt(pageSizeMatch[1]) : 4096;
        const parse = (key: string) => { const m = vmStat.match(new RegExp(`${key}:\\s+(\\d+)`)); return m ? parseInt(m[1]) : 0; };
        const usedBytes = (parse("Pages active") + parse("Pages wired down") + parse("Pages speculative")) * pageSize;
        const totalBytes = parseInt(execSync("sysctl -n hw.memsize", { encoding: "utf-8" }).trim()) || 0;
        if (totalBytes > 0) {
          memoryPercent = Math.round((usedBytes / totalBytes) * 100);
          memoryUsed = formatBytes(usedBytes); memoryTotal = formatBytes(totalBytes);
        }
      } catch { /* */ }

      try {
        const btOut = execSync("sysctl -n kern.boottime", { encoding: "utf-8" }).trim();
        const secMatch = btOut.match(/sec\s*=\s*(\d+)/);
        if (secMatch) {
          const upMs = Date.now() - parseInt(secMatch[1]) * 1000;
          if (upMs > 0) {
            const d = Math.floor(upMs / 86400000); const h = Math.floor((upMs % 86400000) / 3600000); const m = Math.floor((upMs % 3600000) / 60000);
            uptime = d > 0 ? `${d}d ${h}h ${m}m` : `${h}h ${m}m`;
          }
        }
      } catch { /* */ }

      try {
        const gw = execSync("openclaw gateway status 2>/dev/null", { encoding: "utf-8" }).trim();
        gatewayStatus = gw.toLowerCase().includes("running") ? "running" : gw.toLowerCase().includes("stopped") ? "stopped" : "unknown";
        try {
          const gwPid = execSync("pgrep -f 'openclaw' | head -1", { encoding: "utf-8" }).trim();
          if (gwPid) {
            const gwStart = execSync("ps -o lstart= -p " + gwPid, { encoding: "utf-8" }).trim();
            if (gwStart) { const gwH = Math.floor((Date.now() - new Date(gwStart).getTime()) / 3600000); const gwM = Math.floor(((Date.now() - new Date(gwStart).getTime()) % 3600000) / 60000); gatewayUptime = `${gwH}h ${gwM}m`; }
          }
        } catch { /* */ }
      } catch { gatewayStatus = "unknown"; }

    } catch { /* ignore all */ }

    // Get real OpenClaw version from CLI (not stale config)
    let openclawVersion = "unknown";
    try {
      const { execSync } = await import("node:child_process");
      const verOut = execSync("openclaw --version 2>/dev/null", { encoding: "utf-8" }).trim();
      const verMatch = verOut.match(/(\d{4}\.\d+\.\d+)/);
      if (verMatch) openclawVersion = verMatch[1];
    } catch { /* fallback to unknown */ }

    // Get real cron counts from gateway (not stale config)
    let activeCrons = 0;
    let totalCrons = 0;
    try {
      const { execSync } = await import("node:child_process");
      const cronOut = execSync("openclaw cron list --json 2>/dev/null", { encoding: "utf-8", timeout: 10000 }).trim();
      const cronData = JSON.parse(cronOut);
      const jobs = cronData.jobs || cronData || [];
      totalCrons = jobs.length;
      activeCrons = jobs.filter((j: Record<string, unknown>) => j.enabled !== false).length;
    } catch { /* fallback to 0/0 */ }

    return {
      hostname: "spacemonkey", uptime, gatewayUptime,
      diskUsed, diskFree, diskTotal, diskPercent,
      wdDiskUsed, wdDiskTotal, wdDiskPercent, wdDiskMount,
      memoryUsed, memoryTotal, memoryPercent, cpuLoad,
      openclawVersion,
      model: String(modelConfig?.primary || "unknown"),
      gatewayStatus, activeCrons, totalCrons, workspaceFiles, lastBackup: "—",
    } as SystemStats;
  } catch (e) { console.error("[getSystemStats] ERROR:", e); throw e; }
});

export const getSystemHealth = createServerFn({ method: "GET" }).handler(async () => {
  const { execSync } = await import("node:child_process");
  try {
    const loadOut = execSync("sysctl -n vm.loadavg", { encoding: "utf-8" }).trim();
    const loadParts = loadOut.match(/[\d.]+/g);
    const cpu = loadParts && loadParts[1] ? loadParts[1] : "—";
    const mem = execSync("vm_stat | head -5", { encoding: "utf-8" }).trim();
    const dfOut = execSync("df -h / | tail -1", { encoding: "utf-8" }).trim();
    const dfCols = dfOut.split(/\s+/);
    const disk = dfCols.length >= 5 ? `${dfCols[2]} ${dfCols[3]} ${dfCols[4]}` : "—";
    const gwOut = execSync("openclaw gateway status 2>/dev/null", { encoding: "utf-8" }).trim();
    const gateway = gwOut.toLowerCase().includes("running") ? "running" : gwOut.toLowerCase().includes("stopped") ? "stopped" : "unknown";
    return { cpu, mem, disk, gateway, timestamp: new Date().toISOString() };
  } catch { return { cpu: "—", mem: "—", disk: "—", gateway: "unknown", timestamp: new Date().toISOString() }; }
});
