// src/lib/server-data/auto-remediation.ts
// Predefined remediation actions for common failure patterns

export interface RemediationRule {
  id: string;
  label: string;
  description: string;
  /** Check if this rule applies to the given error/title */
  matches: (title: string, error: string) => boolean;
  /** Execute the remediation. Returns a summary of what was done. */
  execute: () => Promise<RemediationResult>;
  /** Whether this rule requires Andre's approval before executing */
  requiresApproval: boolean;
}

export interface RemediationResult {
  ruleId: string;
  success: boolean;
  action: string;
  detail: string;
}

// ── Rules ────────────────────────────────────────────────────────────────────

const RULES: RemediationRule[] = [
  {
    id: "vite-cache-corruption",
    label: "Vite Cache Corruption",
    description: "Clear Vite cache and restart dev server when 504/optimize-dep errors detected",
    matches: (title, error) => {
      const text = `${title} ${error}`.toLowerCase();
      return (
        (text.includes("vite") || text.includes("504") || text.includes("outdated optimize")) &&
        (text.includes("cache") || text.includes("corrupt") || text.includes("dep"))
      );
    },
    requiresApproval: false,
    execute: async (): Promise<RemediationResult> => {
      const { execSync } = await import("child_process");
      try {
        const mcDir = "/Users/spacemonkey/.openclaw/workspace/mission-control-dashboard";
        // Clear Vite cache
        execSync(`cd ${mcDir} && rm -rf node_modules/.vite .vite`, { timeout: 10000 });
        // Kill existing Vite process
        try {
          execSync("pkill -f 'vite dev' 2>/dev/null || true", { timeout: 5000 });
        } catch { /* ignore if no process */ }
        // Restart Vite
        execSync(`cd ${mcDir} && nohup bun run dev --host --port 3000 > /tmp/mc-dev.log 2>&1 &`, {
          timeout: 5000,
        });
        // Wait and verify
        await new Promise((r) => setTimeout(r, 3000));
        const http = await import("http");
        const ok = await new Promise<boolean>((resolve) => {
          const req = http.get("http://localhost:3000/", (res) => {
            resolve(res.statusCode === 200);
          });
          req.on("error", () => resolve(false));
          req.setTimeout(3000, () => { req.destroy(); resolve(false); });
        });
        return {
          ruleId: "vite-cache-corruption",
          success: ok,
          action: "Cleared Vite cache and restarted dev server",
          detail: ok ? "MC dashboard responding 200 on port 3000" : "MC dashboard not responding after restart",
        };
      } catch (err) {
        return {
          ruleId: "vite-cache-corruption",
          success: false,
          action: "Attempted Vite cache clear + restart",
          detail: `Error: ${String(err)}`,
        };
      }
    },
  },
  {
    id: "cron-timeout-retry",
    label: "Cron Timeout Retry",
    description: "Disable and re-enable a cron job that's timing out repeatedly",
    matches: (title, error) => {
      const text = `${title} ${error}`.toLowerCase();
      return text.includes("cron") && (text.includes("timeout") || text.includes("timed out"));
    },
    requiresApproval: true, // Changing cron state needs approval
    execute: async (): Promise<RemediationResult> => {
      return {
        ruleId: "cron-timeout-retry",
        success: false,
        action: "Requires Andre approval to disable/re-enable cron",
        detail: "Auto-remediation for cron timeouts requires human approval. Flagged for triage.",
      };
    },
  },
  {
    id: "rate-limit-backoff",
    label: "Rate Limit Backoff",
    description: "Pause non-critical cron jobs when rate limits are detected",
    matches: (title, error) => {
      const text = `${title} ${error}`.toLowerCase();
      return text.includes("429") || text.includes("rate limit");
    },
    requiresApproval: true, // Pausing crons needs approval
    execute: async (): Promise<RemediationResult> => {
      return {
        ruleId: "rate-limit-backoff",
        success: false,
        action: "Requires Andre approval to pause cron jobs",
        detail: "Rate limit remediation requires human approval. Flagged for triage.",
      };
    },
  },
  {
    id: "disk-space-cleanup",
    label: "Disk Space Cleanup",
    description: "Clear temporary files and caches when disk space is low",
    matches: (title, error) => {
      const text = `${title} ${error}`.toLowerCase();
      return (
        (text.includes("disk") || text.includes("space") || text.includes("storage")) &&
        (text.includes("full") || text.includes("low") || text.includes("no space"))
      );
    },
    requiresApproval: false,
    execute: async (): Promise<RemediationResult> => {
      const { execSync } = await import("child_process");
      try {
        // Safe cleanup targets
        const cleanupCmds = [
          "rm -rf /tmp/mc-dev.log /tmp/vite-*.log 2>/dev/null || true",
          "cd /Users/spacemonkey/.openclaw/workspace/mission-control-dashboard && rm -rf node_modules/.vite .vite 2>/dev/null || true",
        ];
        for (const cmd of cleanupCmds) {
          execSync(cmd, { timeout: 10000 });
        }
        // Check disk after
        const df = execSync("df -h / | tail -1", { timeout: 5000 }).toString().trim();
        return {
          ruleId: "disk-space-cleanup",
          success: true,
          action: "Cleared temp files and Vite cache",
          detail: `Disk status: ${df}`,
        };
      } catch (err) {
        return {
          ruleId: "disk-space-cleanup",
          success: false,
          action: "Attempted disk cleanup",
          detail: `Error: ${String(err)}`,
        };
      }
    },
  },
];

// ── Public API ───────────────────────────────────────────────────────────────

/** Find all remediation rules that match a given error/title */
export function findMatchingRules(title: string, error: string): RemediationRule[] {
  return RULES.filter((r) => r.matches(title, error));
}

/** Execute a remediation rule by ID */
export function executeRule(ruleId: string): Promise<RemediationResult> {
  const rule = RULES.find((r) => r.id === ruleId);
  if (!rule) {
    return Promise.resolve({
      ruleId,
      success: false,
      action: "Rule not found",
      detail: `No remediation rule with ID: ${ruleId}`,
    });
  }
  return rule.execute();
}

/** Get all available rules (for display in UI) */
export function getAllRules(): RemediationRule[] {
  return [...RULES];
}

/** Run auto-remediation check — returns results for all matching rules */
export async function runAutoRemediation(title: string, error: string): Promise<{
  matched: number;
  executed: number;
  results: RemediationResult[];
}> {
  const matching = findMatchingRules(title, error);
  const results: RemediationResult[] = [];
  let executed = 0;

  for (const rule of matching) {
    if (rule.requiresApproval) {
      results.push({
        ruleId: rule.id,
        success: false,
        action: rule.label,
        detail: "Requires Andre approval — flagged for triage",
      });
    } else {
      const result = await rule.execute();
      results.push(result);
      executed++;
    }
  }

  return { matched: matching.length, executed, results };
}
