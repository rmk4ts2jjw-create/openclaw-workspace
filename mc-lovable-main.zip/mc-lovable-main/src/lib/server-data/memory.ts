// src/lib/server-data/memory.ts
// NOTE: node:fs is lazy-imported to avoid pulling it into client bundles.

import { createServerFn } from "@tanstack/react-start";
import { WORKSPACE, type MemoryEntry } from "./types";
import { readFileOrNull, extractTitle } from "./helpers";

export const getDailyLogs = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const { existsSync, readdirSync, readFileSync } = await import("node:fs");
    const memDir = `${WORKSPACE}/memory`;
    if (!existsSync(memDir)) return [];
    const files = readdirSync(memDir)
      .filter((f) => /^\d{4}-\d{2}-\d{2}\.md$/.test(f))
      .sort()
      .reverse();
    return files.map((file) => {
      const body = readFileSync(`${memDir}/${file}`, "utf-8");
      const date = file.replace(".md", "");
      const words = body.split(/\s+/).filter(Boolean).length;
      return { date, words, title: extractTitle(body), body } as MemoryEntry;
    });
  } catch { return []; }
});

export const getLongTermMemory = createServerFn({ method: "GET" }).handler(async () => {
  return (await readFileOrNull(`${WORKSPACE}/MEMORY.md`)) || "# Long-Term Memory\n\nNo long-term memory file found.";
});

export const getWikiStats = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const { existsSync, readdirSync } = await import("node:fs");
    const vault = "/Users/spacemonkey/.openclaw/wiki/main";
    if (!existsSync(vault)) return null;
    const dirs = ["entities", "concepts", "sources", "syntheses", "reports"];
    const stats: Record<string, number> = {};
    let totalPages = 0;
    for (const dir of dirs) {
      const dirPath = `${vault}/${dir}`;
      if (!existsSync(dirPath)) { stats[dir] = 0; continue; }
      const files = readdirSync(dirPath).filter((f: string) => f.endsWith(".md") && f !== "index.md");
      stats[dir] = files.length;
      totalPages += files.length;
    }
    const sourceFiles = readdirSync(`${vault}/sources`).filter((f: string) => f.startsWith("bridge-"));
    stats["bridge"] = sourceFiles.length;
    stats["total"] = totalPages;
    return stats;
  } catch {
    return null;
  }
});
