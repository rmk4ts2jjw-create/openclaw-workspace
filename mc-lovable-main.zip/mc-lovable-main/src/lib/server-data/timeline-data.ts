// src/lib/server-data/timeline-data.ts
// Unified event model — all station events feed into a single timeline
// NOTE: node:fs/node:path are lazy-imported inside createServerFn handlers only.

import { createServerFn } from "@tanstack/react-start";
import type { Task, Incident } from "./types";

const WORKSPACE = process.env.OPENCLAW_WORKSPACE || "/Users/spacemonkey/.openclaw/workspace";

export type TimelineEventType =
  | "task_created"
  | "task_started"
  | "task_completed"
  | "task_stalled"
  | "incident_created"
  | "incident_status_change"
  | "incident_resolved"
  | "cron_success"
  | "cron_failure"
  | "system_health";

export interface TimelineEvent {
  id: string;
  ts: string;
  type: TimelineEventType;
  source: string;
  severity: "info" | "warning" | "critical";
  title: string;
  description: string;
  actor?: string;
  entityId?: string;
  entityUrl?: string;
  metadata?: Record<string, string>;
}

// ── Internal helpers (server-only, never exported to client) ─────────────────

async function readJsonFile<T>(path: string): Promise<T | null> {
  const { existsSync, readFileSync } = await import("node:fs");
  if (!existsSync(path)) return null;
  try { return JSON.parse(readFileSync(path, "utf-8")) as T; } catch { return null; }
}

async function readTasks(): Promise<Task[]> {
  const { normalizeTasks } = await import("./helpers");
  const { join } = await import("node:path");
  const raw = await readJsonFile<unknown>(join(WORKSPACE, "data", "tasks.json"));
  return normalizeTasks(raw) as unknown as Task[];
}

async function readIncidents(): Promise<Incident[]> {
  const { join } = await import("node:path");
  return await readJsonFile<Incident[]>(join(WORKSPACE, "data", "incidents.json")) || [];
}

async function readCrons(): Promise<any[]> {
  const { join } = await import("node:path");
  return await readJsonFile<any[]>(join(WORKSPACE, "data", "crons.json")) || [];
}

function eventsFromTasks(tasks: Task[]): TimelineEvent[] {
  const events: TimelineEvent[] = [];
  for (const task of tasks) {
    const history = task.history || [];
    for (const entry of history) {
      const { ts, actor, details } = { ts: entry.ts, actor: entry.actor || "system", details: entry.details || "" };
      switch (entry.action) {
        case "created":
          events.push({ id: `evt-${task.id}-created`, ts, type: "task_created", source: "task", severity: "info", title: `Task created: ${task.title}`, description: details, actor, entityId: task.id, entityUrl: "/tasks" });
          break;
        case "started":
          events.push({ id: `evt-${task.id}-started`, ts, type: "task_started", source: "task", severity: "info", title: `Task started: ${task.title}`, description: details, actor, entityId: task.id, entityUrl: "/tasks" });
          break;
        case "completed":
          events.push({ id: `evt-${task.id}-completed`, ts, type: "task_completed", source: "task", severity: "info", title: `Task completed: ${task.title}`, description: details, actor, entityId: task.id, entityUrl: "/tasks" });
          break;
        case "stalled":
          events.push({ id: `evt-${task.id}-stalled`, ts, type: "task_stalled", source: "task", severity: "warning", title: `Task stalled: ${task.title}`, description: details, actor, entityId: task.id, entityUrl: "/tasks" });
          break;
        case "reassigned":
          if (details.toLowerCase().includes("triage")) {
            events.push({ id: `evt-${task.id}-triage-${ts}`, ts, type: "task_stalled", source: "task", severity: "warning", title: `Task moved to triage: ${task.title}`, description: details, actor, entityId: task.id, entityUrl: "/tasks" });
          }
          break;
      }
    }
  }
  return events;
}

function eventsFromIncidents(incidents: Incident[]): TimelineEvent[] {
  const events: TimelineEvent[] = [];
  for (const inc of incidents) {
    events.push({ id: `evt-${inc.id}-created`, ts: inc.opened, type: "incident_created", source: "incident", severity: inc.severity === "P1" ? "critical" : inc.severity === "P2" ? "warning" : "info", title: `Incident opened: ${inc.title}`, description: inc.summary, actor: "system", entityId: inc.id, entityUrl: "/incidents", metadata: { severity: inc.severity } });
    for (const tl of inc.timeline || []) {
      events.push({ id: `evt-${inc.id}-tl-${tl.ts}`, ts: tl.ts, type: "incident_status_change", source: "incident", severity: "info", title: `${inc.id}: ${tl.message}`, description: tl.message, actor: tl.actor || "system", entityId: inc.id, entityUrl: "/incidents" });
    }
    if (inc.resolved) {
      events.push({ id: `evt-${inc.id}-resolved`, ts: inc.resolved, type: "incident_resolved", source: "incident", severity: "info", title: `Incident resolved: ${inc.title}`, description: `${inc.id} resolved`, actor: "system", entityId: inc.id, entityUrl: "/incidents" });
    }
  }
  return events;
}

function eventsFromCrons(crons: any[]): TimelineEvent[] {
  const events: TimelineEvent[] = [];
  for (const cron of crons) {
    if (cron.lastError) {
      events.push({ id: `evt-cron-${cron.id}-error`, ts: cron.lastRun || new Date().toISOString(), type: "cron_failure", source: "cron", severity: cron.consecutiveErrors >= 3 ? "critical" : "warning", title: `Cron failed: ${cron.name}`, description: cron.lastError || "Unknown error", actor: "system", entityId: cron.id, entityUrl: "/scheduler", metadata: { consecutiveErrors: String(cron.consecutiveErrors || 1), schedule: cron.schedule || "" } });
    }
    if (cron.lastRun && !cron.lastError) {
      events.push({ id: `evt-cron-${cron.id}-ok`, ts: cron.lastRun, type: "cron_success", source: "cron", severity: "info", title: `Cron ran: ${cron.name}`, description: `Scheduled: ${cron.schedule || "unknown"}`, actor: "system", entityId: cron.id, entityUrl: "/scheduler" });
    }
  }
  return events;
}

async function buildTimeline(filter?: { source?: string; type?: string; severity?: string; limit?: number }): Promise<TimelineEvent[]> {
  const [tasks, incidents, crons] = await Promise.all([readTasks(), readIncidents(), readCrons()]);
  let events: TimelineEvent[] = [...eventsFromTasks(tasks), ...eventsFromIncidents(incidents), ...eventsFromCrons(crons)];
  events.sort((a, b) => new Date(b.ts).getTime() - new Date(a.ts).getTime());
  if (filter?.source) events = events.filter((e) => e.source === filter.source);
  if (filter?.type) events = events.filter((e) => e.type === filter.type);
  if (filter?.severity) events = events.filter((e) => e.severity === filter.severity);
  if (filter?.limit) events = events.slice(0, filter.limit);
  return events;
}

// ── Public API (all wrapped in createServerFn) ───────────────────────────────

export const getTimelineEvents = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => d as { source?: string; type?: string; severity?: string; limit?: number } | undefined)
  .handler(async ({ data }) => {
    return buildTimeline(data);
  });

export const getIncidentTimeline = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => d as string)
  .handler(async ({ data: incidentId }) => {
    const incidents = await readIncidents();
    const inc = incidents.find((i) => i.id === incidentId);
    if (!inc) return [];
    const events = eventsFromIncidents([inc]);
    events.sort((a, b) => new Date(a.ts).getTime() - new Date(b.ts).getTime());
    return events;
  });

export const getRecentEvents = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => d as number | undefined)
  .handler(async ({ data: limit }) => {
    return buildTimeline({ limit: limit || 10 });
  });

export const getTimelineSummary = createServerFn({ method: "GET" }).handler(async () => {
  const events = await buildTimeline();
  const bySource: Record<string, number> = { task: 0, incident: 0, cron: 0, system: 0 };
  let critical = 0;
  let warnings = 0;
  for (const e of events) {
    bySource[e.source] = (bySource[e.source] || 0) + 1;
    if (e.severity === "critical") critical++;
    if (e.severity === "warning") warnings++;
  }
  return { total: events.length, critical, warnings, bySource };
});
