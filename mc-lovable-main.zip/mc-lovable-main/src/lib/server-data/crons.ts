// src/lib/server-data/crons.ts
// Reads cron jobs from the SQLite DB via CLI (Cloudflare Workers compat — no native modules)
import { createServerFn } from "@tanstack/react-start";

const CRON_DB = "/Users/spacemonkey/.openclaw/state/openclaw.sqlite";
const CRON_STORE = "/Users/spacemonkey/.openclaw/cron/jobs.json";

export const getCronJobs = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const { execSync } = await import("node:child_process");
    const sql = `SELECT job_id, name, enabled, schedule_expr, schedule_tz, payload_message, state_json FROM cron_jobs WHERE store_key = '${CRON_STORE}' ORDER BY sort_order ASC, updated_at DESC;`;
    const output = execSync(`/usr/bin/sqlite3 -json "${CRON_DB}" "${sql}"`, {
      encoding: "utf-8",
      timeout: 5000,
    });
    const rows = JSON.parse(output) as Record<string, unknown>[];
    return rows.map((row) => {
      const state = JSON.parse(String(row.state_json || "{}")) as Record<string, unknown>;
      return {
        id: String(row.job_id || ""),
        name: String(row.name || "Unknown"),
        schedule: String(row.schedule_expr || ""),
        enabled: row.enabled === 1 || row.enabled === true,
        status: String(state.lastRunStatus || "ok"),
        lastError: String(state.lastError || ""),
        consecutiveErrors: Number(state.consecutiveErrors || 0),
        nextRun: state.lastRunAtMs ? new Date(Number(state.lastRunAtMs)).toISOString() : "active",
        description: String(row.payload_message || "").slice(0, 120),
      };
    });
  } catch {
    return [];
  }
});
