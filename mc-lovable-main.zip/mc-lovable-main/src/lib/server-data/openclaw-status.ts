// src/lib/server-data/openclaw-status.ts

import { createServerFn } from "@tanstack/react-start";
import { OPENCLAW_DIR, WORKSPACE, type OpenClawStatus, type OpenClawCronJob, type Task } from "./types";
import { readJsonOrNull, normalizeTasks } from "./helpers";

export const getOpenClawStatus = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const cfg = await readJsonOrNull<Record<string, unknown>>(`${OPENCLAW_DIR}/openclaw.json`);
    const models = cfg?.agents as Record<string, unknown> | undefined;
    const defaults = models?.defaults as Record<string, unknown> | undefined;
    const modelConfig = defaults?.model as Record<string, unknown> | undefined;
    const channels = cfg?.channels as Record<string, unknown> | undefined;
    const channelNames = channels ? Object.keys(channels).filter((k) => (channels[k] as Record<string, unknown>)?.enabled) : [];
    const skills = cfg?.skills as Record<string, unknown> | undefined;
    const enabledSkills = skills ? Object.entries(skills).filter(([, v]) => (v as Record<string, unknown>)?.enabled).length : 0;

    // Get real version from CLI
    let version = "unknown";
    try {
      const { execSync } = await import("node:child_process");
      const verOut = execSync("openclaw --version 2>/dev/null", { encoding: "utf-8" }).trim();
      const verMatch = verOut.match(/(\d{4}\.\d+\.\d+)/);
      if (verMatch) version = verMatch[1];
    } catch { /* fallback */ }

    // Get real gateway status
    let gateway: string = "unknown";
    try {
      const { execSync } = await import("node:child_process");
      const gwOut = execSync("openclaw gateway status 2>/dev/null", { encoding: "utf-8" }).trim();
      gateway = gwOut.toLowerCase().includes("running") ? "running" : gwOut.toLowerCase().includes("stopped") ? "stopped" : "unknown";
    } catch { /* fallback */ }

    // Get session count from full status output
    let sessions: number = 0;
    try {
      const { execSync } = await import("node:child_process");
      const statusOut = execSync("openclaw status 2>/dev/null", { encoding: "utf-8" }).trim();
      const sessMatch = statusOut.match(/sessions\s+(\d+)/i);
      if (sessMatch) sessions = parseInt(sessMatch[1]) || 0;
    } catch { /* fallback */ }

    // Get real task counts
    let tasksActive = 0;
    try {
      const { readJsonOrNull: readJson } = await import("./helpers");
      const { WORKSPACE: WS } = await import("./types");
      const { join: j } = await import("node:path");
      const rawTaskData = (await readJson<unknown>(j(WS, "data", "tasks.json")));
      const taskData = normalizeTasks(rawTaskData) as unknown as Task[];
      tasksActive = taskData.filter((t: any) => t.status === "in_progress").length;
    } catch { /* fallback */ }

    return {
      gateway,
      version,
      dashboard: "http://127.0.0.1:18789/",
      channel: channelNames.join(", ") || "none",
      sessions,
      model: String(modelConfig?.primary || "unknown"),
      ctx: "1M",
      uptime: gateway === "running" ? "running" : "stopped",
      heartbeat: "30m",
      tasksActive,
      tasksQueued: 0,
      memoryPlugin: enabledSkills > 0 ? "enabled" : "not checked",
    } as OpenClawStatus;
  } catch (e) { console.error("[getOpenClawStatus] ERROR:", e); throw e; }
});

export const getOpenClawCrons = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const { execSync } = await import("node:child_process");
    const output = execSync("/opt/homebrew/bin/openclaw cron list --all --json", { encoding: "utf-8", timeout: 10000 });
    const data = JSON.parse(output);
    const jobs = (data.jobs || []) as Record<string, unknown>[];
    return jobs.map((j) => {
      const state = (j.state || {}) as Record<string, unknown>;
      const schedule = (j.schedule || {}) as Record<string, unknown>;
      const payload = (j.payload || {}) as Record<string, unknown>;
      return {
        id: String(j.id || ""),
        name: String(j.name || "Unknown"),
        schedule: String(schedule.expr || ""),
        enabled: j.enabled !== false,
        status: String(state.lastRunStatus || "never"),
        lastRun: state.lastRunAtMs ? new Date(Number(state.lastRunAtMs)).toISOString() : "—",
        nextRun: state.nextRunAtMs ? new Date(Number(state.nextRunAtMs)).toISOString() : "—",
        message: String(payload.message || "").slice(0, 150),
      } as OpenClawCronJob;
    });
  } catch (err) { console.error("[getOpenClawCrons] Error:", err); return []; }
});

export const getAwaitingReviewCount = createServerFn({ method: "GET" }).handler(async () => {
  const raw = await readJsonOrNull<unknown>(`${WORKSPACE}/data/tasks.json`);
  const taskData = normalizeTasks(raw) as unknown as Task[];
  const count = taskData.filter((t: any) => t.status === "awaiting_review").length;
  return { count };
});
