// workload.ts — bridge between raw task counts (0‑100) and WorkloadLevel
import { tasksToLevel, WorkloadLevel } from "./room-energy";

/**
 * Convert a scalar workload percentage (0‑100) to a WorkloadLevel.
 * Keeps the existing tasksToLevel for backward compatibility.
 */
export function workloadToLevel(percent: number): WorkloadLevel {
  // Clamp
  const p = Math.max(0, Math.min(100, percent));
  if (p >= 80) return "critical";
  if (p >= 60) return "heavy";
  if (p >= 40) return "medium";
  if (p >= 20) return "light";
  return "idle";
}

// Re‑export for backward compatibility
export { tasksToLevel, type WorkloadLevel };
