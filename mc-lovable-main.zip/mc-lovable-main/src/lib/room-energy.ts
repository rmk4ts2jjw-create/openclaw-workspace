// room-energy.ts — workload levels, energy values, and ambient activity simulation.
// WorkloadLevel drives: animation speed, monitor brightness, room glow, visual urgency.

import { useState, useEffect, useRef } from "react";

export type WorkloadLevel = "idle" | "light" | "medium" | "heavy" | "critical";

export function levelToEnergy(level: WorkloadLevel): number {
  switch (level) {
    case "idle":     return 0;
    case "light":    return 0.25;
    case "medium":   return 0.5;
    case "heavy":    return 0.75;
    case "critical": return 1.0;
  }
}

export function levelToSpeed(level: WorkloadLevel): number {
  switch (level) {
    case "idle":     return 1.0;
    case "light":    return 1.2;
    case "medium":   return 1.5;
    case "heavy":    return 2.0;
    case "critical": return 2.8;
  }
}

export function tasksToLevel(tasks: number, hasCritical = false): WorkloadLevel {
  if (hasCritical) return "critical";
  if (tasks >= 5) return "heavy";
  if (tasks >= 3) return "medium";
  if (tasks >= 1) return "light";
  return "idle";
}
