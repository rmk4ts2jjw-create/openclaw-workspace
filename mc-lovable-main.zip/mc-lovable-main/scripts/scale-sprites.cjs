const { createCanvas, loadImage } = require('canvas');
const path = require('path');
const fs = require('fs');

const OUTPUT_DIR = path.join(__dirname, '..', 'src', 'assets');
const SCALE = 2; // 2x scale factor

const characters = ['monkey', 'lifesupport', 'engineer', 'archivist'];
const poses = ['idle', 'walking', 'working'];

async function main() {
  for (const char of characters) {
    for (const pose of poses) {
      const srcPath = path.join(OUTPUT_DIR, `sprite-${char}-${pose}.png`);
      
      // Check if there's a higher-res version from the HTML render
      // The old sprites are 320x240, we want 640x480
      const img = await loadImage(srcPath);
      
      const newW = img.width * SCALE;
      const newH = img.height * SCALE;
      
      const canvas = createCanvas(newW, newH);
      const ctx = canvas.getContext('2d');
      ctx.imageSmoothingEnabled = false; // Keep pixel art crisp
      ctx.drawImage(img, 0, 0, newW, newH);
      
      const buffer = canvas.toBuffer('image/png');
      
      // Save with 2x suffix
      const outputPath = path.join(OUTPUT_DIR, `sprite-${char}-${pose}-2x.png`);
      fs.writeFileSync(outputPath, buffer);
      console.log(`sprite-${char}-${pose}-2x.png: ${newW}x${newH} (${(buffer.length/1024).toFixed(1)}K)`);
    }
  }
  
  // Also scale rooms 2x
  const rooms = [
    { src: 'room-command.png', out: 'room-command-2x.png' },
    { src: 'room-lifesupport.png', out: 'room-lifesupport-2x.png' },
    { src: 'room-engineer.png', out: 'room-engineer-2x.png' },
    { src: 'room-archivist.png', out: 'room-archivist-2x.png' },
  ];
  
  for (const room of rooms) {
    const srcPath = path.join(OUTPUT_DIR, room.src);
    if (!fs.existsSync(srcPath)) continue;
    
    const img = await loadImage(srcPath);
    const newW = img.width * SCALE;
    const newH = img.height * SCALE;
    
    const canvas = createCanvas(newW, newH);
    const ctx = canvas.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(img, 0, 0, newW, newH);
    
    const buffer = canvas.toBuffer('image/png');
    const outputPath = path.join(OUTPUT_DIR, room.out);
    fs.writeFileSync(outputPath, buffer);
    console.log(`${room.out}: ${newW}x${newH} (${(buffer.length/1024).toFixed(1)}K)`);
  }
  
  console.log('\nDone!');
}

main().catch(err => { console.error(err); process.exit(1); });
