#!/bin/bash
# Start Mission Control dev server with build info injected via env vars
cd "$(dirname "$0")/.."

HASH=$(git rev-parse --short HEAD 2>/dev/null || echo "dev")
TIME=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

echo "[mc] Starting with build $HASH at $TIME"
exec env VITE_BUILD_HASH="$HASH" VITE_BUILD_TIME="$TIME" bun run dev --host --port 3000
