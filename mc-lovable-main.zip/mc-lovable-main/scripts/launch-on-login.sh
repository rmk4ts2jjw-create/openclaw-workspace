#!/usr/bin/env bash
# Install Mission Control as a macOS LaunchAgent
# Runs on login: starts dev server and opens browser

PLIST_NAME="ai.openclaw.mission-control"
PLIST_PATH="$HOME/Library/LaunchAgents/${PLIST_NAME}.plist"
PROJECT_DIR="$HOME/mission-control-dashboard"
BUNDLE_PATH="${PROJECT_DIR}/dist"

# Generate the plist
cat > "$PLIST_PATH" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>${PLIST_NAME}</string>
    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>-c</string>
        <string>cd ${PROJECT_DIR} &amp;&amp; bun dev &amp;&amp; sleep 3 &amp;&amp; open http://localhost:3000</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>WorkingDirectory</key>
    <string>${PROJECT_DIR}</string>
    <key>StandardOutPath</key>
    <string>/tmp/mission-control.log</string>
    <key>StandardErrorPath</key>
    <string>/tmp/mission-control-error.log</string>
    <key>KeepAlive</key>
    <true/>
</dict>
</plist>
EOF

# Load it
launchctl unload "$PLIST_PATH" 2>/dev/null
launchctl load "$PLIST_PATH"

echo "✅ Mission Control LaunchAgent installed."
echo "   Will auto-start on login: bun dev + open localhost:3000"
echo "   Logs: /tmp/mission-control.log"
echo ""
echo "To uninstall:"
echo "  launchctl unload $PLIST_PATH"
echo "  rm $PLIST_PATH"